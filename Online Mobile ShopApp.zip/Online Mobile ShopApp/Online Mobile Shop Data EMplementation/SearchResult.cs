﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Online_Mobile_Shop_Data_Access;
using Online_Mobile_Shop_Model;

namespace Online_Mobile_Shop_Data_Emlpement
{
    public class SearchResult
    {
        SqlCommand command = new SqlCommand();
        Data data = new Data();

        public List<Product> GetListOfProduct(string s)
        {
            List<Product> products = new List<Product>();
            Product product = new Product();
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT [id],[model],[brand],[image] FROM [dbo].[product] WHERE brand LIKE '%{s}%' or model LIKE '%{s}%'";
                var productlist = data.ExeReader(command);
                for (int i = 0; i < productlist.Rows.Count; i++)
                {
                    product.productId = Convert.ToInt32(productlist.Rows[i]["id"].ToString());
                    product.Model = productlist.Rows[i]["model"].ToString();
                    product.Brand = productlist.Rows[i]["brand"].ToString();
                    product.Image = (byte[])productlist.Rows[i]["image"];
                    products.Add(product);
                }
                return products;
            }
            catch
            {
                return null;
            }
        }

        public Product GetProductById(int id)
        {
            try
            {
                Product product = new Product();
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT [id] ,[network] ,[launch] ,[Quantity] ,[dimension] ,[weight] ,[sim] ,[display] ,[display_size] ,[resolution] ,[chipset] ,[ram] ,[memory] ,[camera],[wlan] ,[bluetooth] ,[battery] ,[color] ,[price] ,[warranty] ,[model] ,[brand] ,[image] ,[vote] FROM [dbo].[product] WHERE id ='{id}'";
                var bnd = data.ExeReader(command);
                product.Battery = bnd.Rows[0]["battery"].ToString();
                product.productId = Convert.ToInt32(bnd.Rows[0]["id"].ToString());
                product.Network = bnd.Rows[0]["network"].ToString();
                product.Launch = bnd.Rows[0]["launch"].ToString();
                product.Quantity = Convert.ToInt32(bnd.Rows[0]["Quantity"].ToString());
                product.Dimension = bnd.Rows[0]["dimension"].ToString();
                product.Weight = bnd.Rows[0]["weight"].ToString();
                product.Sim = bnd.Rows[0]["sim"].ToString();
                product.Display = bnd.Rows[0]["display"].ToString();
                product.DispalySize = bnd.Rows[0][8].ToString();
                product.Resolution = bnd.Rows[0]["resolution"].ToString();
                product.Chipset = bnd.Rows[0]["chipset"].ToString();
                product.Ram = bnd.Rows[0]["ram"].ToString();
                product.Memory = bnd.Rows[0]["memory"].ToString();
                product.Camera = bnd.Rows[0]["camera"].ToString();
                product.Wlan = bnd.Rows[0]["wlan"].ToString();
                product.Bluetooth = bnd.Rows[0]["bluetooth"].ToString();
                product.Color = bnd.Rows[0]["color"].ToString();
                product.Price = bnd.Rows[0]["price"].ToString();
                product.Warranty = bnd.Rows[0]["warranty"].ToString();
                product.Model = bnd.Rows[0]["model"].ToString();
                product.Brand = bnd.Rows[0]["brand"].ToString();
                product.Image = (byte[])(bnd.Rows[0]["image"]);
                return product;
            }
            catch
            {
                return null;
            }
        }
    }
}
