﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Online_Mobile_Shop_Data_Access;
using Online_Mobile_Shop_Model;
using System.Data.SqlClient;

namespace Online_Mobile_Shop_Data_Emlpement
{
    public class Login_Registration_Access
    {
        Data data = new Data();
        SqlCommand Command = new SqlCommand();
        public User LoginInfo(User user1)
        {
            try
            {
                DataTable table = new DataTable();
                Command.CommandType = CommandType.Text;
                Command.CommandText = $"SELECT [id],[fname],[lname],[email],[password],[phone],[address],[type] FROM [dbo].[user] WHERE email ='{user1.Email}' AND password ='{user1.Password}'";
                table = data.ExeReader(Command);
                user1.userId = Convert.ToInt32(table.Rows[0]["id"].ToString());
                user1.Email = table.Rows[0]["email"].ToString();
                user1.Fname = table.Rows[0]["fname"].ToString();
                user1.Lname = table.Rows[0]["lname"].ToString();
                user1.Phone = table.Rows[0]["phone"].ToString();
                user1.Address = table.Rows[0]["address"].ToString();
                user1.Password = table.Rows[0]["password"].ToString();
                if (Convert.ToInt32(table.Rows[0]["type"].ToString()) == (int)Types.Admin)
                {
                    user1.Type = Types.Admin;
                }
                else if (Convert.ToInt32(table.Rows[0]["type"].ToString()) == (int)Types.User)
                {
                    user1.Type = Types.User;
                }
            }catch
            {
                user1 = null;
            }
            return user1;
        }

        public int GetUserInfo(User user)
        {
            DataTable table = new DataTable();
            int count;
            try
            {
                Command.CommandType = CommandType.Text;
                Command.CommandText = $"SELECT COUNT([email]) AS ECOUNT FROM [dbo].[user] WHERE email ='{user.Email}'";
                table = data.ExeReader(Command);
                count = Convert.ToInt32(table.Rows[0]["ECOUNT"].ToString());
                return count;
            }
            catch
            {
                count = 3;
                return count;
            }
        }

        public int RegisterUser(User user)
        {
            try
            {
                int stutus;
                Command.CommandType = CommandType.Text;
                Command.CommandText = $"INSERT INTO [dbo].[user] ([fname],[lname],[email],[password],[phone],[address],[type]) VALUES ('{user.Fname}','{user.Lname}','{user.Email}','{user.Password}' ,'{user.Phone}','{user.Address}','{(int)user.Type}')";
                stutus = data.ExeNonQuery(Command);
                return stutus;
            }
            catch
            {
                return 0;
            }
        }
    }
}
