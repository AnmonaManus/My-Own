﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Online_Mobile_Shop_Data_Access;

namespace Online_Mobile_Shop_Data_Emlpement
{
    public class ManageWishList
    {
        SqlCommand command = new SqlCommand();
        Data data = new Data();
        public int AddDataToWishList(int userId, int productId)
        {
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT COUNT(*) AS COUNT FROM [dbo].[WishList] WHERE UserId='{userId}' AND ProductId='{productId}'";
                var value = data.ExeReader(command);
                int count = Convert.ToInt32(value.Rows[0]["COUNT"].ToString());
                if(count==0)
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = $"INSERT INTO [dbo].[WishList] ([UserId] ,[ProductId]) VALUES ('{userId}' ,'{productId}')";
                    int insert = data.ExeNonQuery(command);
                    if (insert == 1)
                    {
                        command.CommandText = $"SELECT [id] ,[vote] FROM [dbo].[product] WHERE id='{productId}'";
                        var p = data.ExeReader(command);
                        command.CommandText = $"UPDATE [dbo].[product] SET [vote] = '{Convert.ToInt32(p.Rows[0]["vote"].ToString())+1}' WHERE id='{productId}'";
                        int update = data.ExeNonQuery(command);
                        if(update>0)
                        {
                            return 1;
                        }
                        else
                        {
                            return 3;
                        }
                        
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    return 2;
                }
            }
            catch
            {
                return 1111;
            }
        }
        //
        public int ManagesWishList(int userId, int pid)
        {
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"DELETE FROM [dbo].[WishList] WHERE UserId='{userId}'AND ProductId='{pid}'";
                int insert = data.ExeNonQuery(command);
                if (insert == 1)
                {
                    command.CommandText = $"SELECT [id] ,[vote] FROM [dbo].[product] WHERE id='{pid}'";
                    var p = data.ExeReader(command);
                    command.CommandText = $"UPDATE [dbo].[product] SET [vote] = '{Convert.ToInt32(p.Rows[0]["vote"].ToString()) - 1}' WHERE id='{pid}'";
                    int update = data.ExeNonQuery(command);
                    if (update > 0)
                    {
                        return 1;
                    }
                    else
                    {
                        return 3;
                    }

                }
                else
                {
                    return 0;
                }
            }catch
            {
                return 1111;
            }
        }
    }
}
