﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Online_Mobile_Shop_Data_Access;
using Online_Mobile_Shop_Model;

namespace Online_Mobile_Shop_Data_Emlpement
{
    public class Orders
    {
        SqlCommand command = new SqlCommand();
        Data data = new Data();
        public int ConfirmOrder(List<Order> carts)
        {
            try
            {
                command.CommandType = CommandType.Text;
                foreach (var cart in carts)
                {
                    command.CommandText = $"INSERT INTO [dbo].[Order] ([brand] ,[model],[purchaseTime],[price] ,[Quantity],[status],[deliver],[UserId])  VALUES   ('{cart.Brand}' ,'{cart.Model}' ,'{cart.PurchaseTime}'  ,'{cart.Price}' ,'{cart.Quantity}' ,'{(int)cart.Stutas}','{cart.Delivered}','{cart.UserId}')";
                    int seccess = data.ExeNonQuery(command);
                    command.Parameters.Clear();
                    command.CommandText = $"SELECT [Quantity] FROM [dbo].[product] WHERE id='{cart.ProductId}'";
                    var pd = data.ExeReader(command);
                    int value = Convert.ToInt32(pd.Rows[0]["Quantity"].ToString());
                    command.CommandText = $"UPDATE [dbo].[product] SET [Quantity] = '{value-cart.Quantity}' WHERE id='{cart.ProductId}'";
                    seccess = data.ExeNonQuery(command);
                }
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        public List<Wishlist> GetWishList(int id)
        {
            List<Wishlist> products = new List<Wishlist>();
            Wishlist product = new Wishlist();
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT dbo.product.id,dbo.product.brand,dbo.product.model,dbo.product.price FROM dbo.Brand ,dbo.product,dbo.WishList WHERE dbo.Brand.brand=dbo.product.brand and dbo.WishList.ProductId=dbo.product.id and dbo.WishList.UserId='{id}'";
            var value = data.ExeReader(command);
            for(int i=0;i<value.Rows.Count;i++)
            {
                product.ProductId = value.Rows[i]["id"].ToString();
                product.Brand = value.Rows[i]["brand"].ToString();
                product.Model = value.Rows[i]["model"].ToString();
                product.Price = value.Rows[i]["price"].ToString();
                products.Add(product);
            }
            return products;
        }

        public List<Order> GetUserOrderData(int id)
        {
            List<Order> orders = new List<Order>();
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT [id],[brand] ,[model] ,[purchaseTime] ,[price] ,[Quantity],[status] ,[deliver] ,[UserId] FROM [Shop].[dbo].[Order] WHERE UserId='{id}' ORDER BY purchaseTime DESC";
            var odr = data.ExeReader(command);
            for(int i=0;i<odr.Rows.Count;i++)
            {
                using(Order order =new Order())
                {
                    order.OrderId = Convert.ToInt32(odr.Rows[i]["id"].ToString());
                    order.Brand = odr.Rows[i]["brand"].ToString();
                    order.Model = odr.Rows[i]["model"].ToString();
                    order.PurchaseTime = Convert.ToDateTime(odr.Rows[i]["purchaseTime"].ToString());
                    order.Price = Convert.ToInt32(odr.Rows[i]["price"].ToString());
                    order.Quantity = Convert.ToInt32(odr.Rows[i]["Quantity"].ToString());
                    order.Delivered = Convert.ToDateTime(odr.Rows[i]["deliver"].ToString());
                    order.UserId = Convert.ToInt32(odr.Rows[i]["UserId"].ToString());
                    if(Convert.ToInt32(odr.Rows[i]["status"].ToString())==0)
                    {
                        order.Stutas = OrderStutas.Pending;
                    }
                    else if(Convert.ToInt32(odr.Rows[i]["status"].ToString()) == 1)
                    {
                        order.Stutas = OrderStutas.Delivered;
                    }
                    orders.Add(order);

                }
            }
            return orders;
        }

        public List<Order> GetAllOrderData()
        {
            List<Order> orders = new List<Order>();
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT [id],[brand] ,[model] ,[purchaseTime] ,[price] ,[Quantity],[status] ,[deliver] ,[UserId] FROM [Shop].[dbo].[Order] ORDER BY purchaseTime DESC";
            var odr = data.ExeReader(command);
            for (int i = 0; i < odr.Rows.Count; i++)
            {
                using (Order order = new Order())
                {
                    order.OrderId = Convert.ToInt32(odr.Rows[i]["id"].ToString());
                    order.Brand = odr.Rows[i]["brand"].ToString();
                    order.Model = odr.Rows[i]["model"].ToString();
                    order.PurchaseTime = Convert.ToDateTime(odr.Rows[i]["purchaseTime"].ToString());
                    order.Price = Convert.ToInt32(odr.Rows[i]["price"].ToString());
                    order.Quantity = Convert.ToInt32(odr.Rows[i]["Quantity"].ToString());
                    order.Delivered = Convert.ToDateTime(odr.Rows[i]["deliver"].ToString());
                    order.UserId = Convert.ToInt32(odr.Rows[i]["UserId"].ToString());
                    if (Convert.ToInt32(odr.Rows[i]["status"].ToString()) == 0)
                    {
                        order.Stutas = OrderStutas.Pending;
                    }
                    else if (Convert.ToInt32(odr.Rows[i]["status"].ToString()) == 1)
                    {
                        order.Stutas = OrderStutas.Delivered;
                    }
                    orders.Add(order);

                }
            }
            return orders;
        }

        public List<Order> GetPendingOrder()
        {
            List<Order> orders = new List<Order>();
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT [id],[brand] ,[model] ,[purchaseTime] ,[price] ,[Quantity],[status] ,[deliver] ,[UserId] FROM [Shop].[dbo].[Order] WHERE status='0' ORDER BY purchaseTime DESC";
            var odr = data.ExeReader(command);
            for (int i = 0; i < odr.Rows.Count; i++)
            {
                using (Order order = new Order())
                {
                    order.OrderId = Convert.ToInt32(odr.Rows[i]["id"].ToString());
                    order.Brand = odr.Rows[i]["brand"].ToString();
                    order.Model = odr.Rows[i]["model"].ToString();
                    order.PurchaseTime = Convert.ToDateTime(odr.Rows[i]["purchaseTime"].ToString());
                    order.Price = Convert.ToInt32(odr.Rows[i]["price"].ToString());
                    order.Quantity = Convert.ToInt32(odr.Rows[i]["Quantity"].ToString());
                    order.Delivered = Convert.ToDateTime(odr.Rows[i]["deliver"].ToString());
                    order.UserId = Convert.ToInt32(odr.Rows[i]["UserId"].ToString());
                    if (Convert.ToInt32(odr.Rows[i]["status"].ToString()) == 0)
                    {
                        order.Stutas = OrderStutas.Pending;
                    }
                    else if (Convert.ToInt32(odr.Rows[i]["status"].ToString()) == 1)
                    {
                        order.Stutas = OrderStutas.Delivered;
                    }
                    orders.Add(order);

                }
            }
            return orders;
        }

        public List<Order> GetPDeliveredOrder()
        {
            List<Order> orders = new List<Order>();
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT [id],[brand] ,[model] ,[purchaseTime] ,[price] ,[Quantity],[status] ,[deliver] ,[UserId] FROM [Shop].[dbo].[Order] WHERE status='1' ORDER BY purchaseTime DESC";
            var odr = data.ExeReader(command);
            for (int i = 0; i < odr.Rows.Count; i++)
            {
                using (Order order = new Order())
                {
                    order.OrderId = Convert.ToInt32(odr.Rows[i]["id"].ToString());
                    order.Brand = odr.Rows[i]["brand"].ToString();
                    order.Model = odr.Rows[i]["model"].ToString();
                    order.PurchaseTime = Convert.ToDateTime(odr.Rows[i]["purchaseTime"].ToString());
                    order.Price = Convert.ToInt32(odr.Rows[i]["price"].ToString());
                    order.Quantity = Convert.ToInt32(odr.Rows[i]["Quantity"].ToString());
                    order.Delivered = Convert.ToDateTime(odr.Rows[i]["deliver"].ToString());
                    order.UserId = Convert.ToInt32(odr.Rows[i]["UserId"].ToString());
                    if (Convert.ToInt32(odr.Rows[i]["status"].ToString()) == 0)
                    {
                        order.Stutas = OrderStutas.Pending;
                    }
                    else if (Convert.ToInt32(odr.Rows[i]["status"].ToString()) == 1)
                    {
                        order.Stutas = OrderStutas.Delivered;
                    }
                    orders.Add(order);

                }
            }
            return orders;
        }

        public int UpdatePendingToDelevered(int pid)
        {
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"UPDATE [dbo].[Order] SET [status] = '1',[deliver] = '{DateTime.Now}' WHERE id='{pid}'";
                int op = data.ExeNonQuery(command);
                if (op == 1)
                {
                    return 1;
                }
                else
                    return 0;
            }catch
            { return 1111; }
        }

        public int UpdateDeleveredToPending(int pid)
        {
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"UPDATE [dbo].[Order] SET [status] = '0',[deliver] = '{DateTime.Now}' WHERE id='{pid}'";
                int op = data.ExeNonQuery(command);
                if (op == 1)
                {
                    return 1;
                }
                else
                    return 0;
            }
            catch
            { return 1111; }
        }
    }
}
