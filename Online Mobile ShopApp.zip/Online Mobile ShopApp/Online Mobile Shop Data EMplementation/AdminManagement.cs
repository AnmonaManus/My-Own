﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Online_Mobile_Shop_Data_Access;
using Online_Mobile_Shop_Model;
namespace Online_Mobile_Shop_Data_Emlpement
{
    public class AdminManagement
    {
        Data d1 =new Data();
        SqlCommand command = new SqlCommand();
        public int AddProductToDatabase(Product product)
        {
           try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT COUNT([brand])  as Brand FROM [dbo].[Brand] WHERE brand ='{product.Brand}'";
                var value = d1.ExeReader(command);
                int val = Convert.ToInt32(value.Rows[0]["Brand"]);
                if(val==0)
                {
                    command.CommandText = $"INSERT INTO [dbo].[Brand] ([brand]) VALUES ('{product.Brand}')";
                    int bnd = d1.ExeNonQuery(command);
                    if(bnd>1)
                    {
                        command.CommandText = $"INSERT INTO [dbo].[product] ([network] ,[launch] ,[Quantity] ,[dimension] ,[weight] ,[sim] ,[display] ,[display_size] ,[resolution] ,[chipset] ,[ram] ,[memory] ,[camera] ,[wlan] ,[bluetooth] ,[battery],[color] ,[price] ,[warranty] ,[model] ,[brand] ,[image] ,[vote]) VALUES ('{product.Network}' ,'{product.Launch}' ,'{product.Quantity}' ,'{product.Dimension}' ,'{product.Weight}' ,'{product.Sim}' ,'{product.Display}' ,'{product.DispalySize}'  ,'{product.Resolution}' ,'{product.Chipset}' ,'{product.Ram}' ,'{product.Memory}' ,'{product.Camera}' ,'{product.Wlan}' ,'{product.Bluetooth}' ,'{product.Battery}' ,'{product.Color}' ,{product.Price}  ,'{product.Warranty}' ,'{product.Model}' ,'{product.Brand}' , @image ,'0')";
                        command.Parameters.Add(new SqlParameter("@image", product.Image));
                        int pdct = d1.ExeNonQuery(command);
                        command.Parameters.Clear();
                        return pdct;
                    }
                    else
                    {
                        return 0;
                    }

                }
                else
                {
                    command.CommandText = $"INSERT INTO [dbo].[product] ([network] ,[launch] ,[Quantity] ,[dimension] ,[weight] ,[sim] ,[display] ,[display_size] ,[resolution] ,[chipset] ,[ram] ,[memory] ,[camera] ,[wlan] ,[bluetooth] ,[battery],[color] ,[price] ,[warranty] ,[model] ,[brand] ,[image] ,[vote]) VALUES ('{product.Network}' ,'{product.Launch}' ,'{product.Quantity}' ,'{product.Dimension}' ,'{product.Weight}' ,'{product.Sim}' ,'{product.Display}' ,'{product.DispalySize}'  ,'{product.Resolution}' ,'{product.Chipset}' ,'{product.Ram}' ,'{product.Memory}' ,'{product.Camera}' ,'{product.Wlan}' ,'{product.Bluetooth}' ,'{product.Battery}' ,'{product.Color}' ,'{product.Price}'  ,'{product.Warranty}' ,'{product.Model}' ,'{product.Brand}' ,@image ,'0')";
                    command.Parameters.Add(new SqlParameter("@image", product.Image));
                    int pdct = d1.ExeNonQuery(command);
                    command.Parameters.Clear();
                    return pdct;
                }
            }
            catch
            {
                return 1111;
            }
        }

        public List<string> FetchModel(string v)
        {
            List<string> modellist = new List<string>();
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT [model] FROM [dbo].[product] WHERE brand='{v}'";
            var model = d1.ExeReader(command);
            for (int i = 0; i < model.Rows.Count; i++)
            {
                modellist.Add(model.Rows[i]["model"].ToString());
            }
            return modellist;
        }

        public List<Product> FetchModelInfo(string b,string m)
        {
            List<Product> products = new List<Product>();
            Product product = new Product();
            command.CommandType = CommandType.Text;
            command.CommandText = $"SELECT [id],[model],[brand],[image] FROM [dbo].[product] WHERE brand='{b}' AND model='{m}'";
            var model = d1.ExeReader(command);
            for(int i=0;i<model.Rows.Count; i++)
            {
                product.productId = Convert.ToInt32(model.Rows[i]["id"].ToString());
                product.Model = model.Rows[i]["model"].ToString();
                product.Brand = model.Rows[i]["brand"].ToString();
                product.Image = (byte[])model.Rows[i]["image"];
                products.Add(product);
            }
            return products;
        }


        public Product GetDetailsById(int id)
        {
            try
            {
                Product product = new Product();
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT [id] ,[network] ,[launch] ,[Quantity] ,[dimension] ,[weight] ,[sim] ,[display] ,[display_size] ,[resolution] ,[chipset] ,[ram] ,[memory] ,[camera],[wlan] ,[bluetooth] ,[battery] ,[color] ,[price] ,[warranty] ,[model] ,[brand] ,[image] ,[vote] FROM [dbo].[product] WHERE id ='{id}'";
                var bnd = d1.ExeReader(command);
                product.Battery = bnd.Rows[0]["battery"].ToString();
                product.productId = Convert.ToInt32(bnd.Rows[0]["id"].ToString());
                product.Network = bnd.Rows[0]["network"].ToString();
                product.Launch = bnd.Rows[0]["launch"].ToString();
                product.Quantity = Convert.ToInt32(bnd.Rows[0]["Quantity"].ToString());
                product.Dimension = bnd.Rows[0]["dimension"].ToString();
                product.Weight = bnd.Rows[0]["weight"].ToString();
                product.Sim = bnd.Rows[0]["sim"].ToString();
                product.Display = bnd.Rows[0]["display"].ToString();
                product.DispalySize = bnd.Rows[0][8].ToString();
                product.Resolution = bnd.Rows[0]["resolution"].ToString();
                product.Chipset = bnd.Rows[0]["chipset"].ToString();
                product.Ram = bnd.Rows[0]["ram"].ToString();
                product.Memory = bnd.Rows[0]["memory"].ToString();
                product.Camera = bnd.Rows[0]["camera"].ToString();
                product.Wlan = bnd.Rows[0]["wlan"].ToString();
                product.Bluetooth = bnd.Rows[0]["bluetooth"].ToString();
                product.Color = bnd.Rows[0]["color"].ToString();
                product.Price = bnd.Rows[0]["price"].ToString();
                product.Warranty = bnd.Rows[0]["warranty"].ToString();
                product.Model = bnd.Rows[0]["model"].ToString();
                product.Brand = bnd.Rows[0]["brand"].ToString();
                product.Image = (byte[])(bnd.Rows[0]["image"]);
                return product;
            }
            catch
            {
                return null;
            }

        }

        public List<string> FetchBrand()
        {
            List<string> str=new List<string>(); 
            command.CommandType = CommandType.Text;
            command.CommandText = "SELECT [brand] FROM [dbo].[Brand]";
            var bnd = d1.ExeReader(command);
            for(int i=0;i<bnd.Rows.Count;i++)
            {
                str.Add(bnd.Rows[i]["brand"].ToString());
            }
            return str;
        }

        public int UpdateProductToDatabase(Product product)
        {
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT COUNT([brand])  as Brand FROM [dbo].[Brand] WHERE brand ='{product.Brand}'";
                var value = d1.ExeReader(command);
                int val = Convert.ToInt32(value.Rows[0]["Brand"]);
                if (val == 0)
                {
                    command.CommandText = $"INSERT INTO [dbo].[Brand] ([brand]) VALUES ('{product.Brand}')";
                    int bnd = d1.ExeNonQuery(command);
                    if (bnd > 1)
                    {
                        command.CommandText = $"UPDATE [dbo].[product] SET [network] = '{product.Network}',[launch] = '{product.Launch}' ,[Quantity] = '{product.Quantity}' ,[dimension] = '{product.Dimension}' ,[weight] = '{product.Weight}' ,[sim] = '{product.Sim}' ,[display] = '{product.Display}' ,[display_size] = '{product.DispalySize}' ,[resolution] = '{product.Resolution}' ,[chipset] = '{product.Chipset}' ,[ram] = '{product.Ram}' ,[memory] = '{product.Memory}' ,[camera] = '{product.Memory}' ,[wlan] = '{product.Wlan}' ,[bluetooth] = '{product.Bluetooth}' ,[battery] = '{product.Battery}',[color] = '{product.Color}' ,[price] = '{product.Price}' ,[warranty] = '{product.Warranty}' ,[model] = '{product.Model}' ,[brand] = '{product.Brand}' ,[image] = @image WHERE id ={product.productId}";
                        command.Parameters.Add(new SqlParameter("@image", product.Image));
                        int pdct = d1.ExeNonQuery(command);
                        command.Parameters.Clear();
                        return pdct;
                    }
                    else
                    {
                        return 0;
                    }

                }
                else
                {
                    command.CommandText = $"UPDATE [dbo].[product] SET [network] = '{product.Network}',[launch] = '{product.Launch}' ,[Quantity] = '{product.Quantity}' ,[dimension] = '{product.Dimension}' ,[weight] = '{product.Weight}' ,[sim] = '{product.Sim}' ,[display] = '{product.Display}' ,[display_size] = '{product.DispalySize}' ,[resolution] = '{product.Resolution}' ,[chipset] = '{product.Chipset}' ,[ram] = '{product.Ram}' ,[memory] = '{product.Memory}' ,[camera] = '{product.Memory}' ,[wlan] = '{product.Wlan}' ,[bluetooth] = '{product.Bluetooth}' ,[battery] = '{product.Battery}',[color] = '{product.Color}' ,[price] = '{product.Price}' ,[warranty] = '{product.Warranty}' ,[model] = '{product.Model}' ,[brand] = '{product.Brand}' ,[image] = @image WHERE id ={product.productId}";
                    command.Parameters.Add(new SqlParameter("@image", product.Image));
                    int pdct = d1.ExeNonQuery(command);
                    command.Parameters.Clear();
                    return pdct;
                }
            }
            catch
            {
                return 1111;
            }
        }

        public int DeleteProductById(int productid)
        {
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"DELETE FROM [dbo].[product] WHERE id='{productid}'";
                int pdct = d1.ExeNonQuery(command);
                if (pdct > 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch
            {
                return 1111;
            }
        }
    }
}
