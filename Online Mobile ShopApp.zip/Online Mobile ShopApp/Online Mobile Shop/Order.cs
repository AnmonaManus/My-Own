﻿using Online_Mobile_Shop_Data_Emlpement;
using Online_Mobile_Shop_Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Mobile_Shop
{
    public partial class Order : Form
    {
        Orders orders = new Orders();
        public Order()
        {
            InitializeComponent();
            this.AddressBox.Multiline = true;
            AddressBox.AutoScroll = true;
        }
        public void SuccessLogout()
        {
            Form1.islogin = false;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.bunifuToolTip1.SetToolTip(this.Login, "Login");
            this.pictureBox2.Visible = false;
            this.pictureBox3.Visible = false;
            this.AdminButton.Visible = false;
        }
        private void BunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BunifuI1mageButton4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 50)
            {
                Form1.menu = true;
                Sidebar.Visible = true;
                Sidebar.Width = 220;
                this.Width = 1080;
                bunifuTransitionOnShow.ShowSync(Sidebar);
            }
            else
            {
                Form1.menu = true;
                Sidebar.Width = 50;
                Sidebar.Visible = false;
                this.Width = 1080 - 50;
                bunifuTransitionOnHide.ShowSync(Sidebar);
            }
        }
        private void Login_Click(object sender, EventArgs e)
        {
            if (!Form1.islogin)
            {
                UserLogin login = new UserLogin();
                login.Show();
                this.Close();
            }
            else
            {
                SuccessLogout();
                Form1 form1 = new Form1();
                this.Hide();
                form1.Show();
            }
        }
        private void Order_Load(object sender, EventArgs e)
        {
            if (Form1.menu)
            {
                if (Sidebar.Width == 50)
                {
                    Form1.menu = true;
                    Sidebar.Visible = true;
                    Sidebar.Width = 220;
                    this.Width = 1080;
                    bunifuTransitionOnShow.ShowSync(Sidebar);
                }
                else
                {
                    Form1.menu = true;
                    Sidebar.Width = 50;
                    Sidebar.Visible = false;
                    this.Width = 1080 - 50;
                    bunifuTransitionOnHide.ShowSync(Sidebar);
                }
            }
            if (Form1.islogin)
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
                this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
                this.pictureBox2.Visible = true;
                this.pictureBox3.Visible = true;
                this.OrderHistorys.Visible = true;
                if (UserLogin.dt.Type == Types.Admin)
                {
                    this.AdminButton.Visible = true;
                }
            }
            else
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
                this.bunifuToolTip1.SetToolTip(this.Login, "Login");
                this.pictureBox2.Visible = false;
                this.pictureBox3.Visible = false;
                this.AdminButton.Visible = false;
                this.OrderHistorys.Visible = false;
            }
            this.EmailBox.Text = UserLogin.dt.Email;
            this.NameBox.Text = $"{UserLogin.dt.Fname} {UserLogin.dt.Lname}";
            this.AddressBox.Text = UserLogin.dt.Address;
            this.PhoneBox.Text = UserLogin.dt.Phone;
        }
        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }
        private void BunifuButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature Will Comming Soon", "Future Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void AdminButton_Click(object sender, EventArgs e)
        {
            AdminManage admin = new AdminManage();
            this.Hide();
            admin.Show();
        }
        private void BunifuButton2_Click(object sender, EventArgs e)
        {
            MoblieList mobile = new MoblieList();
            mobile.Show();
            this.Close();
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            UserCart userCart = new UserCart(ProductDetails.carts);
            userCart.Show();
            this.Close();
        }

        private void BunifuButton1_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        
        private bool Email1Box_Leave()
        {
            try
            {
                System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
                if (rEMail.IsMatch(EmailBox.Text))
                {
                    return true;
                }
                else
                    return false;
            }
            catch (FormatException ex)
            {
                return false;
            }
        }
        private void BunifuButton4_Click(object sender, EventArgs e)
        {
            bool confirm = true;
            if(string.IsNullOrEmpty(this.NameBox.Text))
            {
                confirm = false;
                this.NameBox.Focus();
            }
            else if(string.IsNullOrEmpty(this.EmailBox.Text))
            {
                confirm = false;
                this.EmailBox.Focus();
            }
            else if(string.IsNullOrEmpty(this.AddressBox.Text))
            {
                confirm = false;
                this.AddressBox.Focus();
            }
            else if(string.IsNullOrEmpty(this.PhoneBox.Text))
            {
                confirm = false;
                this.PhoneBox.Focus();
            }
            if(!(bunifuDropdown1.SelectedIndex>-1))
            {
                confirm = false;
                MessageBox.Show("Select Payment Type");
            }
            if(!Email1Box_Leave())
            {
                confirm = false;
                MessageBox.Show("Invaied Email");
            }
            if(confirm)
            {
                List<Online_Mobile_Shop_Model.Order> order = new List<Online_Mobile_Shop_Model.Order>();
                Online_Mobile_Shop_Model.Order order1 = new Online_Mobile_Shop_Model.Order();
                foreach (var cart in ProductDetails.carts)
                {
                    order1.ProductId = cart.ProductId;
                    order1.Brand = cart.Brand;
                    order1.Delivered = null;
                    order1.Model = cart.Model;
                    order1.Price = cart.Price;
                    order1.Quantity = cart.Quantity;
                    order1.PurchaseTime = DateTime.Now;
                    order1.Stutas = OrderStutas.Pending;
                    order1.UserId = UserLogin.dt.userId;
                    order.Add(order1);
                }
              int value=  orders.ConfirmOrder(order);
                if(value==1)
                {
                    MessageBox.Show("Ordered Wait For Receve");
                    Form1 form1 = new Form1();
                    this.Hide();
                    form1.Show();
                    ProductDetails.carts.Clear();
                }
                else if(value==0)
                {
                    MessageBox.Show("Server Error Try Leter");
                    Form1 form1 = new Form1();
                    this.Hide();
                    form1.Show();
                }
            }
        }

        private void AddressBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            var value = (PlaceholderTextBox)sender;
            if(value.PlaceholderText.Equals("Name") && e.KeyChar==(char)Keys.Enter)
            {
                this.EmailBox.Focus();
            }
            else if(value.PlaceholderText.Equals("Email") && e.KeyChar == (char)Keys.Enter)
            {
                this.AddressBox.Focus();
            }
            else if(value.PlaceholderText.Equals("Address") && e.KeyChar == (char)Keys.Enter)
            {
                this.PhoneBox.Focus();
            }
            else if(value.PlaceholderText.Equals("Phone Number"))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    AddressBox.Focus();
                }
                if ((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) ||
            (e.KeyChar == '.'))
                {
                    e.Handled = true;
                }
            }
        }

        private void BunifuLabel4_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            WishList wishList = new WishList(new Orders().GetWishList(UserLogin.dt.userId));
            this.Hide();
            wishList.Show();
        }

        private void OrderHistorys_Click(object sender, EventArgs e)
        {
            OrderHistory orderHistory = new OrderHistory();
            this.Hide();
            orderHistory.Show();
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            Search search = new Search(bunifuTextBox1.Text);
            this.Hide();
            search.Show();
        }

        private void BunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                PictureBox5_Click(sender, e);
            }
        }
    }
}
