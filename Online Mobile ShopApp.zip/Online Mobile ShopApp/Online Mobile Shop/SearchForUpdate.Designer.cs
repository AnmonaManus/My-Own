﻿namespace Online_Mobile_Shop
{
    partial class SearchForUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchForUpdate));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Header = new System.Windows.Forms.Panel();
            this.TitlePic = new System.Windows.Forms.PictureBox();
            this.TitleLb = new System.Windows.Forms.Label();
            this.bunifuImageButton4 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Results = new System.Windows.Forms.FlowLayoutPanel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.SearchModel = new Bunifu.UI.WinForms.BunifuDropdown();
            this.SearchBrand = new Bunifu.UI.WinForms.BunifuDropdown();
            this.bunifuToolTip1 = new Bunifu.UI.WinForms.BunifuToolTip(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.Header.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TitlePic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // Header
            // 
            this.Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(42)))), ((int)(((byte)(170)))));
            this.Header.Controls.Add(this.TitlePic);
            this.Header.Controls.Add(this.TitleLb);
            this.Header.Controls.Add(this.bunifuImageButton4);
            this.Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.Header.Location = new System.Drawing.Point(0, 0);
            this.Header.Name = "Header";
            this.Header.Size = new System.Drawing.Size(629, 39);
            this.Header.TabIndex = 0;
            this.bunifuToolTip1.SetToolTip(this.Header, "");
            this.bunifuToolTip1.SetToolTipIcon(this.Header, null);
            this.bunifuToolTip1.SetToolTipTitle(this.Header, "");
            // 
            // TitlePic
            // 
            this.TitlePic.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_google_web_search_52;
            this.TitlePic.Location = new System.Drawing.Point(6, 2);
            this.TitlePic.Name = "TitlePic";
            this.TitlePic.Size = new System.Drawing.Size(35, 34);
            this.TitlePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.TitlePic.TabIndex = 5;
            this.TitlePic.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.TitlePic, "");
            this.bunifuToolTip1.SetToolTipIcon(this.TitlePic, null);
            this.bunifuToolTip1.SetToolTipTitle(this.TitlePic, "");
            // 
            // TitleLb
            // 
            this.TitleLb.AutoSize = true;
            this.TitleLb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleLb.ForeColor = System.Drawing.Color.White;
            this.TitleLb.Location = new System.Drawing.Point(49, 9);
            this.TitleLb.Name = "TitleLb";
            this.TitleLb.Size = new System.Drawing.Size(145, 20);
            this.TitleLb.TabIndex = 4;
            this.TitleLb.Text = "Search For Update";
            this.bunifuToolTip1.SetToolTip(this.TitleLb, "");
            this.bunifuToolTip1.SetToolTipIcon(this.TitleLb, null);
            this.bunifuToolTip1.SetToolTipTitle(this.TitleLb, "");
            // 
            // bunifuImageButton4
            // 
            this.bunifuImageButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuImageButton4.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_multiply_48;
            this.bunifuImageButton4.ImageActive = null;
            this.bunifuImageButton4.Location = new System.Drawing.Point(585, 6);
            this.bunifuImageButton4.Name = "bunifuImageButton4";
            this.bunifuImageButton4.Size = new System.Drawing.Size(34, 28);
            this.bunifuImageButton4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton4.TabIndex = 2;
            this.bunifuImageButton4.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.bunifuImageButton4, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuImageButton4, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuImageButton4, "");
            this.bunifuImageButton4.Zoom = 10;
            this.bunifuImageButton4.Click += new System.EventHandler(this.BunifuImageButton4_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.panel2.Controls.Add(this.Results);
            this.panel2.Controls.Add(this.bunifuLabel1);
            this.panel2.Controls.Add(this.bunifuLabel4);
            this.panel2.Controls.Add(this.SearchModel);
            this.panel2.Controls.Add(this.SearchBrand);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 39);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(629, 363);
            this.panel2.TabIndex = 1;
            this.bunifuToolTip1.SetToolTip(this.panel2, "");
            this.bunifuToolTip1.SetToolTipIcon(this.panel2, null);
            this.bunifuToolTip1.SetToolTipTitle(this.panel2, "");
            // 
            // Results
            // 
            this.Results.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Results.ForeColor = System.Drawing.Color.White;
            this.Results.Location = new System.Drawing.Point(0, 162);
            this.Results.Name = "Results";
            this.Results.Padding = new System.Windows.Forms.Padding(20, 10, 0, 0);
            this.Results.Size = new System.Drawing.Size(629, 201);
            this.Results.TabIndex = 12;
            this.Results.TabStop = true;
            this.bunifuToolTip1.SetToolTip(this.Results, "");
            this.bunifuToolTip1.SetToolTipIcon(this.Results, null);
            this.bunifuToolTip1.SetToolTipTitle(this.Results, "");
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.AutoSize = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(143, 91);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(100, 32);
            this.bunifuLabel1.TabIndex = 11;
            this.bunifuLabel1.Text = "Select Model";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel1, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel1, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel1, "");
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.AutoSize = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel4.Location = new System.Drawing.Point(143, 37);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(100, 32);
            this.bunifuLabel4.TabIndex = 11;
            this.bunifuLabel4.Text = "Select Brand";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel4, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel4, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel4, "");
            // 
            // SearchModel
            // 
            this.SearchModel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.SearchModel.BorderRadius = 1;
            this.SearchModel.Color = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.SearchModel.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.SearchModel.DisabledColor = System.Drawing.Color.Gray;
            this.SearchModel.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SearchModel.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thick;
            this.SearchModel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchModel.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.SearchModel.Enabled = false;
            this.SearchModel.FillDropDown = false;
            this.SearchModel.FillIndicator = false;
            this.SearchModel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchModel.ForeColor = System.Drawing.Color.White;
            this.SearchModel.FormattingEnabled = true;
            this.SearchModel.Icon = null;
            this.SearchModel.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.SearchModel.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.SearchModel.ItemBackColor = System.Drawing.Color.White;
            this.SearchModel.ItemBorderColor = System.Drawing.Color.White;
            this.SearchModel.ItemForeColor = System.Drawing.Color.DodgerBlue;
            this.SearchModel.ItemHeight = 26;
            this.SearchModel.ItemHighLightColor = System.Drawing.Color.Thistle;
            this.SearchModel.Location = new System.Drawing.Point(251, 88);
            this.SearchModel.Name = "SearchModel";
            this.SearchModel.Size = new System.Drawing.Size(217, 32);
            this.SearchModel.TabIndex = 10;
            this.SearchModel.Text = null;
            this.bunifuToolTip1.SetToolTip(this.SearchModel, "");
            this.bunifuToolTip1.SetToolTipIcon(this.SearchModel, null);
            this.bunifuToolTip1.SetToolTipTitle(this.SearchModel, "");
            this.SearchModel.SelectedIndexChanged += new System.EventHandler(this.SearchModel_SelectedIndexChanged);
            // 
            // SearchBrand
            // 
            this.SearchBrand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.SearchBrand.BorderRadius = 1;
            this.SearchBrand.Color = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.SearchBrand.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.SearchBrand.DisabledColor = System.Drawing.Color.Gray;
            this.SearchBrand.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.SearchBrand.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thick;
            this.SearchBrand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchBrand.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.SearchBrand.FillDropDown = false;
            this.SearchBrand.FillIndicator = false;
            this.SearchBrand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchBrand.ForeColor = System.Drawing.Color.White;
            this.SearchBrand.FormattingEnabled = true;
            this.SearchBrand.Icon = null;
            this.SearchBrand.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.SearchBrand.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.SearchBrand.ItemBackColor = System.Drawing.Color.White;
            this.SearchBrand.ItemBorderColor = System.Drawing.Color.White;
            this.SearchBrand.ItemForeColor = System.Drawing.Color.DodgerBlue;
            this.SearchBrand.ItemHeight = 26;
            this.SearchBrand.ItemHighLightColor = System.Drawing.Color.Thistle;
            this.SearchBrand.Location = new System.Drawing.Point(251, 34);
            this.SearchBrand.Name = "SearchBrand";
            this.SearchBrand.Size = new System.Drawing.Size(217, 32);
            this.SearchBrand.TabIndex = 10;
            this.SearchBrand.Text = null;
            this.bunifuToolTip1.SetToolTip(this.SearchBrand, "");
            this.bunifuToolTip1.SetToolTipIcon(this.SearchBrand, null);
            this.bunifuToolTip1.SetToolTipTitle(this.SearchBrand, "");
            this.SearchBrand.SelectedIndexChanged += new System.EventHandler(this.SearchBrand_SelectedIndexChanged);
            // 
            // bunifuToolTip1
            // 
            this.bunifuToolTip1.Active = true;
            this.bunifuToolTip1.AlignTextWithTitle = false;
            this.bunifuToolTip1.AllowAutoClose = false;
            this.bunifuToolTip1.AllowFading = true;
            this.bunifuToolTip1.AutoCloseDuration = 5000;
            this.bunifuToolTip1.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuToolTip1.BorderColor = System.Drawing.Color.Gainsboro;
            this.bunifuToolTip1.ClickToShowDisplayControl = false;
            this.bunifuToolTip1.ConvertNewlinesToBreakTags = true;
            this.bunifuToolTip1.DisplayControl = null;
            this.bunifuToolTip1.EntryAnimationSpeed = 350;
            this.bunifuToolTip1.ExitAnimationSpeed = 200;
            this.bunifuToolTip1.GenerateAutoCloseDuration = false;
            this.bunifuToolTip1.IconMargin = 6;
            this.bunifuToolTip1.InitialDelay = 0;
            this.bunifuToolTip1.Name = "bunifuToolTip1";
            this.bunifuToolTip1.Opacity = 1D;
            this.bunifuToolTip1.OverrideToolTipTitles = false;
            this.bunifuToolTip1.Padding = new System.Windows.Forms.Padding(10);
            this.bunifuToolTip1.ReshowDelay = 100;
            this.bunifuToolTip1.ShowAlways = true;
            this.bunifuToolTip1.ShowBorders = false;
            this.bunifuToolTip1.ShowIcons = true;
            this.bunifuToolTip1.ShowShadows = true;
            this.bunifuToolTip1.Tag = null;
            this.bunifuToolTip1.TextFont = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuToolTip1.TextForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuToolTip1.TextMargin = 2;
            this.bunifuToolTip1.TitleFont = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.bunifuToolTip1.TitleForeColor = System.Drawing.Color.Black;
            this.bunifuToolTip1.ToolTipPosition = new System.Drawing.Point(0, 0);
            this.bunifuToolTip1.ToolTipTitle = null;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.Header;
            this.bunifuDragControl1.Vertical = true;
            // 
            // SearchForUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 402);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SearchForUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "SearchForUpdate";
            this.Load += new System.EventHandler(this.SearchForUpdate_Load);
            this.Header.ResumeLayout(false);
            this.Header.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TitlePic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel Header;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton4;
        private System.Windows.Forms.PictureBox TitlePic;
        private System.Windows.Forms.Label TitleLb;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuDropdown SearchBrand;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuDropdown SearchModel;
        private System.Windows.Forms.FlowLayoutPanel Results;
        private Bunifu.UI.WinForms.BunifuToolTip bunifuToolTip1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
    }
}