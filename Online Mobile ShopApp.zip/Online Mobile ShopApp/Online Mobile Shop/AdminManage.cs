﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Online_Mobile_Shop_Model;
using Online_Mobile_Shop_Data_Emlpement;
namespace Online_Mobile_Shop
{
    public partial class AdminManage : Form
    {
        List<Panel> panels = new List<Panel>();
        int panel,Productid;
        string addfilename=null;
        byte[] updateimage;
        Product product = new Product();
        AdminManagement management = new AdminManagement();
        Image ConvertByteToImage(byte[] data)
        {
            using (MemoryStream memory = new MemoryStream(data))
            {
                return Image.FromStream(memory);
            }
        }
        byte[] COnvertImageToByte(String image)
        {
            byte[] img = null;
            FileStream fs = new FileStream(image, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            img = br.ReadBytes((int)fs.Length);
            return img;
        }
        public AdminManage()
        {
            InitializeComponent();
            panels.Add(AddProductPanel);
            panels.Add(UpdateProductPanel);
            panels.Add(DeleteProductPanel);
            panels[0].BringToFront();
            panel = 0;
        }
        public void SuccessLogin()
        {
            Form1.islogin = true;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
            this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
            this.pictureBox2.Visible = true;
            this.pictureBox3.Visible = true;
            if (UserLogin.dt.Type == Types.Admin)
            {
                this.AdminButton.Visible = true;
            }

        }
        public void SuccessLogout()
        {
            Form1.islogin = false;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.bunifuToolTip1.SetToolTip(this.Login, "Login");
            this.pictureBox2.Visible = false;
            this.pictureBox3.Visible = false;
            this.AdminButton.Visible = false;
        }
        public void GetSearchData(int id)
        {
            product = management.GetDetailsById(id);
            this.network1Text.Text = product.Network;
            this.launch1Text.Text = product.Launch;
            this.quantity1Text.Text = product.Quantity.ToString();
            this.dimension1Text.Text = product.Dimension;
            this.weight1Text.Text = product.Weight;
            this.sim1Text.Text = product.Sim;
            this.display1Text.Text = product.Display;
            this.displaySize1Text.Text = product.DispalySize;
            this.resolution1Text.Text = product.Resolution;
            this.chipset1Text.Text = product.Chipset;
            this.ram1Text.Text = product.Ram;
            this.memory1Text.Text = product.Memory;
            this.camera1Text.Text = product.Camera;
            this.wlan1Text.Text = product.Wlan;
            this.bluetooth1Text.Text = product.Bluetooth;
            this.battery1Text.Text = product.Battery;
            this.color1Text.Text = product.Color;
            this.price1Text.Text = product.Price;
            this.warranty1Text.Text = product.Warranty;
            this.model1Text.Text = product.Model;
            this.brand1Text.Text = product.Brand;
            Productid = product.productId;
            this.UpdateProductImage.Image = ConvertByteToImage(product.Image);
            this.updateimage = product.Image;
            this.network1Text.Enabled = true;
            this.launch1Text.Enabled = true;
            this.quantity1Text.Enabled = true;
            this.dimension1Text.Enabled = true;
            this.weight1Text.Enabled = true;
            this.sim1Text.Enabled = true;
            this.display1Text.Enabled = true;
            this.displaySize1Text.Enabled = true;
            this.resolution1Text.Enabled = true;
            this.chipset1Text.Enabled = true;
            this.ram1Text.Enabled = true;
            this.memory1Text.Enabled = true;
            this.camera1Text.Enabled = true;
            this.wlan1Text.Enabled = true;
            this.bluetooth1Text.Enabled = true;
            this.battery1Text.Enabled = true;
            this.color1Text.Enabled = true;
            this.price1Text.Enabled = true;
            this.warranty1Text.Enabled = true;
            this.model1Text.Enabled = true;
            this.brand1Text.Enabled = true;
            this.bunifuButton7.Enabled = true;

        }

        internal void GetSearchDataForDelete(int id)
        {
            product = management.GetDetailsById(id);
            this.network2Text.Text = product.Network;
            this.launch2Text.Text = product.Launch;
            this.quantity2Text.Text = product.Quantity.ToString();
            this.dimension2Text.Text = product.Dimension;
            this.weight2Text.Text = product.Weight;
            this.sim2Text.Text = product.Sim;
            this.display2Text.Text = product.Display;
            this.displaySize2Text.Text = product.DispalySize;
            this.resolution2Text.Text = product.Resolution;
            this.chipset2Text.Text = product.Chipset;
            this.ram2Text.Text = product.Ram;
            this.memory2Text.Text = product.Memory;
            this.camera2Text.Text = product.Camera;
            this.wlan2Text.Text = product.Wlan;
            this.bluetooth2Text.Text = product.Bluetooth;
            this.battery2Text.Text = product.Battery;
            this.color2Text.Text = product.Color;
            this.price2Text.Text = product.Price;
            this.warranty2Text.Text = product.Warranty;
            this.model2Text.Text = product.Model;
            this.brand2Text.Text = product.Brand;
            Productid = product.productId;
            this.deleteProductImage.Image = ConvertByteToImage(product.Image);
        }

        private void BunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BunifuI1mageButton4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 50)
            {
                Form1.menu = true;
                Sidebar.Visible = true;
                Sidebar.Width = 220;
                this.Width = 1080;
                bunifuTransitionOnShow.ShowSync(Sidebar);
            }
            else
            {
                Form1.menu = true;
                Sidebar.Width = 50;
                Sidebar.Visible = false;
                this.Width = 1080 - 50;
                bunifuTransitionOnHide.ShowSync(Sidebar);
            }
        }
        private void Login_Click(object sender, EventArgs e)
        {
            if (!Form1.islogin)
            {
                UserLogin login = new UserLogin();
                login.Show();
                this.Close();
            }
            else
            {
                SuccessLogout();
            }
        }
        private void AdminManage_Load(object sender, EventArgs e)
        {
            if (Form1.menu)
            {
                if (Sidebar.Width == 50)
                {
                    Form1.menu = true;
                    Sidebar.Visible = true;
                    Sidebar.Width = 220;
                    this.Width = 1080;
                    bunifuTransitionOnShow.ShowSync(Sidebar);
                }
                else
                {
                    Form1.menu = true;
                    Sidebar.Width = 50;
                    Sidebar.Visible = false;
                    this.Width = 1080 - 50;
                    bunifuTransitionOnHide.ShowSync(Sidebar);
                }
            }
            if (Form1.islogin)
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
                this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
                this.pictureBox2.Visible = true;
                this.pictureBox3.Visible = true;
                this.OrderHistorys.Visible = true;
                if (UserLogin.dt.Type == Types.Admin)
                {
                    this.AdminButton.Visible = true;
                }
            }
            else
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
                this.bunifuToolTip1.SetToolTip(this.Login, "Login");
                this.pictureBox2.Visible = false;
                this.pictureBox3.Visible = false;
                this.AdminButton.Visible = false;
                this.OrderHistorys.Visible = false;
            }
            this.BrandcomboBox.Items.Clear();
            List<string> brands = management.FetchBrand();
            foreach (var bnd in brands)
            {
                this.BrandcomboBox.Items.Add(bnd);
            }
        }

        private void AddProduct_Click(object sender, EventArgs e)
        {
            this.BrandcomboBox.Items.Clear();
            List<string> brands = management.FetchBrand();
            foreach(var bnd in brands)
            {
                this.BrandcomboBox.Items.Add(bnd);
            }
            if(panel!=0)
            {
                addfilename = null;
                this.networkText.Text = null;
                this.launchText.Text = null;
                this.QuantityText.Text = null;
                this.dimensionText.Text = null;
                this.weightText.Text = null;
                this.simText.Text = null;
                this.displayText.Text = null;
                this.display_sizeText.Text = null;
                this.resolutionText.Text = null;
                this.chipsetText.Text = null;
                this.ramText.Text = null;
                this.memoryText.Text = null;
                this.cameraText.Text = null;
                this.wlanText.Text = null;
                this.bluetoothText.Text = null;
                this.batteryText.Text = null;
                this.colorText.Text = null;
                this.priceText.Text = null;
                this.warrantyText.Text = null;
                this.modelText.Text = null;
                this.brandText.Text = null;
                this.ProductImage.Image = null;
                panels[0].BringToFront();
                panel = 0;


            }
            AddProductBar.BackColor = Color.DodgerBlue;
            UpdateProductBar.BackColor = Color.Silver;
            DeleteProductBar.BackColor = Color.Silver;
        }

        private void UpdateProduct_Click(object sender, EventArgs e)
        {
            this.BrandComboBox1.Enabled = false;
            this.BrandComboBox1.Items.Clear();
            this.BrandComboBox1.BeginUpdate();
            List<string> brands = management.FetchBrand();
            foreach (var bnd in brands)
            {
                this.BrandComboBox1.Items.Add(bnd);
            }
            this.network1Text.Enabled = false;
            this.launch1Text.Enabled = false;
            this.quantity1Text.Enabled = false;
            this.dimension1Text.Enabled = false;
            this.weight1Text.Enabled = false;
            this.sim1Text.Enabled = false;
            this.display1Text.Enabled = false;
            this.displaySize1Text.Enabled = false;
            this.resolution1Text.Enabled = false;
            this.chipset1Text.Enabled = false;
            this.ram1Text.Enabled = false;
            this.memory1Text.Enabled = false;
            this.camera1Text.Enabled = false;
            this.wlan1Text.Enabled = false;
            this.bluetooth1Text.Enabled = false;
            this.battery1Text.Enabled = false;
            this.color1Text.Enabled = false;
            this.price1Text.Enabled = false;
            this.warranty1Text.Enabled = false;
            this.model1Text.Enabled = false;
            this.brand1Text.Enabled = false;
            this.bunifuButton7.Enabled = false;
            if (panel!=1)
            {
                addfilename = null;
                this.network1Text.Text = null;
                this.launch1Text.Text = null;
                this.quantity1Text.Text = null;
                this.dimension1Text.Text = null;
                this.weight1Text.Text = null;
                this.sim1Text.Text = null;
                this.display1Text.Text = null;
                this.displaySize1Text.Text = null;
                this.resolution1Text.Text = null;
                this.chipset1Text.Text = null;
                this.ram1Text.Text = null;
                this.memory1Text.Text = null;
                this.camera1Text.Text = null;
                this.wlan1Text.Text = null;
                this.bluetooth1Text.Text = null;
                this.battery1Text.Text = null;
                this.color1Text.Text = null;
                this.price1Text.Text = null;
                this.warranty1Text.Text = null;
                this.model1Text.Text = null;
                this.brand1Text.Text = null;
                this.UpdateProductImage.Image = null;
                panels[1].BringToFront();
                panel = 1;
            }
            
            AddProductBar.BackColor = Color.Silver;
            UpdateProductBar.BackColor = Color.DodgerBlue;
            DeleteProductBar.BackColor = Color.Silver;
        }

        private void DeleteProduct_Click(object sender, EventArgs e)
        {
            if(panel!=2)
            {
                this.network2Text.Text = null;
                this.launch2Text.Text = null;
                this.quantity2Text.Text = null;
                this.dimension2Text.Text = null;
                this.weight2Text.Text = null;
                this.sim2Text.Text = null;
                this.display2Text.Text = null;
                this.displaySize2Text.Text = null;
                this.resolution2Text.Text = null;
                this.chipset2Text.Text = null;
                this.ram2Text.Text = null;
                this.memory2Text.Text = null;
                this.camera2Text.Text = null;
                this.wlan2Text.Text = null;
                this.bluetooth2Text.Text = null;
                this.battery2Text.Text = null;
                this.color2Text.Text = null;
                this.price2Text.Text = null;
                this.warranty2Text.Text = null;
                this.model2Text.Text = null;
                this.brand2Text.Text = null;
                this.deleteProductImage.Image = null;
                panels[2].BringToFront();
                panel = 2;
            }
            AddProductBar.BackColor = Color.Silver;
            UpdateProductBar.BackColor = Color.Silver;
            DeleteProductBar.BackColor = Color.DodgerBlue;
        }

        private void BunifuButton4_Click(object sender, EventArgs e)
        {
            
            using(OpenFileDialog ofd = new OpenFileDialog() { Filter = "JPEG| *.jpg", ValidateNames = true, Multiselect = false })
            {
                if(ofd.ShowDialog()==DialogResult.OK)
                {
                    addfilename = ofd.FileName;
                    ProductImage.Image = Image.FromFile(addfilename);
                }
            }
        }

        private void BunifuButton5_Click(object sender, EventArgs e)
        {
            bool addproduct = true;
            if (string.IsNullOrEmpty(networkText.Text))
            {
                MessageBox.Show("Networn Info Is Impty");
                addproduct = false;
                networkText.Focus();
            }
            else if (string.IsNullOrEmpty(launchText.Text))
            {
                MessageBox.Show("launch date Is Impty");
                addproduct = false;
                launchText.Focus();
            }
            else if (string.IsNullOrEmpty(QuantityText.Text))
            {
                MessageBox.Show("Quantity Is Impty");
                addproduct = false;
                QuantityText.Focus();
            }
            else if (string.IsNullOrEmpty(dimensionText.Text))
            {
                MessageBox.Show("dimension Info Is Impty");
                addproduct = false;
                dimensionText.Focus();
            }
            else if (string.IsNullOrEmpty(weightText.Text))
            {
                MessageBox.Show("weight Info Is Impty");
                addproduct = false;
                weightText.Focus();
            }
            else if (string.IsNullOrEmpty(simText.Text))
            {
                MessageBox.Show("sim Info Is Impty");
                addproduct = false;
                simText.Focus();
            }
            else if (string.IsNullOrEmpty(displayText.Text))
            {
                MessageBox.Show("display Info Is Impty");
                addproduct = false;
                displayText.Focus();
            }
            else if (string.IsNullOrEmpty(display_sizeText.Text))
            {
                MessageBox.Show("display_size Info Is Impty");
                addproduct = false;
                display_sizeText.Focus();
            }
            else if (string.IsNullOrEmpty(resolutionText.Text))
            {
                MessageBox.Show("resolution Info Is Impty");
                addproduct = false;
                resolutionText.Focus();
            }
            else if (string.IsNullOrEmpty(chipsetText.Text))
            {
                MessageBox.Show("chipset Info Is Impty");
                addproduct = false;
                chipsetText.Focus();
            }
            else if (string.IsNullOrEmpty(ramText.Text))
            {
                MessageBox.Show("ram Info Is Impty");
                addproduct = false;
                ramText.Focus();
            }
            else if (string.IsNullOrEmpty(memoryText.Text))
            {
                MessageBox.Show("memory Info Is Impty");
                addproduct = false;
                memoryText.Focus();
            }
            else if (string.IsNullOrEmpty(cameraText.Text))
            {
                MessageBox.Show("camera Info Is Impty");
                addproduct = false;
                cameraText.Focus();
            }
            else if (string.IsNullOrEmpty(wlanText.Text))
            {
                MessageBox.Show("wlan Info Is Impty");
                addproduct = false;
                wlanText.Focus();

            }
            else if (string.IsNullOrEmpty(bluetoothText.Text))
            {
                MessageBox.Show("bluetooth Info Is Impty");
                addproduct = false;
                bluetoothText.Focus();
            }
            else if (string.IsNullOrEmpty(batteryText.Text))
            {
                MessageBox.Show("battery Info Is Impty");
                addproduct = false;
                batteryText.Focus();
            }
            else if (string.IsNullOrEmpty(colorText.Text))
            {
                MessageBox.Show("color Info Is Impty");
                addproduct = false;
                colorText.Focus();
            }
            else if (string.IsNullOrEmpty(priceText.Text))
            {
                MessageBox.Show("price Info Is Impty");
                addproduct = false;
                priceText.Focus();
            }
            else if (string.IsNullOrEmpty(warrantyText.Text))
            {
                MessageBox.Show("warranty Info Is Impty");
                addproduct = false;
                warrantyText.Focus();
            }
            else if (string.IsNullOrEmpty(modelText.Text))
            {
                MessageBox.Show("model Info Is Impty");
                addproduct = false;
                modelText.Focus();
            }
            else if (string.IsNullOrEmpty(brandText.Text))
            {
                if(bunifuCheckBox1.Checked)
                {
                    MessageBox.Show("Select An Existing Brand From Dropdown List Or Uncheck The Button and Add Brand Manualy");
                    addproduct = false;
                    BrandcomboBox.Focus();
                }
                else if(!bunifuCheckBox1.Checked)
                {
                    MessageBox.Show("brand Info Is Impty");
                    addproduct = false;
                    brandText.Focus();
                }
            }
            else if (ProductImage.Image == null)
            {
                MessageBox.Show("Select a Product Image","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                addproduct = false;
                BunifuButton4_Click(sender, e);
            }
           
            if(addproduct)
            {
                int oper;
                product.Battery = batteryText.Text;
                product.Bluetooth = bluetoothText.Text;
                product.Brand = brandText.Text;
                product.Camera = cameraText.Text;
                product.Chipset = chipsetText.Text;
                product.Color = colorText.Text;
                product.Dimension = dimensionText.Text;
                product.DispalySize = display_sizeText.Text;
                product.Display = displayText.Text;
                product.Launch = launchText.Text;
                product.Memory = memoryText.Text;
                product.Model = modelText.Text;
                product.Network = networkText.Text;
                product.Price = priceText.Text;
                product.Quantity = Convert.ToInt32(QuantityText.Text);
                product.Ram = ramText.Text;
                product.Resolution = resolutionText.Text;
                product.Sim = simText.Text;
                product.Warranty = warrantyText.Text;
                product.Weight = weightText.Text;
                product.Wlan = wlanText.Text;
                product.Image = COnvertImageToByte(addfilename);

                oper = management.AddProductToDatabase(product);
                if (oper==0)
                {
                    MessageBox.Show("Product Can Not Add", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if(oper==1)
                {
                    MessageBox.Show("Product Added Successfull", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.networkText.Text = null;
                    this.launchText.Text = null;
                    this.QuantityText.Text = null;
                    this.dimensionText.Text = null;
                    this.weightText.Text = null;
                    this.simText.Text = null;
                    this.displayText.Text = null;
                    this.display_sizeText.Text = null;
                    this.resolutionText.Text = null;
                    this.chipsetText.Text = null;
                    this.ramText.Text = null;
                    this.memoryText.Text = null;
                    this.cameraText.Text = null;
                    this.wlanText.Text = null;
                    this.bluetoothText.Text = null;
                    this.batteryText.Text = null;
                    this.colorText.Text = null;
                    this.priceText.Text = null;
                    this.warrantyText.Text = null;
                    this.modelText.Text = null;
                    this.brandText.Text = null;
                    this.ProductImage.Image = null;
                }

                else if(oper==1111)
                {
                    MessageBox.Show("Server Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            

                    
            }
        }

        private void BunifuButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature Will Comming Soon","Future Update",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void BunifuCheckBox1_CheckedChanged(object sender, Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs e)
        {
            if(bunifuCheckBox1.Checked)
            {
                this.BrandcomboBox.Enabled = true;
                this.brandText.ReadOnly = true;
                this.brandText.Enabled = false;
            }
            else if (!bunifuCheckBox1.Checked)
            {
                this.BrandcomboBox.Enabled = false;
                this.brandText.ReadOnly = false;
                this.brandText.Enabled = true;
            }
        }

        private void BrandcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.brandText.Text = this.BrandcomboBox.SelectedItem.ToString();
        }

        private void BrandText_KeyPress(object sender, KeyPressEventArgs e)
        {
            var item = (PlaceholderTextBox)sender;
            if(item.PlaceholderText.Trim().ToLower().Equals("network".Trim().ToLower()) && e.KeyChar==(char)Keys.Enter)
            {
                this.launchText.Focus();
            }
           else if (item.PlaceholderText.Trim().ToLower().Equals("launch date".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                QuantityText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("quantity".Trim().ToLower()))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    dimensionText.Focus();
                }
                else if ((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) || (e.KeyChar == '.'))
                {
                    MessageBox.Show("Only Numbers are allowed", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Handled = true;
                }
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("dimension".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                weightText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("weight".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                simText.Focus();

            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("sim".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                displayText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("display".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                display_sizeText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("display_size".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                resolutionText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("resolution".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                chipsetText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("chipset".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                ramText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("ram".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                memoryText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("memory".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                cameraText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("camera".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                wlanText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("wlan".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                bluetoothText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("bluetooth".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                batteryText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("battery".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                colorText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("color".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                priceText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("price".Trim().ToLower()))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    warrantyText.Focus();
                }
                else if ((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) || (e.KeyChar == '.'))
                {
                    MessageBox.Show("Only Numbers are allowed", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Handled = true;
                }
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("warranty".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                modelText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("model".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                brandText.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("brand".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                BunifuButton5_Click(sender, e);
            }
            
        }

        private void BunifuButton7_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "JPEG| *.jpg", ValidateNames = true, Multiselect = false })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    addfilename = ofd.FileName;
                    UpdateProductImage.Image = Image.FromFile(addfilename);
                }
            }
        }

        private void BunifuButton8_Click(object sender, EventArgs e)
        {
            SearchForUpdate forUpdate = new SearchForUpdate("Search For Update","update",this);
            forUpdate.Show();
        }

        private void BunifuCheckBox2_CheckedChanged(object sender, Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs e)
        {
            if(bunifuCheckBox2.Checked)
            {
                this.BrandComboBox1.Enabled = true;
                this.brand1Text.Enabled = false;
            }
            else if(!bunifuCheckBox2.Checked)
            {
                this.BrandComboBox1.Enabled = false;
                this.brand1Text.Enabled = true;
            }
        }

        private void BrandComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.brand1Text.Text = this.BrandComboBox1.SelectedItem.ToString();
        }

        private void BunifuButton9_Click(object sender, EventArgs e)
        {
            SearchForUpdate forUpdate = new SearchForUpdate("Search For Delete", "delete", this);
            forUpdate.Show();
        }

        private void BunifuButton6_Click(object sender, EventArgs e)
        {
            bool addproduct = true;
            if (string.IsNullOrEmpty(network2Text.Text))
            {
                MessageBox.Show("Networn Info Is Impty");
                addproduct = false;
                network2Text.Focus();
            }
            else if (string.IsNullOrEmpty(launch2Text.Text))
            {
                MessageBox.Show("launch date Is Impty");
                addproduct = false;
                launch2Text.Focus();
            }
            else if (string.IsNullOrEmpty(quantity2Text.Text))
            {
                MessageBox.Show("Quantity Is Impty");
                addproduct = false;
                quantity2Text.Focus();
            }
            else if (string.IsNullOrEmpty(dimension2Text.Text))
            {
                MessageBox.Show("dimension Info Is Impty");
                addproduct = false;
                dimension2Text.Focus();
            }
            else if (string.IsNullOrEmpty(weight2Text.Text))
            {
                MessageBox.Show("weight Info Is Impty");
                addproduct = false;
                weight2Text.Focus();
            }
            else if (string.IsNullOrEmpty(sim2Text.Text))
            {
                MessageBox.Show("sim Info Is Impty");
                addproduct = false;
                sim2Text.Focus();
            }
            else if (string.IsNullOrEmpty(display2Text.Text))
            {
                MessageBox.Show("display Info Is Impty");
                addproduct = false;
                display2Text.Focus();
            }
            else if (string.IsNullOrEmpty(displaySize2Text.Text))
            {
                MessageBox.Show("display_size Info Is Impty");
                addproduct = false;
                displaySize2Text.Focus();
            }
            else if (string.IsNullOrEmpty(resolution2Text.Text))
            {
                MessageBox.Show("resolution Info Is Impty");
                addproduct = false;
                resolution2Text.Focus();
            }
            else if (string.IsNullOrEmpty(chipset2Text.Text))
            {
                MessageBox.Show("chipset Info Is Impty");
                addproduct = false;
                chipset2Text.Focus();
            }
            else if (string.IsNullOrEmpty(ram2Text.Text))
            {
                MessageBox.Show("ram Info Is Impty");
                addproduct = false;
                ram2Text.Focus();
            }
            else if (string.IsNullOrEmpty(memory2Text.Text))
            {
                MessageBox.Show("memory Info Is Impty");
                addproduct = false;
                memory2Text.Focus();
            }
            else if (string.IsNullOrEmpty(camera2Text.Text))
            {
                MessageBox.Show("camera Info Is Impty");
                addproduct = false;
                camera2Text.Focus();
            }
            else if (string.IsNullOrEmpty(wlan2Text.Text))
            {
                MessageBox.Show("wlan Info Is Impty");
                addproduct = false;
                wlan2Text.Focus();

            }
            else if (string.IsNullOrEmpty(bluetooth2Text.Text))
            {
                MessageBox.Show("bluetooth Info Is Impty");
                addproduct = false;
                bluetooth2Text.Focus();
            }
            else if (string.IsNullOrEmpty(battery2Text.Text))
            {
                MessageBox.Show("battery Info Is Impty");
                addproduct = false;
                battery2Text.Focus();
            }
            else if (string.IsNullOrEmpty(color2Text.Text))
            {
                MessageBox.Show("color Info Is Impty");
                addproduct = false;
                color2Text.Focus();
            }
            else if (string.IsNullOrEmpty(price2Text.Text))
            {
                MessageBox.Show("price Info Is Impty");
                addproduct = false;
                price2Text.Focus();
            }
            else if (string.IsNullOrEmpty(warranty2Text.Text))
            {
                MessageBox.Show("warranty Info Is Impty");
                addproduct = false;
                warranty2Text.Focus();
            }
            else if (string.IsNullOrEmpty(model2Text.Text))
            {
                MessageBox.Show("model Info Is Impty");
                addproduct = false;
                model2Text.Focus();
            }
            else if (string.IsNullOrEmpty(brand2Text.Text))
            {
                    MessageBox.Show("brand Info Is Impty");
                    addproduct = false;
                    brand1Text.Focus();
            
            }
            if(addproduct)
            {
                if(MessageBox.Show("Are You Confirm to Delete This Product?","Warning",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
                {
                    int delete = management.DeleteProductById(Productid);
                    if (delete == 0)
                    {
                        MessageBox.Show("Product Can Not Delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (delete == 1)
                    {
                        MessageBox.Show("Product Deleted Successfull", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.network2Text.Text = null;
                        this.launch2Text.Text = null;
                        this.quantity2Text.Text = null;
                        this.dimension2Text.Text = null;
                        this.weight2Text.Text = null;
                        this.sim2Text.Text = null;
                        this.display2Text.Text = null;
                        this.displaySize2Text.Text = null;
                        this.resolution2Text.Text = null;
                        this.chipset2Text.Text = null;
                        this.ram2Text.Text = null;
                        this.memory2Text.Text = null;
                        this.camera2Text.Text = null;
                        this.wlan2Text.Text = null;
                        this.bluetooth2Text.Text = null;
                        this.battery2Text.Text = null;
                        this.color2Text.Text = null;
                        this.price2Text.Text = null;
                        this.warranty2Text.Text = null;
                        this.model2Text.Text = null;
                        this.brand2Text.Text = null;
                        this.deleteProductImage.Image = null;
                    }

                    else if (delete == 1111)
                    {
                        MessageBox.Show("Server Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void Brand2Text_KeyDown(object sender, KeyEventArgs e)
        {
            var value = (PlaceholderTextBox)sender;
            if(value.Text.Trim().Equals(""))
            {
                MessageBox.Show("Select Product By Search for delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(!value.Text.Trim().Equals(""))
            {
                MessageBox.Show("You Can Not Edit If Want TO Edit GO TO UPDATE SECTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Brand2Text_KeyDown(object sender, EventArgs e)
        {
            var value = (Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox)sender;
            if (value.Text.Trim().Equals(""))
            {
                MessageBox.Show("Select Product By Search for delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!value.Text.Trim().Equals(""))
            {
                MessageBox.Show("You Can Not Edit If Want TO Edit GO TO UPDATE SECTION", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Brand1Text_KeyPress(object sender, KeyPressEventArgs e)
        {
            var item = (PlaceholderTextBox)sender;
            if (item.PlaceholderText.Trim().ToLower().Equals("network".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                this.launch1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("launch date".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                quantity1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("quantity".Trim().ToLower()))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    dimension1Text.Focus();
                }
                else if ((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) || (e.KeyChar == '.'))
                {
                    MessageBox.Show("Only Numbers are allowed", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Handled = true;
                }
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("dimension".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                weight1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("weight".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                sim1Text.Focus();

            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("sim".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                display1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("display".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                displaySize1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("display_size".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                resolution1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("resolution".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                chipset1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("chipset".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                ram1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("ram".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                memory1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("memory".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                camera1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("camera".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                wlan1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("wlan".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                bluetooth1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("bluetooth".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                battery1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("battery".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                color1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("color".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                price1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("price".Trim().ToLower()))
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    warranty1Text.Focus();
                }
                else if ((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) || (e.KeyChar == '.'))
                {
                    MessageBox.Show("Only Numbers are allowed", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Handled = true;
                }
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("warranty".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                model1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("model".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                brand1Text.Focus();
            }
            else if (item.PlaceholderText.Trim().ToLower().Equals("brand".Trim().ToLower()) && e.KeyChar == (char)Keys.Enter)
            {
                BunifuButton5_Click(sender, e);
            }
        }

        private void Quantity1Text_Leave(object sender, EventArgs e)
        {
            var value = (Bunifu.UI.WinForms.BunifuButton.BunifuButton)sender;
            int number;
            if(!int.TryParse(value.Text ,out number))
            {
                MessageBox.Show("Only Numbers Are Allowed", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                value.Text = null;
            }
        }

        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }

        private void BunifuButton2_Click(object sender, EventArgs e)
        {
            MoblieList mobile = new MoblieList();
            mobile.Show();
            this.Close();
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            UserCart userCart = new UserCart(ProductDetails.carts);
            userCart.Show();
            this.Close();
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            WishList wishList = new WishList(new Orders().GetWishList(UserLogin.dt.userId));
            this.Hide();
            wishList.Show();
        }

        private void OrderHistory_Click(object sender, EventArgs e)
        {
            OrderHistory orderHistory = new OrderHistory();
            this.Hide();
            orderHistory.Show();
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            Search search = new Search(bunifuTextBox1.Text);
            this.Hide();
            search.Show();
        }

        private void BunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==(char)Keys.Enter)
            {
                PictureBox5_Click(sender, e);
            }
        }

        private void UpdateProductBtn_Click(object sender, EventArgs e)
        {
            bool addproduct = true;
            if (string.IsNullOrEmpty(network1Text.Text))
            {
                MessageBox.Show("Networn Info Is Impty");
                addproduct = false;
                network1Text.Focus();
            }
            else if (string.IsNullOrEmpty(launch1Text.Text))
            {
                MessageBox.Show("launch date Is Impty");
                addproduct = false;
                launch1Text.Focus();
            }
            else if (string.IsNullOrEmpty(quantity1Text.Text))
            {
                MessageBox.Show("Quantity Is Impty");
                addproduct = false;
                quantity1Text.Focus();
            }
            else if (string.IsNullOrEmpty(dimension1Text.Text))
            {
                MessageBox.Show("dimension Info Is Impty");
                addproduct = false;
                dimension1Text.Focus();
            }
            else if (string.IsNullOrEmpty(weight1Text.Text))
            {
                MessageBox.Show("weight Info Is Impty");
                addproduct = false;
                weight1Text.Focus();
            }
            else if (string.IsNullOrEmpty(sim1Text.Text))
            {
                MessageBox.Show("sim Info Is Impty");
                addproduct = false;
                sim1Text.Focus();
            }
            else if (string.IsNullOrEmpty(display1Text.Text))
            {
                MessageBox.Show("display Info Is Impty");
                addproduct = false;
                display1Text.Focus();
            }
            else if (string.IsNullOrEmpty(displaySize1Text.Text))
            {
                MessageBox.Show("display_size Info Is Impty");
                addproduct = false;
                displaySize1Text.Focus();
            }
            else if (string.IsNullOrEmpty(resolution1Text.Text))
            {
                MessageBox.Show("resolution Info Is Impty");
                addproduct = false;
                resolution1Text.Focus();
            }
            else if (string.IsNullOrEmpty(chipset1Text.Text))
            {
                MessageBox.Show("chipset Info Is Impty");
                addproduct = false;
                chipset1Text.Focus();
            }
            else if (string.IsNullOrEmpty(ram1Text.Text))
            {
                MessageBox.Show("ram Info Is Impty");
                addproduct = false;
                ram1Text.Focus();
            }
            else if (string.IsNullOrEmpty(memory1Text.Text))
            {
                MessageBox.Show("memory Info Is Impty");
                addproduct = false;
                memory1Text.Focus();
            }
            else if (string.IsNullOrEmpty(camera1Text.Text))
            {
                MessageBox.Show("camera Info Is Impty");
                addproduct = false;
                camera1Text.Focus();
            }
            else if (string.IsNullOrEmpty(wlan1Text.Text))
            {
                MessageBox.Show("wlan Info Is Impty");
                addproduct = false;
                wlan1Text.Focus();

            }
            else if (string.IsNullOrEmpty(bluetooth1Text.Text))
            {
                MessageBox.Show("bluetooth Info Is Impty");
                addproduct = false;
                bluetooth1Text.Focus();
            }
            else if (string.IsNullOrEmpty(battery1Text.Text))
            {
                MessageBox.Show("battery Info Is Impty");
                addproduct = false;
                battery1Text.Focus();
            }
            else if (string.IsNullOrEmpty(color1Text.Text))
            {
                MessageBox.Show("color Info Is Impty");
                addproduct = false;
                color1Text.Focus();
            }
            else if (string.IsNullOrEmpty(price1Text.Text))
            {
                MessageBox.Show("price Info Is Impty");
                addproduct = false;
                price1Text.Focus();
            }
            else if (string.IsNullOrEmpty(warranty1Text.Text))
            {
                MessageBox.Show("warranty Info Is Impty");
                addproduct = false;
                warranty1Text.Focus();
            }
            else if (string.IsNullOrEmpty(model1Text.Text))
            {
                MessageBox.Show("model Info Is Impty");
                addproduct = false;
                model1Text.Focus();
            }
            else if (string.IsNullOrEmpty(brand1Text.Text))
            {
                if (bunifuCheckBox1.Checked)
                {
                    MessageBox.Show("Select An Existing Brand From Dropdown List Or Uncheck The Button and Add Brand Manualy");
                    addproduct = false;
                    BrandComboBox1.Focus();
                }
                else if (!bunifuCheckBox1.Checked)
                {
                    MessageBox.Show("brand Info Is Impty");
                    addproduct = false;
                    brand1Text.Focus();
                }
            }
            else if (UpdateProductImage.Image == null)
            {
                MessageBox.Show("Select a Product Image", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                addproduct = false;
                BunifuButton7_Click(sender, e);
            }

            if (addproduct)
            {
                int oper;
                product.productId = Productid;
                product.Battery = battery1Text.Text;
                product.Bluetooth = bluetooth1Text.Text;
                product.Brand = brand1Text.Text;
                product.Camera = camera1Text.Text;
                product.Chipset = chipset1Text.Text;
                product.Color = color1Text.Text;
                product.Dimension = dimension1Text.Text;
                product.DispalySize = displaySize1Text.Text;
                product.Display = display1Text.Text;
                product.Launch = launch1Text.Text;
                product.Memory = memory1Text.Text;
                product.Model = model1Text.Text;
                product.Network = network1Text.Text;
                product.Price = price1Text.Text;
                product.Quantity = Convert.ToInt32(quantity1Text.Text);
                product.Ram = ram1Text.Text;
                product.Resolution = resolution1Text.Text;
                product.Sim = sim1Text.Text;
                product.Warranty = warranty1Text.Text;
                product.Weight = weight1Text.Text;
                product.Wlan = wlan1Text.Text;
                if (addfilename == null)
                {
                    product.Image = updateimage;
                }
                else if (addfilename != null)
                {
                    product.Image = COnvertImageToByte(addfilename);
                }
                oper = management.UpdateProductToDatabase(product);
                if (oper == 0)
                {
                    MessageBox.Show("Product Can Not Update", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (oper == 1)
                {
                    MessageBox.Show("Product Updated Successfull", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.network1Text.Text = null;
                    this.launch1Text.Text = null;
                    this.quantity1Text.Text = null;
                    this.dimension1Text.Text = null;
                    this.weight1Text.Text = null;
                    this.sim1Text.Text = null;
                    this.display1Text.Text = null;
                    this.displaySize1Text.Text = null;
                    this.resolution1Text.Text = null;
                    this.chipset1Text.Text = null;
                    this.ram1Text.Text = null;
                    this.memory1Text.Text = null;
                    this.camera1Text.Text = null;
                    this.wlan1Text.Text = null;
                    this.bluetooth1Text.Text = null;
                    this.battery1Text.Text = null;
                    this.color1Text.Text = null;
                    this.price1Text.Text = null;
                    this.warranty1Text.Text = null;
                    this.model1Text.Text = null;
                    this.brand1Text.Text = null;
                    this.UpdateProductImage.Image = null;
                    UpdateProduct_Click(sender, e);

                }

                else if (oper == 1111)
                {
                    MessageBox.Show("Server Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }



            }
        }
    }
}
