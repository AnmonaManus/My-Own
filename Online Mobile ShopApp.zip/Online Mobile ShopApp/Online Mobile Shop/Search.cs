﻿using Online_Mobile_Shop_Data_Emlpement;
using Online_Mobile_Shop_Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Mobile_Shop
{
    public partial class Search : Form
    {
        SearchResult search = new SearchResult();
        public Search(string s)
        {
            InitializeComponent();
            ProductList(s);
        }
        Image ConvertByteToImage(byte[] data)
        {
            using (MemoryStream memory = new MemoryStream(data))
            {
                return Image.FromStream(memory);
            }
        }
        public void SuccessLogout()
        {
            Form1.islogin = false;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.bunifuToolTip1.SetToolTip(this.Login, "Login");
            this.pictureBox2.Visible = false;
            this.pictureBox3.Visible = false;
            this.AdminButton.Visible = false;
        }
        private void BunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BunifuI1mageButton4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 50)
            {
                Form1.menu = true;
                Sidebar.Visible = true;
                Sidebar.Width = 220;
                this.Width = 1080;
                bunifuTransitionOnShow.ShowSync(Sidebar);
            }
            else
            {
                Form1.menu = true;
                Sidebar.Width = 50;
                Sidebar.Visible = false;
                this.Width = 1080 - 50;
                bunifuTransitionOnHide.ShowSync(Sidebar);
            }
        }
        private void Login_Click(object sender, EventArgs e)
        {
            if (!Form1.islogin)
            {
                UserLogin login = new UserLogin();
                login.Show();
                this.Close();
            }
            else
            {
                SuccessLogout();
            }
        }
        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }
        private void AdminButton_Click(object sender, EventArgs e)
        {
            AdminManage admin = new AdminManage();
            this.Hide();
            admin.Show();
        }

        private void BunifuButton2_Click(object sender, EventArgs e)
        {
            MoblieList mobile = new MoblieList();
            mobile.Show();
            this.Close();
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            UserCart userCart = new UserCart(ProductDetails.carts);
            userCart.Show();
            this.Close();
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            WishList wishList = new WishList(new Orders().GetWishList(UserLogin.dt.userId));
            this.Hide();
            wishList.Show();
        }

        private void OrderHistory_Click(object sender, EventArgs e)
        {
            OrderHistory orderHistory = new OrderHistory();
            this.Hide();
            orderHistory.Show();
        }
        private void BunifuButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature Will Comming Soon", "Future Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void Search_Load(object sender, EventArgs e)
        {
            if (Form1.menu)
            {
                if (Sidebar.Width == 50)
                {
                    Form1.menu = true;
                    Sidebar.Visible = true;
                    Sidebar.Width = 220;
                    this.Width = 1080;
                    bunifuTransitionOnShow.ShowSync(Sidebar);
                }
                else
                {
                    Form1.menu = true;
                    Sidebar.Width = 50;
                    Sidebar.Visible = false;
                    this.Width = 1080 - 50;
                    bunifuTransitionOnHide.ShowSync(Sidebar);
                }
            }
            if (Form1.islogin)
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
                this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
                this.pictureBox2.Visible = true;
                this.pictureBox3.Visible = true;
                this.OrderHistorys.Visible = true;
                if (UserLogin.dt.Type == Types.Admin)
                {
                    this.AdminButton.Visible = true;
                }
            }
            else
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
                this.bunifuToolTip1.SetToolTip(this.Login, "Login");
                this.pictureBox2.Visible = false;
                this.pictureBox3.Visible = false;
                this.AdminButton.Visible = false;
                this.OrderHistorys.Visible = false;
            }

        }
        private void ProductList(String s)
        {
            ListofFlowSearch.Controls.Clear();
            List<Product> products = search.GetListOfProduct(s);
            Bunifu.UI.WinForms.BunifuButton.BunifuButton[] buttons = new Bunifu.UI.WinForms.BunifuButton.BunifuButton[products.Count];
            for (int i = 0; i < products.Count; i++)
            {
                buttons[i] = new Bunifu.UI.WinForms.BunifuButton.BunifuButton() { IdleBorderColor = Color.FromArgb(37, 49, 57), IdleFillColor = Color.FromArgb(37, 49, 57), Size = new Size(189, 189), IdleIconLeftImage = ConvertByteToImage(products[i].Image), Text = products[i].productId.ToString() };
                bunifuToolTip1.SetToolTip(buttons[i], $"{products[i].Brand} {products[i].Model} ");
                ListofFlowSearch.Controls.Add(buttons[i]);
                buttons[i].Click += MoblieList_Click;

            }
        }

        private void MoblieList_Click(object sender, EventArgs e)
        {
            var btn = (Bunifu.UI.WinForms.BunifuButton.BunifuButton)sender;
            Product product1 = search.GetProductById(Convert.ToInt32(btn.Text));
            ProductDetails productDetails = new ProductDetails(product1);
            this.Hide();
            productDetails.Show();
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            ProductList(bunifuTextBox1.Text);
        }

        private void BunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                PictureBox5_Click(sender, e);
            }
        }
    }
}
