﻿using Online_Mobile_Shop_Data_Emlpement;
using Online_Mobile_Shop_Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Mobile_Shop
{
    public partial class ProductDetails : Form
    {
        Product product;
       public static List<Cart> carts = new List<Cart>();
        ManageWishList wishList = new ManageWishList();
        public ProductDetails(Product _product)
        {
            InitializeComponent();
            product = _product;
        }
        private void ProductDetails_Load(object sender, EventArgs e)
        {
            if (Form1.menu)
            {
                if (Sidebar.Width == 50)
                {
                    Form1.menu = true;
                    Sidebar.Visible = true;
                    Sidebar.Width = 220;
                    this.Width = 1080;
                    bunifuTransitionOnShow.ShowSync(Sidebar);
                }
                else
                {
                    Form1.menu = true;
                    Sidebar.Width = 50;
                    Sidebar.Visible = false;
                    this.Width = 1080 - 50;
                    bunifuTransitionOnHide.ShowSync(Sidebar);
                }
            }
            if (Form1.islogin)
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
                this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
                this.pictureBox2.Visible = true;
                this.pictureBox3.Visible = true;
                this.OrderHistorys.Visible = true;
                if (UserLogin.dt.Type == Types.Admin)
                {
                    this.AdminButton.Visible = true;
                }
            }
            else
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
                this.bunifuToolTip1.SetToolTip(this.Login, "Login");
                this.pictureBox2.Visible = false;
                this.pictureBox3.Visible = false;
                this.AdminButton.Visible = false;
                this.OrderHistorys.Visible = false;
            }
            SetValue();
        }
        public void SuccessLogin()
        {
            Form1.islogin = true;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
            this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
            this.pictureBox2.Visible = true;
            this.pictureBox3.Visible = true;
            if (UserLogin.dt.Type == Types.Admin)
            {
                this.AdminButton.Visible = true;
            }

        }
        public void SuccessLogout()
        {
            Form1.islogin = false;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.bunifuToolTip1.SetToolTip(this.Login, "Login");
            this.pictureBox2.Visible = false;
            this.pictureBox3.Visible = false;
            this.AdminButton.Visible = false;
        }
        private void BunifuButton2_Click(object sender, EventArgs e)
        {
            MoblieList mobile = new MoblieList();
            this.Hide();
            mobile.Show();
        }
        private void AdminButton_Click(object sender, EventArgs e)
        {
            AdminManage admin = new AdminManage();
            this.Hide();
            admin.Show();
        }
        private void BunifuButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature Will Comming Soon", "Future Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void BunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BunifuI1mageButton4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void Login_Click(object sender, EventArgs e)
        {
            if (!Form1.islogin)
            {
                UserLogin login = new UserLogin();
                this.Hide();
                login.Show();
            }
            else
            {
                SuccessLogout();
            }
        }
        Image ConvertByteToImage(byte[] data)
        {
            using (MemoryStream memory = new MemoryStream(data))
            {
                return Image.FromStream(memory);
            }
        }
        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 50)
            {
                Form1.menu = true;
                Sidebar.Visible = true;
                Sidebar.Width = 220;
                this.Width = 1080;
                bunifuTransitionOnShow.ShowSync(Sidebar);
            }
            else
            {
                Form1.menu = true;
                Sidebar.Width = 50;
                Sidebar.Visible = false;
                this.Width = 1080 - 50;
                bunifuTransitionOnHide.ShowSync(Sidebar);
            }
        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {
            if(!Form1.islogin)
            {
                MessageBox.Show("This Feature Only For Registered User", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if(Form1.islogin)
            {
                int oper = wishList.AddDataToWishList(UserLogin.dt.userId, product.productId);
                if(oper==1)
                {
                    MessageBox.Show("Added To Wishlist", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if(oper==2)
                {
                    MessageBox.Show("Already Added To WishList", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (oper == 0)
                {
                    MessageBox.Show("Can Not Added To WishList Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (oper == 1111)
                {
                    MessageBox.Show("Server Error Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if(oper==3)
                {
                    MessageBox.Show("Server Is Busy Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                    
            }
        }

        private void BunifuButton4_Click(object sender, EventArgs e)
        {
            if(!Form1.islogin)
            {
                MessageBox.Show("This Feature Only For Registered User", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (Convert.ToInt32(this.QuantityLabel.Text) == 0)
                {
                    MessageBox.Show("Select Quantity First", "Invalied Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    try
                    {
                        using (Cart cart = new Cart())
                        {
                            cart.ProductId = product.productId;
                            cart.Brand = product.Brand;
                            cart.Model = product.Model;
                            cart.Price = Convert.ToInt32(product.Price) * Convert.ToInt32(this.QuantityLabel.Text);
                            cart.Quantity = Convert.ToInt32(this.QuantityLabel.Text);
                            int count = carts.Where(c => c.Brand == product.Brand && c.Model == product.Model).Count();
                            if (count == 1)
                            {
                                var value = carts.Where(c => c.Brand == product.Brand && c.Model == product.Model).Select(c => c.Quantity).SingleOrDefault();
                                if (value + Convert.ToInt32(this.QuantityLabel.Text) > 3)
                                {
                                    MessageBox.Show("Maximum 3 Is Allowed", "Maximum Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                else
                                {
                                    var crt = carts.Where(c => c.Brand == product.Brand && c.Model == product.Model).SingleOrDefault();
                                    carts.Remove(crt);
                                    crt.Quantity += Convert.ToInt32(this.QuantityLabel.Text);
                                    crt.Price = crt.Quantity * Convert.ToInt32(product.Price);
                                    carts.Add(crt);
                                    MessageBox.Show("Added To Card", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                            else
                            {
                                carts.Add(cart);
                                MessageBox.Show("Added To Card", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }

                        }

                    }
                    catch
                    {
                        MessageBox.Show("Can Not Add To Card", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
        }

        private void BunifuImageButton5_Click(object sender, EventArgs e)
        {
            if(Convert.ToInt32(this.QuantityLabel.Text)>=3)
            {
                MessageBox.Show("Maximum 3 Is Allowed","Maximum Value",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            else
            {
                this.QuantityLabel.Text = (Convert.ToInt32(this.QuantityLabel.Text) + 1).ToString();
            }
        }

        private void BunifuImageButton6_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(this.QuantityLabel.Text) <= 0)
            {
                MessageBox.Show("Not In Valied Range", "Out Of Range", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                this.QuantityLabel.Text = (Convert.ToInt32(this.QuantityLabel.Text) - 1).ToString();
            }
        }
        private void SetValue()
        {
            this.BrandAndModelName.Text = null;
            this.MobileImage.Image = null;
            this.NetworkText.Text = null;
            this.LunchText.Text = null;
            this.DimensionText.Text = null;
            this.WeightText.Text = null;
            this.SimText.Text = null;
            this.DisplayText.Text = null;
            this.DisplaySizeText.Text = null;
            this.ResolutionText.Text = null; ;
            this.ChipsetText.Text = null;
            this.MemoryText.Text = null;
            this.CameraText.Text = null;
            this.WlanText.Text = null;
            this.BluetoothText.Text = null;
            this.BatteryText.Text = null;
            this.ColorText.Text = null;
            this.PriceText.Text = null;
            this.WarrantyText.Text = null;
            this.bunifuLabel6.Text = null;


            this.BrandAndModelName.Text = $"{product.Brand} {product.Model}";
            this.MobileImage.Image = ConvertByteToImage(product.Image);
            this.NetworkText.Text = product.Network;
            this.LunchText.Text = product.Launch;
            this.DimensionText.Text = product.Dimension;
            this.WeightText.Text = product.Weight;
            this.SimText.Text = product.Sim;
            this.DisplayText.Text = product.Display;
            this.DisplaySizeText.Text = product.DispalySize;
            this.ResolutionText.Text = product.Resolution;
            this.ChipsetText.Text = product.Chipset;
            this.MemoryText.Text = product.Memory;
            this.CameraText.Text = product.Camera;
            this.WlanText.Text = product.Wlan;
            this.BluetoothText.Text = product.Bluetooth;
            this.BatteryText.Text = product.Battery;
            this.ColorText.Text = product.Color;
            this.PriceText.Text = product.Price;
            this.WarrantyText.Text = product.Warranty;
            if (product.Quantity > 10)
            {
                this.bunifuLabel6.Text = "Available";
                this.bunifuLabel6.ForeColor = Color.Green;
                this.bunifuImageButton5.Enabled = true;
                this.bunifuImageButton6.Enabled = true;
            }
            else
            {
                this.bunifuLabel6.Text = "Not Available";
                this.bunifuLabel6.ForeColor = Color.Red;
                this.bunifuImageButton5.Enabled = false;
                this.bunifuImageButton6.Enabled = false;
            }
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            UserCart userCart = new UserCart(ProductDetails.carts);
            this.Hide();
            userCart.Show();
        }

        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            WishList wishList = new WishList(new Orders().GetWishList(UserLogin.dt.userId));
            this.Hide();
            wishList.Show();
        }

        private void OrderHistorys_Click(object sender, EventArgs e)
        {
            OrderHistory orderHistory = new OrderHistory();
            this.Hide();
            orderHistory.Show();
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            Search search = new Search(bunifuTextBox1.Text);
            this.Hide();
            search.Show();
        }

        private void BunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                PictureBox5_Click(sender, e);
            }
        }
    }
}
