﻿using Online_Mobile_Shop_Data_Emlpement;
using Online_Mobile_Shop_Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Mobile_Shop
{
    public partial class OrderHistory : Form
    {
        Orders order = new Orders();
        List<Panel> panels = new List<Panel>();
        List<Panel> subpanel = new List<Panel>();
        List<Online_Mobile_Shop_Model.Order> ord= new List<Online_Mobile_Shop_Model.Order>();
        Orders orders = new Orders();
        public OrderHistory()
        {
            InitializeComponent();
            panels.Add(this.UserOrderPanel);
            panels.Add(this.AdminOrderPanel);
            subpanel.Add(Pending);
            subpanel.Add(Delevered);
            if (this.PendingDataGridView1.Rows.Count > 0)
            {
                this.PendingDataGridView1.CurrentCell.Selected = false;
            }
            if (this.UserDataGridView.Rows.Count > 0)
            {
                this.UserDataGridView.CurrentCell.Selected = false;
            }
            if (UserLogin.dt.Type==Types.User)
            {
                panels[0].BringToFront();
            }
            else if(UserLogin.dt.Type==Types.Admin)
            {
                panels[1].BringToFront();
                subpanel[0].BringToFront();
            }
        }
        private void BunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void AdminButton_Click(object sender, EventArgs e)
        {
            AdminManage admin = new AdminManage();
            this.Hide();
            admin.Show();
        }
        public void SuccessLogout()
        {
            Form1.islogin = false;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.bunifuToolTip1.SetToolTip(this.Login, "Login");
            this.pictureBox2.Visible = false;
            this.pictureBox3.Visible = false;
            this.AdminButton.Visible = false;
        }
        private void BunifuI1mageButton4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 50)
            {
                Form1.menu = true;
                Sidebar.Visible = true;
                Sidebar.Width = 220;
                this.Width = 1080;
                bunifuTransitionOnShow.ShowSync(Sidebar);
            }
            else
            {
                Form1.menu = true;
                Sidebar.Width = 50;
                Sidebar.Visible = false;
                this.Width = 1080 - 50;
                bunifuTransitionOnHide.ShowSync(Sidebar);
            }
        }
        private void Login_Click(object sender, EventArgs e)
        {
            if (!Form1.islogin)
            {
                UserLogin login = new UserLogin();
                login.Show();
                this.Close();
            }
            else
            {
                SuccessLogout();
            }
        }
        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }

        private void BunifuButton2_Click(object sender, EventArgs e)
        {
            MoblieList mobile = new MoblieList();
            mobile.Show();
            this.Close();
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            UserCart userCart = new UserCart(ProductDetails.carts);
            userCart.Show();
            this.Close();
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            WishList wishList = new WishList(new Orders().GetWishList(UserLogin.dt.userId));
            this.Hide();
            wishList.Show();
        }
        private void BunifuButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature Will Comming Soon", "Future Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OrderHistory_Load(object sender, EventArgs e)
        {
            Updates();
            if (Form1.menu)
            {
                if (Sidebar.Width == 50)
                {
                    Form1.menu = true;
                    Sidebar.Visible = true;
                    Sidebar.Width = 220;
                    this.Width = 1080;
                    bunifuTransitionOnShow.ShowSync(Sidebar);
                }
                else
                {
                    Form1.menu = true;
                    Sidebar.Width = 50;
                    Sidebar.Visible = false;
                    this.Width = 1080 - 50;
                    bunifuTransitionOnHide.ShowSync(Sidebar);
                }
            }
            if (Form1.islogin)
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
                this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
                this.pictureBox2.Visible = true;
                this.pictureBox3.Visible = true;
                this.OrderHistorys.Visible = true;
                if (UserLogin.dt.Type == Types.Admin)
                {
                    this.AdminButton.Visible = true;
                }
            }
            else
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
                this.bunifuToolTip1.SetToolTip(this.Login, "Login");
                this.pictureBox2.Visible = false;
                this.pictureBox3.Visible = false;
                this.AdminButton.Visible = false;
                this.OrderHistorys.Visible = false;
            }
            GetPendingUpdate();
        }

        private void BunifuButton1_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }
        private void Updates()
        {
            if(UserLogin.dt.Type==Types.User)
            {
                this.UserDataGridView.Rows.Clear();
                List<Online_Mobile_Shop_Model.Order> orders = new List<Online_Mobile_Shop_Model.Order>();
                orders = order.GetUserOrderData(UserLogin.dt.userId);
                for(int i=0;i<orders.Count;i++)
                {
                    if (orders[i].Stutas == OrderStutas.Pending)
                    {
                        MessageBox.Show($"{orders[i].OrderId}   {orders[i].Stutas}");
                        this.UserDataGridView.Rows.Add(orders[i].OrderId, orders[i].Brand, orders[i].Model, orders[i].PurchaseTime, orders[i].Quantity, orders[i].Price, orders[i].Stutas, "Not Delevered");
                    }
                    else if (orders[i].Stutas == OrderStutas.Delivered)
                    {
                        MessageBox.Show($"{orders[i].OrderId}    {orders[i].Stutas}");
                        this.UserDataGridView.Rows.Add(orders[i].OrderId, orders[i].Brand, orders[i].Model, orders[i].PurchaseTime, orders[i].Quantity, orders[i].Price, orders[i].Stutas, orders[i].Delivered);
                    }
                }
            }
            else if (UserLogin.dt.Type == Types.Admin)
            {
                this.UserDataGridView.Rows.Clear();
                List<Online_Mobile_Shop_Model.Order> orders = new List<Online_Mobile_Shop_Model.Order>();
                orders = order.GetAllOrderData();
                for (int i = 0; i < orders.Count; i++)
                {
                    if (orders[i].Stutas == OrderStutas.Pending)
                    {
                        this.UserDataGridView.Rows.Add(orders[i].OrderId, orders[i].Brand, orders[i].Model, orders[i].PurchaseTime, orders[i].Quantity, orders[i].Price, orders[i].Stutas, "Not Delevered");
                    }
                    else if (orders[i].Stutas == OrderStutas.Delivered)
                    {
                        this.UserDataGridView.Rows.Add(orders[i].OrderId, orders[i].Brand, orders[i].Model, orders[i].PurchaseTime, orders[i].Quantity, orders[i].Price, orders[i].Stutas, orders[i].Delivered);
                    }
                }
            }
        }

        private void OrderHistorys_Click(object sender, EventArgs e)
        { }

        private void BunifuButton4_Click(object sender, EventArgs e)
        {
            if(this.PendingDataGridView1.SelectedCells.Count<=0)
            {
                MessageBox.Show("Please Select A Product First");
            }
            else
            {
                int rowindex = PendingDataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow row = PendingDataGridView1.Rows[rowindex];
                int pid = Convert.ToInt32(row.Cells["PendingId"].Value.ToString());
                MessageBox.Show(pid.ToString());
                int oper = orders.UpdatePendingToDelevered(pid);
                if (oper == 1)
                {
                    MessageBox.Show("Order Stutas Updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    GetPendingUpdate();
                }
                else if (oper == 0)
                {
                    MessageBox.Show("Order Stutas Can Not Update Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (oper == 1111)
                {
                    MessageBox.Show("Server Error Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (oper == 3)
                {
                    MessageBox.Show("Server Is Busy Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
        private void GetPendingUpdate()
        {
            PendingDataGridView1.Rows.Clear();
            var oper = orders.GetPendingOrder();
            for (int i = 0; i < oper.Count; i++)
            {

                this.PendingDataGridView1.Rows.Add(oper[i].OrderId, oper[i].UserId, oper[i].Brand, oper[i].Model, oper[i].PurchaseTime, oper[i].Quantity, oper[i].Price, oper[i].Stutas);

            }
        }

        private void AddProduct_Click(object sender, EventArgs e)
        {
            this.AddProductBar.BackColor = Color.DodgerBlue;
            this.UpdateProductBar.BackColor = Color.Silver;
            subpanel[0].BringToFront();
            GetPendingUpdate();
        }

        private void UpdateProduct_Click(object sender, EventArgs e)
        {
            this.AddProductBar.BackColor = Color.Silver;
            this.UpdateProductBar.BackColor = Color.DodgerBlue;
            subpanel[1].BringToFront();
            GetDeliveredUpdate();
        }

        private void BunifuButton5_Click(object sender, EventArgs e)
        {
            if (this.PendingDataGridView1.SelectedCells.Count <= 0)
            {
                MessageBox.Show("Please Select A Product First");
            }
            else
            {
                int rowindex = DeliveredDataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow row = DeliveredDataGridView1.Rows[rowindex];
                int pid = Convert.ToInt32(row.Cells["DeleveredId"].Value.ToString());
                MessageBox.Show(pid.ToString());
                int oper = orders.UpdateDeleveredToPending(pid);
                if (oper == 1)
                {
                    MessageBox.Show("Order Stutas Updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    GetDeliveredUpdate();
                }
                else if (oper == 0)
                {
                    MessageBox.Show("Order Stutas Can Not Update Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (oper == 1111)
                {
                    MessageBox.Show("Server Error Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (oper == 3)
                {
                    MessageBox.Show("Server Is Busy Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
        private void GetDeliveredUpdate()
        {
            DeliveredDataGridView1.Rows.Clear();
            var oper = orders.GetPDeliveredOrder();
            for (int i = 0; i < oper.Count; i++)
            {

                this.DeliveredDataGridView1.Rows.Add(oper[i].OrderId, oper[i].UserId, oper[i].Brand, oper[i].Model, oper[i].PurchaseTime, oper[i].Quantity, oper[i].Price, oper[i].Stutas,oper[i].Delivered);

            }
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            Search search = new Search(bunifuTextBox1.Text);
            this.Hide();
            search.Show();
        }

        private void BunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                PictureBox5_Click(sender, e);
            }
        }
    }
}
