﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Online_Mobile_Shop_Model;
using Online_Mobile_Shop_Data_Emlpement;

namespace Online_Mobile_Shop
{
    public partial class UserLogin : Form
    {
        Login_Registration_Access login = new Login_Registration_Access();
        User user = new User();
        public static User dt = new User();
        List<Panel> panels = new List<Panel>();
        int panel, email = 0;
        public UserLogin()
        {
            InitializeComponent();
            EmailBox.Text = null;
            PasswordBox.Text = null;
            panels.Add(LoginPanel);
            panels.Add(RegistrationPanel);
            panels[0].BringToFront();
            panel = 0;
        }
        public void SuccessLogin()
        {
            Form1.islogin = true;
            this.Loginimg.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
            this.bunifuToolTip1.SetToolTip(this.Loginimg, "Logout");
            this.pictureBox2.Visible = true;
            this.pictureBox3.Visible = true;

        }
        public void SuccessLogout()
        {
            Form1.islogin = false;
            this.Loginimg.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.bunifuToolTip1.SetToolTip(this.Loginimg, "Login");
            this.pictureBox2.Visible = false;
            this.pictureBox3.Visible = false;
        }
        private void BunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BunifuI1mageButton4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 50)
            {
                Form1.menu = true;
                Sidebar.Visible = true;
                Sidebar.Width = 220;
                this.Width = 1080;
                bunifuTransitionOnShow.ShowSync(Sidebar);
            }
            else
            {
                Form1.menu = true;
                Sidebar.Width = 50;
                Sidebar.Visible = false;
                this.Width = 1080 - 50;
                bunifuTransitionOnHide.ShowSync(Sidebar);
            }
        }

        private void UserLogin_Load(object sender, EventArgs e)
        {
            if (Form1.menu)
            {
                if (Sidebar.Width == 50)
                {
                    Form1.menu = true;
                    Sidebar.Visible = true;
                    Sidebar.Width = 220;
                    this.Width = 1080;
                    bunifuTransitionOnShow.ShowSync(Sidebar);
                }
                else
                {
                    Form1.menu = true;
                    Sidebar.Width = 50;
                    Sidebar.Visible = false;
                    this.Width = 1080 - 50;
                    bunifuTransitionOnHide.ShowSync(Sidebar);
                }
            }
            if (Form1.islogin)
            {
                this.Loginimg.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
                this.bunifuToolTip1.SetToolTip(this.Loginimg, "Logout");
                this.pictureBox2.Visible = true;
                this.pictureBox3.Visible = true;
            }
            else
            {
                this.Loginimg.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
                this.bunifuToolTip1.SetToolTip(this.Loginimg, "Login");
                this.pictureBox2.Visible = false;
                this.pictureBox3.Visible = false;
            }
        }

        private void BunifuButton4_Click(object sender, EventArgs e)
        {
            user.Email = this.EmailBox.Text;
            user.Password = this.PasswordBox.Text;
            dt = login.LoginInfo(user);
            if(dt==null)
            {
                MessageBox.Show("User Name Or Password Not Matched");
            }
            else
            {
                SuccessLogin();
                Form1 form1 = new Form1();
                this.Hide();
                form1.Show();
            }
        }

        private void Login_Click(object sender, EventArgs e)
        {

        }

        private void BunifuButton5_Click(object sender, EventArgs e)
        {
            this.FnameBox.Text = null;
            this.LnameBox.Text = null;
            this.Email1Box.Text = null;
            this.Password1Box.Text = null;
            this.PhoneBox.Text = null;
            this.AddressBox.Text = null;
            panels[1].BringToFront();
            panel = 1;
        }

        private void BunifuButton7_Click(object sender, EventArgs e)
        {
            this.EmailBox.Text = null;
            this.PasswordBox.Text = null;
            panels[0].BringToFront();
            panel = 0;
        }

        private void PhoneBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==(char)Keys.Enter)
            {
                AddressBox.Focus();
            }
            if ((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) ||
        (e.KeyChar == '.'))
            {
                e.Handled = true;
            }
        }

        private void Loginimg_Click(object sender, EventArgs e)
        {
            if(panel==1)
            {
                BunifuButton7_Click(sender, e);
            }
        }

        private void BunifuButton6_Click(object sender, EventArgs e)
        {
            bool register = true; ;
            if (string.IsNullOrEmpty(FnameBox.Text.Trim()))
            {
                MessageBox.Show("First Name is Impty");
                register = false;
                FnameBox.Focus();
            }
            else if (string.IsNullOrEmpty(LnameBox.Text.Trim()))
            {
                MessageBox.Show("Last Name is Impty");
                register = false;
                LnameBox.Focus();
            }
            else if (string.IsNullOrEmpty(Email1Box.Text.Trim()))
            {
                MessageBox.Show("Email Id is Impty");
                register = false;
                Email1Box.Focus();
            }
            else if (!string.IsNullOrEmpty(Email1Box.Text.Trim()))
            {
                var eml = Email1Box_Leave();
                if (!eml)
                {
                    MessageBox.Show("Email Is Not Valied");
                    register = false;
                    Email1Box.Focus();
                }
                else if (string.IsNullOrEmpty(Password1Box.Text.Trim()))
                {
                    MessageBox.Show("Password is Impty");
                    register = false;
                    Password1Box.Focus();
                }
                else if (string.IsNullOrEmpty(PhoneBox.Text.Trim()))
                {
                    MessageBox.Show("Phone Number is Impty");
                    register = false;
                    PhoneBox.Focus();
                }
                else if (string.IsNullOrEmpty(AddressBox.Text.Trim()))
                {
                    MessageBox.Show("Address is Impty");
                    register = false;
                    AddressBox.Focus();
                }
            }
            if(register)
            {
                int count, stutas;
                user.Fname = FnameBox.Text;
                user.Lname = LnameBox.Text;
                user.Email = Email1Box.Text;
                user.Password = Password1Box.Text;
                user.Phone = PhoneBox.Text;
                user.Address = AddressBox.Text;
                user.Type = Types.User;
                count = login.GetUserInfo(user);
                if(count==1)
                {
                    MessageBox.Show("User Already Exist Use Another Email");
                }
                else if(count==3)
                {
                    MessageBox.Show("Server Error Please Try Again Leter");
                }
                else if(count==0)
                {
                    stutas = login.RegisterUser(user);
                    if(stutas>0)
                    {
                        MessageBox.Show("Registration Successfull Please Login");
                        EmailBox.Text = null;
                        PasswordBox.Text = null;
                        panels[0].BringToFront();
                        panel = 0;
                    }
                    else
                    {
                        MessageBox.Show("Registration Failed Try Again Later");
                    }
                }
            }
        }

        private void BunifuButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature Will Comming Soon", "Future Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }



        private void FnameBox_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                this.LnameBox.Focus();
            }
            
        }

        private void LnameBox_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                this.Email1Box.Focus();
            }
            
        }
        private void EmailBox_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                this.PasswordBox.Focus();
            }
        }
        private void Email1Box_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                this.Password1Box.Focus();
            }
            
        }

        private void Password1Box_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                this.PhoneBox.Focus();
            }
            
        }

        private void PhoneBox_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                this.AddressBox.Focus();
            }
            
        }

        private void AddressBox_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BunifuButton6_Click(sender, e);
            }
            
        }


        private void PasswordBox_Enter(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BunifuButton4_Click(sender, e);
            }
        }

        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void BunifuButton2_Click(object sender, EventArgs e)
        {
            MoblieList moblieList = new MoblieList();
            this.Hide();
            moblieList.Show();
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            Search search = new Search(bunifuTextBox1.Text);
            this.Hide();
            search.Show();
        }

        private void BunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                PictureBox5_Click(sender, e);
            }
        }

        private bool Email1Box_Leave()
        {
            try
            {
                System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
                if (rEMail.IsMatch(Email1Box.Text))
                {
                    return true;
                }
                else
                    return false;
            }
            catch (FormatException ex)
            {
                return false;
            }
        }
    }
}
