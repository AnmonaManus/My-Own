﻿using Online_Mobile_Shop_Data_Emlpement;
using Online_Mobile_Shop_Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Mobile_Shop
{
    public partial class WishList : Form
    {
        List<Wishlist> wishlists;
        ManageWishList manageWish = new ManageWishList();
        public WishList(List<Wishlist> _wishlists)
        {
            InitializeComponent();
            this.wishlists = _wishlists;
        }
        private void Wish_Load(object sender, EventArgs e)
        {
            if (Form1.menu)
            {
                if (Sidebar.Width == 50)
                {
                    Form1.menu = true;
                    Sidebar.Visible = true;
                    Sidebar.Width = 220;
                    this.Width = 1080;
                    bunifuTransitionOnShow.ShowSync(Sidebar);
                }
                else
                {
                    Form1.menu = true;
                    Sidebar.Width = 50;
                    Sidebar.Visible = false;
                    this.Width = 1080 - 50;
                    bunifuTransitionOnHide.ShowSync(Sidebar);
                }
            }
            if (Form1.islogin)
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
                this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
                this.pictureBox2.Visible = true;
                this.pictureBox3.Visible = true;
                if (UserLogin.dt.Type == Types.Admin)
                {
                    this.AdminButton.Visible = true;
                }
            }
            else
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
                this.bunifuToolTip1.SetToolTip(this.Login, "Login");
                this.pictureBox2.Visible = false;
                this.pictureBox3.Visible = false;
                this.AdminButton.Visible = false;
            }
            Add();
            if (bunifuDataGridView1.Rows.Count > 0)
            {
                this.bunifuDataGridView1.CurrentCell.Selected = false;
            }
        }
        private void BunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BunifuI1mageButton4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 50)
            {
                Form1.menu = true;
                Sidebar.Visible = true;
                Sidebar.Width = 220;
                this.Width = 1080;
                bunifuTransitionOnShow.ShowSync(Sidebar);
            }
            else
            {
                Form1.menu = true;
                Sidebar.Width = 50;
                Sidebar.Visible = false;
                this.Width = 1080 - 50;
                bunifuTransitionOnHide.ShowSync(Sidebar);
            }
        }
        public void SuccessLogout()
        {
            Form1.islogin = false;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.bunifuToolTip1.SetToolTip(this.Login, "Login");
            this.pictureBox2.Visible = false;
            this.pictureBox3.Visible = false;
            this.AdminButton.Visible = false;
        }
        private void Login_Click(object sender, EventArgs e)
        {
            if (!Form1.islogin)
            {
                UserLogin login = new UserLogin();
                login.Show();
                this.Close();
            }
            else
            {
                SuccessLogout();
            }
        }
        private void BunifuButton2_Click(object sender, EventArgs e)
        {
            MoblieList mobile = new MoblieList();
            mobile.Show();
            this.Close();
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            UserCart userCart = new UserCart(ProductDetails.carts);
            userCart.Show();
            this.Close();
        }
        private void BunifuButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature Will Comming Soon", "Future Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void AdminButton_Click(object sender, EventArgs e)
        {
            AdminManage admin = new AdminManage();
            this.Hide();
            admin.Show();
        }
        private void Add()
        {
            foreach (var cart in wishlists)
            {
                bunifuDataGridView1.Rows.Add(cart.ProductId, cart.Brand, cart.Model, cart.Price);
            }
        }

        private void DeleteWishList_Click(object sender, EventArgs e)
        {
            if (bunifuDataGridView1.SelectedCells.Count <= 0)
            {
                MessageBox.Show("Please Select A Product First");
            }
            else
            {
                int rowindex = bunifuDataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow row = bunifuDataGridView1.Rows[rowindex];
                int pid = Convert.ToInt32(row.Cells["ProductId"].Value.ToString());
                int oper = manageWish.ManagesWishList(UserLogin.dt.userId, pid);
                if (oper == 1)
                {
                    MessageBox.Show("Removed From Wishlist", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    bunifuDataGridView1.Rows.Clear();
                    wishlists = new Orders().GetWishList(UserLogin.dt.userId);
                    Add();
                }
                else if (oper == 0)
                {
                    MessageBox.Show("Can Not Remove From WishList Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (oper == 1111)
                {
                    MessageBox.Show("Server Error Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (oper == 3)
                {
                    MessageBox.Show("Server Is Busy Try Again Leter", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            } 
        }

        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void OrderHistorys_Click(object sender, EventArgs e)
        {
            OrderHistory orderHistory = new OrderHistory();
            this.Hide();
            orderHistory.Show();
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            Search search = new Search(bunifuTextBox1.Text);
            this.Hide();
            search.Show();
        }

        private void BunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                PictureBox5_Click(sender, e);
            }
        }
    }
}
