﻿using Online_Mobile_Shop_Data_Emlpement;
using Online_Mobile_Shop_Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Mobile_Shop
{
    public partial class UserCart : Form
    {
        List<Cart> carts;
        public UserCart(List<Cart> _carts)
        {
            InitializeComponent();
            this.carts = _carts;
        }
        private void Cart_Load(object sender, EventArgs e)
        {
            if (Form1.menu)
            {
                if (Sidebar.Width == 50)
                {
                    Form1.menu = true;
                    Sidebar.Visible = true;
                    Sidebar.Width = 220;
                    this.Width = 1080;
                    bunifuTransitionOnShow.ShowSync(Sidebar);
                }
                else
                {
                    Form1.menu = true;
                    Sidebar.Width = 50;
                    Sidebar.Visible = false;
                    this.Width = 1080 - 50;
                    bunifuTransitionOnHide.ShowSync(Sidebar);
                }
            }
            if (Form1.islogin)
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_sign_out_48;
                this.bunifuToolTip1.SetToolTip(this.Login, "Logout");
                this.pictureBox2.Visible = true;
                this.pictureBox3.Visible = true;
                this.OrderHistorys.Visible = true;
                if (UserLogin.dt.Type == Types.Admin)
                {
                    this.AdminButton.Visible = true;
                }
            }
            else
            {
                this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
                this.bunifuToolTip1.SetToolTip(this.Login, "Login");
                this.pictureBox2.Visible = false;
                this.pictureBox3.Visible = false;
                this.AdminButton.Visible = false;
                this.OrderHistorys.Visible = false;
            }
            CardLoad();
            if(bunifuDataGridView1.Rows.Count>0)
            {
                this.bunifuDataGridView1.CurrentCell.Selected = false;
            }
        }
        private void BunifuImageButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BunifuI1mageButton4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public void SuccessLogout()
        {
            Form1.islogin = false;
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.bunifuToolTip1.SetToolTip(this.Login, "Login");
            this.pictureBox2.Visible = false;
            this.pictureBox3.Visible = false;
            this.AdminButton.Visible = false;
        }
        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (Sidebar.Width == 50)
            {
                Form1.menu = true;
                Sidebar.Visible = true;
                Sidebar.Width = 220;
                this.Width = 1080;
                bunifuTransitionOnShow.ShowSync(Sidebar);
            }
            else
            {
                Form1.menu = true;
                Sidebar.Width = 50;
                Sidebar.Visible = false;
                this.Width = 1080 - 50;
                bunifuTransitionOnHide.ShowSync(Sidebar);
            }
        }
        private void Login_Click(object sender, EventArgs e)
        {
            if (!Form1.islogin)
            {
                UserLogin login = new UserLogin();
                this.Hide();
                login.Show();
            }
            else
            {
                SuccessLogout();
            }
        }
        private void BunifuButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature Will Comming Soon", "Future Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void BunifuButton2_Click(object sender, EventArgs e)
        {
            MoblieList mobile = new MoblieList();
            this.Hide();
            mobile.Show();
        }
        private void AdminButton_Click(object sender, EventArgs e)
        {
            AdminManage admin = new AdminManage();
            admin.Show();
            this.Close();
        }

        private void BunifuLabel1_Click(object sender, EventArgs e)
        {

        }
        private void CardLoad()
        {
            foreach(var cart in carts)
            {
                bunifuDataGridView1.Rows.Add(cart.Brand, cart.Model, cart.Quantity, cart.Price);
            }
            if(carts.Count > 0)
                    {
                this.TotalPrice.Text = carts.Sum(c => c.Price).ToString();
            }
                    else
            {
                this.TotalPrice.Text = "0";
            }
        }

        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void BunifuButton4_Click(object sender, EventArgs e)
        {
            if(carts.Count==0)
            {
                MessageBox.Show("Please Add Product To Cart");
            }
            else
            {
               if(bunifuDataGridView1.SelectedCells.Count>0)
                {
                    int rowindex = bunifuDataGridView1.SelectedCells[0].RowIndex;
                    DataGridViewRow row = bunifuDataGridView1.Rows[rowindex];
                    var crt = carts.Where(c => c.Brand == row.Cells["Brand"].Value.ToString().Trim() && c.Model == row.Cells["Model"].Value.ToString().Trim()).SingleOrDefault();
                    carts.Remove(crt);
                    ProductDetails.carts = this.carts;
                    bunifuDataGridView1.Rows.Clear();

                    foreach (var cart in carts)
                    {
                        bunifuDataGridView1.Rows.Add(cart.Brand, cart.Model, cart.Quantity, cart.Price);
                    }
                    if(carts.Count>0)
                    {
                        this.TotalPrice.Text = carts.Sum(c => c.Price).ToString();
                    }
                    else
                    {
                        this.TotalPrice.Text = "0";
                    }
                }
                else
                {
                    MessageBox.Show("Select A Product To Remove");
                }
            }
        }

        private void BunifuButton5_Click(object sender, EventArgs e)
        {
            if (carts.Count == 0)
            {
                MessageBox.Show("Please Add Product To Cart");
            }
            else
            {
                Order order = new Order();
                this.Hide();
                order.Show();
            }
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            WishList wishList = new WishList(new Orders().GetWishList(UserLogin.dt.userId));
            this.Hide();
            wishList.Show();
        }

        private void OrderHistorys_Click(object sender, EventArgs e)
        {
            OrderHistory orderHistory = new OrderHistory();
            this.Hide();
            orderHistory.Show();
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            Search search = new Search(bunifuTextBox1.Text);
            this.Hide();
            search.Show();
        }

        private void BunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                PictureBox5_Click(sender, e);
            }
        }
    }
}
