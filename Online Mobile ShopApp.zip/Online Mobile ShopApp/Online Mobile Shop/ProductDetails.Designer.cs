﻿using System;

namespace Online_Mobile_Shop
{
    partial class ProductDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductDetails));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuAnimatorNS.Animation animation2 = new Bunifu.UI.WinForms.BunifuAnimatorNS.Animation();
            Bunifu.UI.WinForms.BunifuAnimatorNS.Animation animation1 = new Bunifu.UI.WinForms.BunifuAnimatorNS.Animation();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Sidebar = new System.Windows.Forms.Panel();
            this.OrderHistorys = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.AdminButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.WorkSpace = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SimText = new Bunifu.UI.WinForms.BunifuLabel();
            this.ResolutionText = new Bunifu.UI.WinForms.BunifuLabel();
            this.DisplaySizeText = new Bunifu.UI.WinForms.BunifuLabel();
            this.WarrantyText = new Bunifu.UI.WinForms.BunifuLabel();
            this.PriceText = new Bunifu.UI.WinForms.BunifuLabel();
            this.ColorText = new Bunifu.UI.WinForms.BunifuLabel();
            this.BatteryText = new Bunifu.UI.WinForms.BunifuLabel();
            this.BluetoothText = new Bunifu.UI.WinForms.BunifuLabel();
            this.WlanText = new Bunifu.UI.WinForms.BunifuLabel();
            this.CameraText = new Bunifu.UI.WinForms.BunifuLabel();
            this.MemoryText = new Bunifu.UI.WinForms.BunifuLabel();
            this.ChipsetText = new Bunifu.UI.WinForms.BunifuLabel();
            this.DisplayText = new Bunifu.UI.WinForms.BunifuLabel();
            this.DimensionText = new Bunifu.UI.WinForms.BunifuLabel();
            this.WeightText = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel25 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel21 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel19 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel48 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel46 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel44 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel41 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel38 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel36 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel33 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel30 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel27 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel17 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel12 = new Bunifu.UI.WinForms.BunifuLabel();
            this.LunchText = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel9 = new Bunifu.UI.WinForms.BunifuLabel();
            this.NetworkText = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel43 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel40 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel35 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel32 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel29 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel24 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel23 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel14 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel7 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.BrandAndModelName = new Bunifu.UI.WinForms.BunifuLabel();
            this.MobileImage = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.bunifuImageButton6 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bunifuImageButton5 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.QuantityLabel = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuButton4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Searchbar = new System.Windows.Forms.Panel();
            this.Login = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuTextBox1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.Header = new System.Windows.Forms.Panel();
            this.TitlePic = new System.Windows.Forms.PictureBox();
            this.TitleLb = new System.Windows.Forms.Label();
            this.bunifuImageButton4 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton2 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuImageButton1 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuToolTip1 = new Bunifu.UI.WinForms.BunifuToolTip(this.components);
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl3 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuTransitionOnHide = new Bunifu.UI.WinForms.BunifuTransition(this.components);
            this.bunifuTransitionOnShow = new Bunifu.UI.WinForms.BunifuTransition(this.components);
            this.Sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.WorkSpace.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MobileImage)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.Searchbar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Login)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.Header.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TitlePic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // Sidebar
            // 
            this.Sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.Sidebar.Controls.Add(this.OrderHistorys);
            this.Sidebar.Controls.Add(this.AdminButton);
            this.Sidebar.Controls.Add(this.bunifuButton3);
            this.Sidebar.Controls.Add(this.bunifuButton2);
            this.Sidebar.Controls.Add(this.bunifuButton1);
            this.Sidebar.Controls.Add(this.pictureBox1);
            this.bunifuTransitionOnShow.SetDecoration(this.Sidebar, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.Sidebar, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.Sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.Sidebar.Location = new System.Drawing.Point(0, 34);
            this.Sidebar.Name = "Sidebar";
            this.Sidebar.Size = new System.Drawing.Size(220, 686);
            this.Sidebar.TabIndex = 0;
            this.bunifuToolTip1.SetToolTip(this.Sidebar, "");
            this.bunifuToolTip1.SetToolTipIcon(this.Sidebar, null);
            this.bunifuToolTip1.SetToolTipTitle(this.Sidebar, "");
            // 
            // OrderHistorys
            // 
            this.OrderHistorys.AllowToggling = false;
            this.OrderHistorys.AnimationSpeed = 200;
            this.OrderHistorys.AutoGenerateColors = true;
            this.OrderHistorys.BackColor = System.Drawing.Color.Transparent;
            this.OrderHistorys.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.OrderHistorys.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OrderHistorys.BackgroundImage")));
            this.OrderHistorys.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.OrderHistorys.ButtonText = "Order History";
            this.OrderHistorys.ButtonTextMarginLeft = 0;
            this.OrderHistorys.ColorContrastOnClick = 45;
            this.OrderHistorys.ColorContrastOnHover = 45;
            this.OrderHistorys.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.OrderHistorys.CustomizableEdges = borderEdges2;
            this.bunifuTransitionOnShow.SetDecoration(this.OrderHistorys, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.OrderHistorys, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.OrderHistorys.DialogResult = System.Windows.Forms.DialogResult.None;
            this.OrderHistorys.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.OrderHistorys.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.OrderHistorys.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.OrderHistorys.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.OrderHistorys.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.OrderHistorys.ForeColor = System.Drawing.Color.White;
            this.OrderHistorys.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.OrderHistorys.IconMarginLeft = 11;
            this.OrderHistorys.IconPadding = 10;
            this.OrderHistorys.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.OrderHistorys.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.OrderHistorys.IdleBorderRadius = 3;
            this.OrderHistorys.IdleBorderThickness = 1;
            this.OrderHistorys.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.OrderHistorys.IdleIconLeftImage = global::Online_Mobile_Shop.Properties.Resources.icons8_purchase_order_64;
            this.OrderHistorys.IdleIconRightImage = null;
            this.OrderHistorys.IndicateFocus = false;
            this.OrderHistorys.Location = new System.Drawing.Point(0, 476);
            this.OrderHistorys.Name = "OrderHistorys";
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties7.BorderRadius = 3;
            stateProperties7.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties7.BorderThickness = 1;
            stateProperties7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties7.ForeColor = System.Drawing.Color.White;
            stateProperties7.IconLeftImage = null;
            stateProperties7.IconRightImage = null;
            this.OrderHistorys.onHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties8.BorderRadius = 3;
            stateProperties8.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties8.BorderThickness = 1;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties8.ForeColor = System.Drawing.Color.White;
            stateProperties8.IconLeftImage = null;
            stateProperties8.IconRightImage = null;
            this.OrderHistorys.OnPressedState = stateProperties8;
            this.OrderHistorys.Size = new System.Drawing.Size(220, 45);
            this.OrderHistorys.TabIndex = 2;
            this.OrderHistorys.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.OrderHistorys.TextMarginLeft = 0;
            this.bunifuToolTip1.SetToolTip(this.OrderHistorys, "");
            this.bunifuToolTip1.SetToolTipIcon(this.OrderHistorys, null);
            this.bunifuToolTip1.SetToolTipTitle(this.OrderHistorys, "");
            this.OrderHistorys.Visible = false;
            this.OrderHistorys.Click += new System.EventHandler(this.OrderHistorys_Click);
            // 
            // AdminButton
            // 
            this.AdminButton.AllowToggling = false;
            this.AdminButton.AnimationSpeed = 200;
            this.AdminButton.AutoGenerateColors = true;
            this.AdminButton.BackColor = System.Drawing.Color.Transparent;
            this.AdminButton.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.AdminButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("AdminButton.BackgroundImage")));
            this.AdminButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.AdminButton.ButtonText = "Admin Panel";
            this.AdminButton.ButtonTextMarginLeft = 0;
            this.AdminButton.ColorContrastOnClick = 45;
            this.AdminButton.ColorContrastOnHover = 45;
            this.AdminButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.AdminButton.CustomizableEdges = borderEdges3;
            this.bunifuTransitionOnShow.SetDecoration(this.AdminButton, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.AdminButton, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.AdminButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.AdminButton.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.AdminButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.AdminButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.AdminButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.AdminButton.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.AdminButton.ForeColor = System.Drawing.Color.White;
            this.AdminButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.AdminButton.IconMarginLeft = 11;
            this.AdminButton.IconPadding = 10;
            this.AdminButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.AdminButton.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.AdminButton.IdleBorderRadius = 3;
            this.AdminButton.IdleBorderThickness = 1;
            this.AdminButton.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.AdminButton.IdleIconLeftImage = global::Online_Mobile_Shop.Properties.Resources.icons8_user_account_48;
            this.AdminButton.IdleIconRightImage = null;
            this.AdminButton.IndicateFocus = false;
            this.AdminButton.Location = new System.Drawing.Point(0, 374);
            this.AdminButton.Name = "AdminButton";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties9.BorderRadius = 3;
            stateProperties9.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties9.BorderThickness = 1;
            stateProperties9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties9.ForeColor = System.Drawing.Color.White;
            stateProperties9.IconLeftImage = null;
            stateProperties9.IconRightImage = null;
            this.AdminButton.onHoverState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties10.BorderRadius = 3;
            stateProperties10.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties10.BorderThickness = 1;
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties10.ForeColor = System.Drawing.Color.White;
            stateProperties10.IconLeftImage = null;
            stateProperties10.IconRightImage = null;
            this.AdminButton.OnPressedState = stateProperties10;
            this.AdminButton.Size = new System.Drawing.Size(220, 45);
            this.AdminButton.TabIndex = 1;
            this.AdminButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.AdminButton.TextMarginLeft = 0;
            this.bunifuToolTip1.SetToolTip(this.AdminButton, "");
            this.bunifuToolTip1.SetToolTipIcon(this.AdminButton, null);
            this.bunifuToolTip1.SetToolTipTitle(this.AdminButton, "");
            this.AdminButton.Visible = false;
            this.AdminButton.Click += new System.EventHandler(this.AdminButton_Click);
            // 
            // bunifuButton3
            // 
            this.bunifuButton3.AllowToggling = false;
            this.bunifuButton3.AnimationSpeed = 200;
            this.bunifuButton3.AutoGenerateColors = true;
            this.bunifuButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton3.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.BackgroundImage")));
            this.bunifuButton3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.ButtonText = "Tablet Phone";
            this.bunifuButton3.ButtonTextMarginLeft = 0;
            this.bunifuButton3.ColorContrastOnClick = 45;
            this.bunifuButton3.ColorContrastOnHover = 45;
            this.bunifuButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.bunifuButton3.CustomizableEdges = borderEdges4;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuButton3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuButton3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton3.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton3.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton3.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton3.IconMarginLeft = 11;
            this.bunifuButton3.IconPadding = 10;
            this.bunifuButton3.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton3.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton3.IdleBorderRadius = 3;
            this.bunifuButton3.IdleBorderThickness = 1;
            this.bunifuButton3.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton3.IdleIconLeftImage = global::Online_Mobile_Shop.Properties.Resources.icons8_windows8_tablet_48;
            this.bunifuButton3.IdleIconRightImage = null;
            this.bunifuButton3.IndicateFocus = false;
            this.bunifuButton3.Location = new System.Drawing.Point(0, 270);
            this.bunifuButton3.Name = "bunifuButton3";
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties11.BorderRadius = 3;
            stateProperties11.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties11.BorderThickness = 1;
            stateProperties11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties11.ForeColor = System.Drawing.Color.White;
            stateProperties11.IconLeftImage = null;
            stateProperties11.IconRightImage = null;
            this.bunifuButton3.onHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties12.BorderRadius = 3;
            stateProperties12.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties12.BorderThickness = 1;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties12.ForeColor = System.Drawing.Color.White;
            stateProperties12.IconLeftImage = null;
            stateProperties12.IconRightImage = null;
            this.bunifuButton3.OnPressedState = stateProperties12;
            this.bunifuButton3.Size = new System.Drawing.Size(220, 45);
            this.bunifuButton3.TabIndex = 1;
            this.bunifuButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton3.TextMarginLeft = 0;
            this.bunifuToolTip1.SetToolTip(this.bunifuButton3, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuButton3, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuButton3, "");
            this.bunifuButton3.Click += new System.EventHandler(this.BunifuButton3_Click);
            // 
            // bunifuButton2
            // 
            this.bunifuButton2.AllowToggling = false;
            this.bunifuButton2.AnimationSpeed = 200;
            this.bunifuButton2.AutoGenerateColors = true;
            this.bunifuButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.BackgroundImage")));
            this.bunifuButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.ButtonText = "Mobile Phone";
            this.bunifuButton2.ButtonTextMarginLeft = 0;
            this.bunifuButton2.ColorContrastOnClick = 45;
            this.bunifuButton2.ColorContrastOnHover = 45;
            this.bunifuButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.bunifuButton2.CustomizableEdges = borderEdges5;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuButton2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuButton2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton2.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton2.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IconMarginLeft = 11;
            this.bunifuButton2.IconPadding = 10;
            this.bunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton2.IdleBorderRadius = 3;
            this.bunifuButton2.IdleBorderThickness = 1;
            this.bunifuButton2.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton2.IdleIconLeftImage = global::Online_Mobile_Shop.Properties.Resources.icons8_mobile_64;
            this.bunifuButton2.IdleIconRightImage = null;
            this.bunifuButton2.IndicateFocus = false;
            this.bunifuButton2.Location = new System.Drawing.Point(0, 176);
            this.bunifuButton2.Name = "bunifuButton2";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties13.BorderRadius = 3;
            stateProperties13.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties13.BorderThickness = 1;
            stateProperties13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties13.ForeColor = System.Drawing.Color.White;
            stateProperties13.IconLeftImage = null;
            stateProperties13.IconRightImage = null;
            this.bunifuButton2.onHoverState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties14.BorderRadius = 3;
            stateProperties14.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties14.BorderThickness = 1;
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties14.ForeColor = System.Drawing.Color.White;
            stateProperties14.IconLeftImage = null;
            stateProperties14.IconRightImage = null;
            this.bunifuButton2.OnPressedState = stateProperties14;
            this.bunifuButton2.Size = new System.Drawing.Size(220, 45);
            this.bunifuButton2.TabIndex = 1;
            this.bunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton2.TextMarginLeft = 0;
            this.bunifuToolTip1.SetToolTip(this.bunifuButton2, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuButton2, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuButton2, "");
            this.bunifuButton2.Click += new System.EventHandler(this.BunifuButton2_Click);
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.AllowToggling = false;
            this.bunifuButton1.AnimationSpeed = 200;
            this.bunifuButton1.AutoGenerateColors = true;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.ButtonText = "Home";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.ColorContrastOnClick = 45;
            this.bunifuButton1.ColorContrastOnHover = 45;
            this.bunifuButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.bunifuButton1.CustomizableEdges = borderEdges6;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuButton1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuButton1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IconMarginLeft = 11;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton1.IdleBorderRadius = 3;
            this.bunifuButton1.IdleBorderThickness = 1;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(28)))), ((int)(((byte)(33)))));
            this.bunifuButton1.IdleIconLeftImage = global::Online_Mobile_Shop.Properties.Resources.icons8_home_48;
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.IndicateFocus = false;
            this.bunifuButton1.Location = new System.Drawing.Point(0, 96);
            this.bunifuButton1.Name = "bunifuButton1";
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties15.BorderRadius = 3;
            stateProperties15.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties15.BorderThickness = 1;
            stateProperties15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(130)))), ((int)(((byte)(132)))));
            stateProperties15.ForeColor = System.Drawing.Color.White;
            stateProperties15.IconLeftImage = null;
            stateProperties15.IconRightImage = null;
            this.bunifuButton1.onHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties16.BorderRadius = 3;
            stateProperties16.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties16.BorderThickness = 1;
            stateProperties16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            stateProperties16.ForeColor = System.Drawing.Color.White;
            stateProperties16.IconLeftImage = null;
            stateProperties16.IconRightImage = null;
            this.bunifuButton1.OnPressedState = stateProperties16;
            this.bunifuButton1.Size = new System.Drawing.Size(220, 45);
            this.bunifuButton1.TabIndex = 1;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.TextMarginLeft = 0;
            this.bunifuToolTip1.SetToolTip(this.bunifuButton1, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuButton1, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuButton1, "");
            this.bunifuButton1.Click += new System.EventHandler(this.BunifuButton1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuTransitionOnHide.SetDecoration(this.pictureBox1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.pictureBox1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.pictureBox1.Image = global::Online_Mobile_Shop.Properties.Resources._134216_64;
            this.pictureBox1.Location = new System.Drawing.Point(172, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 39);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.pictureBox1, "Menu");
            this.bunifuToolTip1.SetToolTipIcon(this.pictureBox1, null);
            this.bunifuToolTip1.SetToolTipTitle(this.pictureBox1, "");
            this.pictureBox1.Click += new System.EventHandler(this.PictureBox1_Click);
            // 
            // WorkSpace
            // 
            this.WorkSpace.Controls.Add(this.flowLayoutPanel1);
            this.WorkSpace.Controls.Add(this.Searchbar);
            this.bunifuTransitionOnShow.SetDecoration(this.WorkSpace, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.WorkSpace, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.WorkSpace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.WorkSpace.Location = new System.Drawing.Point(220, 34);
            this.WorkSpace.Name = "WorkSpace";
            this.WorkSpace.Size = new System.Drawing.Size(860, 686);
            this.WorkSpace.TabIndex = 2;
            this.bunifuToolTip1.SetToolTip(this.WorkSpace, "");
            this.bunifuToolTip1.SetToolTipIcon(this.WorkSpace, null);
            this.bunifuToolTip1.SetToolTipTitle(this.WorkSpace, "");
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.bunifuTransitionOnHide.SetDecoration(this.flowLayoutPanel1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.flowLayoutPanel1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 53);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(860, 633);
            this.flowLayoutPanel1.TabIndex = 1;
            this.bunifuToolTip1.SetToolTip(this.flowLayoutPanel1, "");
            this.bunifuToolTip1.SetToolTipIcon(this.flowLayoutPanel1, null);
            this.bunifuToolTip1.SetToolTipTitle(this.flowLayoutPanel1, "");
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.SimText);
            this.panel1.Controls.Add(this.ResolutionText);
            this.panel1.Controls.Add(this.DisplaySizeText);
            this.panel1.Controls.Add(this.WarrantyText);
            this.panel1.Controls.Add(this.PriceText);
            this.panel1.Controls.Add(this.ColorText);
            this.panel1.Controls.Add(this.BatteryText);
            this.panel1.Controls.Add(this.BluetoothText);
            this.panel1.Controls.Add(this.WlanText);
            this.panel1.Controls.Add(this.CameraText);
            this.panel1.Controls.Add(this.MemoryText);
            this.panel1.Controls.Add(this.ChipsetText);
            this.panel1.Controls.Add(this.DisplayText);
            this.panel1.Controls.Add(this.DimensionText);
            this.panel1.Controls.Add(this.WeightText);
            this.panel1.Controls.Add(this.bunifuLabel25);
            this.panel1.Controls.Add(this.bunifuLabel21);
            this.panel1.Controls.Add(this.bunifuLabel19);
            this.panel1.Controls.Add(this.bunifuLabel6);
            this.panel1.Controls.Add(this.bunifuLabel48);
            this.panel1.Controls.Add(this.bunifuLabel46);
            this.panel1.Controls.Add(this.bunifuLabel44);
            this.panel1.Controls.Add(this.bunifuLabel41);
            this.panel1.Controls.Add(this.bunifuLabel38);
            this.panel1.Controls.Add(this.bunifuLabel36);
            this.panel1.Controls.Add(this.bunifuLabel33);
            this.panel1.Controls.Add(this.bunifuLabel30);
            this.panel1.Controls.Add(this.bunifuLabel27);
            this.panel1.Controls.Add(this.bunifuLabel17);
            this.panel1.Controls.Add(this.bunifuLabel12);
            this.panel1.Controls.Add(this.LunchText);
            this.panel1.Controls.Add(this.bunifuLabel9);
            this.panel1.Controls.Add(this.NetworkText);
            this.panel1.Controls.Add(this.bunifuLabel8);
            this.panel1.Controls.Add(this.bunifuLabel5);
            this.panel1.Controls.Add(this.bunifuLabel3);
            this.panel1.Controls.Add(this.bunifuLabel43);
            this.panel1.Controls.Add(this.bunifuLabel40);
            this.panel1.Controls.Add(this.bunifuLabel35);
            this.panel1.Controls.Add(this.bunifuLabel32);
            this.panel1.Controls.Add(this.bunifuLabel29);
            this.panel1.Controls.Add(this.bunifuLabel24);
            this.panel1.Controls.Add(this.bunifuLabel2);
            this.panel1.Controls.Add(this.bunifuLabel23);
            this.panel1.Controls.Add(this.bunifuLabel14);
            this.panel1.Controls.Add(this.bunifuLabel7);
            this.panel1.Controls.Add(this.bunifuLabel4);
            this.panel1.Controls.Add(this.bunifuLabel1);
            this.panel1.Controls.Add(this.BrandAndModelName);
            this.panel1.Controls.Add(this.MobileImage);
            this.bunifuTransitionOnShow.SetDecoration(this.panel1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.panel1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(837, 1489);
            this.panel1.TabIndex = 0;
            this.bunifuToolTip1.SetToolTip(this.panel1, "");
            this.bunifuToolTip1.SetToolTipIcon(this.panel1, null);
            this.bunifuToolTip1.SetToolTipTitle(this.panel1, "");
            // 
            // SimText
            // 
            this.SimText.AutoEllipsis = false;
            this.SimText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.SimText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.SimText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.SimText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SimText.ForeColor = System.Drawing.Color.White;
            this.SimText.Location = new System.Drawing.Point(369, 547);
            this.SimText.Name = "SimText";
            this.SimText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SimText.Size = new System.Drawing.Size(77, 20);
            this.SimText.TabIndex = 4;
            this.SimText.Text = "11-12-2017";
            this.SimText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.SimText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.SimText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.SimText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.SimText, "");
            // 
            // ResolutionText
            // 
            this.ResolutionText.AutoEllipsis = false;
            this.ResolutionText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.ResolutionText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.ResolutionText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.ResolutionText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResolutionText.ForeColor = System.Drawing.Color.White;
            this.ResolutionText.Location = new System.Drawing.Point(367, 680);
            this.ResolutionText.Name = "ResolutionText";
            this.ResolutionText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ResolutionText.Size = new System.Drawing.Size(77, 20);
            this.ResolutionText.TabIndex = 4;
            this.ResolutionText.Text = "11-12-2017";
            this.ResolutionText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.ResolutionText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.ResolutionText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.ResolutionText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.ResolutionText, "");
            // 
            // DisplaySizeText
            // 
            this.DisplaySizeText.AutoEllipsis = false;
            this.DisplaySizeText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.DisplaySizeText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.DisplaySizeText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.DisplaySizeText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplaySizeText.ForeColor = System.Drawing.Color.White;
            this.DisplaySizeText.Location = new System.Drawing.Point(369, 654);
            this.DisplaySizeText.Name = "DisplaySizeText";
            this.DisplaySizeText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DisplaySizeText.Size = new System.Drawing.Size(77, 20);
            this.DisplaySizeText.TabIndex = 4;
            this.DisplaySizeText.Text = "11-12-2017";
            this.DisplaySizeText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.DisplaySizeText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.DisplaySizeText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.DisplaySizeText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.DisplaySizeText, "");
            // 
            // WarrantyText
            // 
            this.WarrantyText.AutoEllipsis = false;
            this.WarrantyText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.WarrantyText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.WarrantyText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.WarrantyText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WarrantyText.ForeColor = System.Drawing.Color.White;
            this.WarrantyText.Location = new System.Drawing.Point(345, 1333);
            this.WarrantyText.Name = "WarrantyText";
            this.WarrantyText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.WarrantyText.Size = new System.Drawing.Size(77, 20);
            this.WarrantyText.TabIndex = 4;
            this.WarrantyText.Text = "11-12-2017";
            this.WarrantyText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.WarrantyText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.WarrantyText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.WarrantyText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.WarrantyText, "");
            // 
            // PriceText
            // 
            this.PriceText.AutoEllipsis = false;
            this.PriceText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.PriceText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.PriceText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.PriceText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceText.ForeColor = System.Drawing.Color.White;
            this.PriceText.Location = new System.Drawing.Point(346, 1300);
            this.PriceText.Name = "PriceText";
            this.PriceText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.PriceText.Size = new System.Drawing.Size(77, 20);
            this.PriceText.TabIndex = 4;
            this.PriceText.Text = "11-12-2017";
            this.PriceText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.PriceText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.PriceText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.PriceText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.PriceText, "");
            // 
            // ColorText
            // 
            this.ColorText.AutoEllipsis = false;
            this.ColorText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.ColorText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.ColorText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.ColorText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColorText.ForeColor = System.Drawing.Color.White;
            this.ColorText.Location = new System.Drawing.Point(346, 1263);
            this.ColorText.Name = "ColorText";
            this.ColorText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ColorText.Size = new System.Drawing.Size(77, 20);
            this.ColorText.TabIndex = 4;
            this.ColorText.Text = "11-12-2017";
            this.ColorText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.ColorText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.ColorText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.ColorText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.ColorText, "");
            // 
            // BatteryText
            // 
            this.BatteryText.AutoEllipsis = false;
            this.BatteryText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.BatteryText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.BatteryText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.BatteryText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BatteryText.ForeColor = System.Drawing.Color.White;
            this.BatteryText.Location = new System.Drawing.Point(349, 1154);
            this.BatteryText.Name = "BatteryText";
            this.BatteryText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BatteryText.Size = new System.Drawing.Size(77, 20);
            this.BatteryText.TabIndex = 4;
            this.BatteryText.Text = "11-12-2017";
            this.BatteryText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.BatteryText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.BatteryText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.BatteryText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.BatteryText, "");
            // 
            // BluetoothText
            // 
            this.BluetoothText.AutoEllipsis = false;
            this.BluetoothText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.BluetoothText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.BluetoothText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.BluetoothText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BluetoothText.ForeColor = System.Drawing.Color.White;
            this.BluetoothText.Location = new System.Drawing.Point(355, 1068);
            this.BluetoothText.Name = "BluetoothText";
            this.BluetoothText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BluetoothText.Size = new System.Drawing.Size(77, 20);
            this.BluetoothText.TabIndex = 4;
            this.BluetoothText.Text = "11-12-2017";
            this.BluetoothText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.BluetoothText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.BluetoothText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.BluetoothText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.BluetoothText, "");
            // 
            // WlanText
            // 
            this.WlanText.AutoEllipsis = false;
            this.WlanText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.WlanText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.WlanText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.WlanText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WlanText.ForeColor = System.Drawing.Color.White;
            this.WlanText.Location = new System.Drawing.Point(355, 1039);
            this.WlanText.Name = "WlanText";
            this.WlanText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.WlanText.Size = new System.Drawing.Size(77, 20);
            this.WlanText.TabIndex = 4;
            this.WlanText.Text = "11-12-2017";
            this.WlanText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.WlanText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.WlanText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.WlanText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.WlanText, "");
            // 
            // CameraText
            // 
            this.CameraText.AutoEllipsis = false;
            this.CameraText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.CameraText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.CameraText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.CameraText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CameraText.ForeColor = System.Drawing.Color.White;
            this.CameraText.Location = new System.Drawing.Point(366, 948);
            this.CameraText.Name = "CameraText";
            this.CameraText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CameraText.Size = new System.Drawing.Size(77, 20);
            this.CameraText.TabIndex = 4;
            this.CameraText.Text = "11-12-2017";
            this.CameraText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.CameraText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.CameraText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.CameraText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.CameraText, "");
            // 
            // MemoryText
            // 
            this.MemoryText.AutoEllipsis = false;
            this.MemoryText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.MemoryText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.MemoryText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.MemoryText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemoryText.ForeColor = System.Drawing.Color.White;
            this.MemoryText.Location = new System.Drawing.Point(367, 847);
            this.MemoryText.Name = "MemoryText";
            this.MemoryText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MemoryText.Size = new System.Drawing.Size(77, 20);
            this.MemoryText.TabIndex = 4;
            this.MemoryText.Text = "11-12-2017";
            this.MemoryText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.MemoryText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.MemoryText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.MemoryText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.MemoryText, "");
            // 
            // ChipsetText
            // 
            this.ChipsetText.AutoEllipsis = false;
            this.ChipsetText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.ChipsetText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.ChipsetText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.ChipsetText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChipsetText.ForeColor = System.Drawing.Color.White;
            this.ChipsetText.Location = new System.Drawing.Point(369, 767);
            this.ChipsetText.Name = "ChipsetText";
            this.ChipsetText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ChipsetText.Size = new System.Drawing.Size(77, 20);
            this.ChipsetText.TabIndex = 4;
            this.ChipsetText.Text = "11-12-2017";
            this.ChipsetText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.ChipsetText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.ChipsetText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.ChipsetText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.ChipsetText, "");
            // 
            // DisplayText
            // 
            this.DisplayText.AutoEllipsis = false;
            this.DisplayText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.DisplayText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.DisplayText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.DisplayText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayText.ForeColor = System.Drawing.Color.White;
            this.DisplayText.Location = new System.Drawing.Point(369, 628);
            this.DisplayText.Name = "DisplayText";
            this.DisplayText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DisplayText.Size = new System.Drawing.Size(77, 20);
            this.DisplayText.TabIndex = 4;
            this.DisplayText.Text = "11-12-2017";
            this.DisplayText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.DisplayText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.DisplayText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.DisplayText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.DisplayText, "");
            // 
            // DimensionText
            // 
            this.DimensionText.AutoEllipsis = false;
            this.DimensionText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.DimensionText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.DimensionText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.DimensionText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DimensionText.ForeColor = System.Drawing.Color.White;
            this.DimensionText.Location = new System.Drawing.Point(369, 495);
            this.DimensionText.Name = "DimensionText";
            this.DimensionText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DimensionText.Size = new System.Drawing.Size(77, 20);
            this.DimensionText.TabIndex = 4;
            this.DimensionText.Text = "11-12-2017";
            this.DimensionText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.DimensionText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.DimensionText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.DimensionText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.DimensionText, "");
            // 
            // WeightText
            // 
            this.WeightText.AutoEllipsis = false;
            this.WeightText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.WeightText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.WeightText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.WeightText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WeightText.ForeColor = System.Drawing.Color.White;
            this.WeightText.Location = new System.Drawing.Point(369, 521);
            this.WeightText.Name = "WeightText";
            this.WeightText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.WeightText.Size = new System.Drawing.Size(77, 20);
            this.WeightText.TabIndex = 4;
            this.WeightText.Text = "11-12-2017";
            this.WeightText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.WeightText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.WeightText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.WeightText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.WeightText, "");
            // 
            // bunifuLabel25
            // 
            this.bunifuLabel25.AutoEllipsis = false;
            this.bunifuLabel25.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel25, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel25, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel25.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel25.Location = new System.Drawing.Point(243, 680);
            this.bunifuLabel25.Name = "bunifuLabel25";
            this.bunifuLabel25.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel25.Size = new System.Drawing.Size(84, 20);
            this.bunifuLabel25.TabIndex = 3;
            this.bunifuLabel25.Text = "Resolution";
            this.bunifuLabel25.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel25.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel25, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel25, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel25, "");
            // 
            // bunifuLabel21
            // 
            this.bunifuLabel21.AutoEllipsis = false;
            this.bunifuLabel21.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel21, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel21, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel21.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel21.Location = new System.Drawing.Point(243, 680);
            this.bunifuLabel21.Name = "bunifuLabel21";
            this.bunifuLabel21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel21.Size = new System.Drawing.Size(84, 20);
            this.bunifuLabel21.TabIndex = 3;
            this.bunifuLabel21.Text = "Resolution";
            this.bunifuLabel21.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel21.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel21, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel21, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel21, "");
            // 
            // bunifuLabel19
            // 
            this.bunifuLabel19.AutoEllipsis = false;
            this.bunifuLabel19.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel19, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel19, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel19.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel19.Location = new System.Drawing.Point(245, 654);
            this.bunifuLabel19.Name = "bunifuLabel19";
            this.bunifuLabel19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel19.Size = new System.Drawing.Size(36, 20);
            this.bunifuLabel19.TabIndex = 3;
            this.bunifuLabel19.Text = "Size";
            this.bunifuLabel19.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel19.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel19, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel19, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel19, "");
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel6, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel6, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel6.Location = new System.Drawing.Point(295, 1417);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(79, 22);
            this.bunifuLabel6.TabIndex = 3;
            this.bunifuLabel6.Text = "Warranty";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel6, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel6, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel6, "");
            // 
            // bunifuLabel48
            // 
            this.bunifuLabel48.AutoEllipsis = false;
            this.bunifuLabel48.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel48, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel48, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel48.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel48.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel48.Location = new System.Drawing.Point(221, 1333);
            this.bunifuLabel48.Name = "bunifuLabel48";
            this.bunifuLabel48.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel48.Size = new System.Drawing.Size(71, 20);
            this.bunifuLabel48.TabIndex = 3;
            this.bunifuLabel48.Text = "Warranty";
            this.bunifuLabel48.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel48.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel48, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel48, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel48, "");
            // 
            // bunifuLabel46
            // 
            this.bunifuLabel46.AutoEllipsis = false;
            this.bunifuLabel46.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel46, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel46, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel46.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel46.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel46.Location = new System.Drawing.Point(222, 1300);
            this.bunifuLabel46.Name = "bunifuLabel46";
            this.bunifuLabel46.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel46.Size = new System.Drawing.Size(42, 20);
            this.bunifuLabel46.TabIndex = 3;
            this.bunifuLabel46.Text = "Price";
            this.bunifuLabel46.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel46.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel46, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel46, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel46, "");
            // 
            // bunifuLabel44
            // 
            this.bunifuLabel44.AutoEllipsis = false;
            this.bunifuLabel44.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel44, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel44, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel44.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel44.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel44.Location = new System.Drawing.Point(222, 1263);
            this.bunifuLabel44.Name = "bunifuLabel44";
            this.bunifuLabel44.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel44.Size = new System.Drawing.Size(45, 20);
            this.bunifuLabel44.TabIndex = 3;
            this.bunifuLabel44.Text = "Color";
            this.bunifuLabel44.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel44.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel44, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel44, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel44, "");
            // 
            // bunifuLabel41
            // 
            this.bunifuLabel41.AutoEllipsis = false;
            this.bunifuLabel41.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel41, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel41, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel41.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel41.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel41.Location = new System.Drawing.Point(225, 1154);
            this.bunifuLabel41.Name = "bunifuLabel41";
            this.bunifuLabel41.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel41.Size = new System.Drawing.Size(39, 20);
            this.bunifuLabel41.TabIndex = 3;
            this.bunifuLabel41.Text = "Type";
            this.bunifuLabel41.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel41.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel41, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel41, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel41, "");
            // 
            // bunifuLabel38
            // 
            this.bunifuLabel38.AutoEllipsis = false;
            this.bunifuLabel38.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel38, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel38, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel38.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel38.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel38.Location = new System.Drawing.Point(231, 1068);
            this.bunifuLabel38.Name = "bunifuLabel38";
            this.bunifuLabel38.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel38.Size = new System.Drawing.Size(75, 20);
            this.bunifuLabel38.TabIndex = 3;
            this.bunifuLabel38.Text = "Bluetooth";
            this.bunifuLabel38.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel38.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel38, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel38, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel38, "");
            // 
            // bunifuLabel36
            // 
            this.bunifuLabel36.AutoEllipsis = false;
            this.bunifuLabel36.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel36, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel36, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel36.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel36.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel36.Location = new System.Drawing.Point(231, 1039);
            this.bunifuLabel36.Name = "bunifuLabel36";
            this.bunifuLabel36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel36.Size = new System.Drawing.Size(32, 20);
            this.bunifuLabel36.TabIndex = 3;
            this.bunifuLabel36.Text = "Wifi";
            this.bunifuLabel36.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel36.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel36, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel36, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel36, "");
            // 
            // bunifuLabel33
            // 
            this.bunifuLabel33.AutoEllipsis = false;
            this.bunifuLabel33.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel33, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel33, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel33.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel33.Location = new System.Drawing.Point(242, 948);
            this.bunifuLabel33.Name = "bunifuLabel33";
            this.bunifuLabel33.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel33.Size = new System.Drawing.Size(69, 20);
            this.bunifuLabel33.TabIndex = 3;
            this.bunifuLabel33.Text = "Features";
            this.bunifuLabel33.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel33.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel33, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel33, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel33, "");
            // 
            // bunifuLabel30
            // 
            this.bunifuLabel30.AutoEllipsis = false;
            this.bunifuLabel30.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel30, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel30, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel30.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel30.Location = new System.Drawing.Point(243, 847);
            this.bunifuLabel30.Name = "bunifuLabel30";
            this.bunifuLabel30.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel30.Size = new System.Drawing.Size(58, 20);
            this.bunifuLabel30.TabIndex = 3;
            this.bunifuLabel30.Text = "Internal";
            this.bunifuLabel30.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel30.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel30, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel30, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel30, "");
            // 
            // bunifuLabel27
            // 
            this.bunifuLabel27.AutoEllipsis = false;
            this.bunifuLabel27.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel27, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel27, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel27.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel27.Location = new System.Drawing.Point(245, 767);
            this.bunifuLabel27.Name = "bunifuLabel27";
            this.bunifuLabel27.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel27.Size = new System.Drawing.Size(60, 20);
            this.bunifuLabel27.TabIndex = 3;
            this.bunifuLabel27.Text = "Chipset";
            this.bunifuLabel27.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel27.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel27, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel27, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel27, "");
            // 
            // bunifuLabel17
            // 
            this.bunifuLabel17.AutoEllipsis = false;
            this.bunifuLabel17.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel17, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel17, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel17.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel17.Location = new System.Drawing.Point(245, 628);
            this.bunifuLabel17.Name = "bunifuLabel17";
            this.bunifuLabel17.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel17.Size = new System.Drawing.Size(39, 20);
            this.bunifuLabel17.TabIndex = 3;
            this.bunifuLabel17.Text = "Type";
            this.bunifuLabel17.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel17.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel17, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel17, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel17, "");
            // 
            // bunifuLabel12
            // 
            this.bunifuLabel12.AutoEllipsis = false;
            this.bunifuLabel12.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel12, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel12, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel12.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel12.Location = new System.Drawing.Point(243, 547);
            this.bunifuLabel12.Name = "bunifuLabel12";
            this.bunifuLabel12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel12.Size = new System.Drawing.Size(32, 20);
            this.bunifuLabel12.TabIndex = 3;
            this.bunifuLabel12.Text = "Sim";
            this.bunifuLabel12.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel12.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel12, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel12, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel12, "");
            // 
            // LunchText
            // 
            this.LunchText.AutoEllipsis = false;
            this.LunchText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.LunchText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.LunchText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.LunchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LunchText.ForeColor = System.Drawing.Color.White;
            this.LunchText.Location = new System.Drawing.Point(369, 420);
            this.LunchText.Name = "LunchText";
            this.LunchText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LunchText.Size = new System.Drawing.Size(77, 20);
            this.LunchText.TabIndex = 4;
            this.LunchText.Text = "11-12-2017";
            this.LunchText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.LunchText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.LunchText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.LunchText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.LunchText, "");
            // 
            // bunifuLabel9
            // 
            this.bunifuLabel9.AutoEllipsis = false;
            this.bunifuLabel9.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel9, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel9, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel9.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel9.Location = new System.Drawing.Point(245, 521);
            this.bunifuLabel9.Name = "bunifuLabel9";
            this.bunifuLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel9.Size = new System.Drawing.Size(55, 20);
            this.bunifuLabel9.TabIndex = 3;
            this.bunifuLabel9.Text = "Weight";
            this.bunifuLabel9.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel9.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel9, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel9, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel9, "");
            // 
            // NetworkText
            // 
            this.NetworkText.AutoEllipsis = false;
            this.NetworkText.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.NetworkText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.NetworkText, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.NetworkText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetworkText.ForeColor = System.Drawing.Color.White;
            this.NetworkText.Location = new System.Drawing.Point(369, 339);
            this.NetworkText.Name = "NetworkText";
            this.NetworkText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.NetworkText.Size = new System.Drawing.Size(95, 20);
            this.NetworkText.TabIndex = 4;
            this.NetworkText.Text = "2G/3G/4G/5G";
            this.NetworkText.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.NetworkText.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.NetworkText, "");
            this.bunifuToolTip1.SetToolTipIcon(this.NetworkText, null);
            this.bunifuToolTip1.SetToolTipTitle(this.NetworkText, "");
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel8, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel8, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel8.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel8.Location = new System.Drawing.Point(243, 495);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(83, 20);
            this.bunifuLabel8.TabIndex = 3;
            this.bunifuLabel8.Text = "Dimension";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel8, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel8, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel8, "");
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel5, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel5, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel5.Location = new System.Drawing.Point(243, 420);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(88, 20);
            this.bunifuLabel5.TabIndex = 3;
            this.bunifuLabel5.Text = "Lunch Date";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel5, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel5, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel5, "");
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel3.Location = new System.Drawing.Point(151, 1379);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(147, 27);
            this.bunifuLabel3.TabIndex = 2;
            this.bunifuLabel3.Text = "AVAILABILITY";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel3, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel3, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel3, "");
            // 
            // bunifuLabel43
            // 
            this.bunifuLabel43.AutoEllipsis = false;
            this.bunifuLabel43.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel43, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel43, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel43.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel43.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel43.Location = new System.Drawing.Point(146, 1221);
            this.bunifuLabel43.Name = "bunifuLabel43";
            this.bunifuLabel43.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel43.Size = new System.Drawing.Size(58, 27);
            this.bunifuLabel43.TabIndex = 2;
            this.bunifuLabel43.Text = "MISC";
            this.bunifuLabel43.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel43.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel43, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel43, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel43, "");
            // 
            // bunifuLabel40
            // 
            this.bunifuLabel40.AutoEllipsis = false;
            this.bunifuLabel40.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel40, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel40, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel40.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel40.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel40.Location = new System.Drawing.Point(152, 1124);
            this.bunifuLabel40.Name = "bunifuLabel40";
            this.bunifuLabel40.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel40.Size = new System.Drawing.Size(102, 27);
            this.bunifuLabel40.TabIndex = 2;
            this.bunifuLabel40.Text = "BATTERY";
            this.bunifuLabel40.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel40.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel40, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel40, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel40, "");
            // 
            // bunifuLabel35
            // 
            this.bunifuLabel35.AutoEllipsis = false;
            this.bunifuLabel35.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel35, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel35, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel35.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel35.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel35.Location = new System.Drawing.Point(153, 1001);
            this.bunifuLabel35.Name = "bunifuLabel35";
            this.bunifuLabel35.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel35.Size = new System.Drawing.Size(87, 27);
            this.bunifuLabel35.TabIndex = 2;
            this.bunifuLabel35.Text = "COMMS";
            this.bunifuLabel35.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel35.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel35, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel35, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel35, "");
            // 
            // bunifuLabel32
            // 
            this.bunifuLabel32.AutoEllipsis = false;
            this.bunifuLabel32.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel32, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel32, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel32.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel32.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel32.Location = new System.Drawing.Point(159, 906);
            this.bunifuLabel32.Name = "bunifuLabel32";
            this.bunifuLabel32.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel32.Size = new System.Drawing.Size(95, 27);
            this.bunifuLabel32.TabIndex = 2;
            this.bunifuLabel32.Text = "CAMERA";
            this.bunifuLabel32.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel32.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel32, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel32, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel32, "");
            // 
            // bunifuLabel29
            // 
            this.bunifuLabel29.AutoEllipsis = false;
            this.bunifuLabel29.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel29, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel29, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel29.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel29.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel29.Location = new System.Drawing.Point(164, 809);
            this.bunifuLabel29.Name = "bunifuLabel29";
            this.bunifuLabel29.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel29.Size = new System.Drawing.Size(98, 27);
            this.bunifuLabel29.TabIndex = 2;
            this.bunifuLabel29.Text = "MEMORY";
            this.bunifuLabel29.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel29.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel29, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel29, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel29, "");
            // 
            // bunifuLabel24
            // 
            this.bunifuLabel24.AutoEllipsis = false;
            this.bunifuLabel24.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel24, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel24, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel24.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel24.Location = new System.Drawing.Point(163, 724);
            this.bunifuLabel24.Name = "bunifuLabel24";
            this.bunifuLabel24.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel24.Size = new System.Drawing.Size(120, 27);
            this.bunifuLabel24.TabIndex = 2;
            this.bunifuLabel24.Text = "PLATFORM";
            this.bunifuLabel24.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel24.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel24, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel24, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel24, "");
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuLabel2.Location = new System.Drawing.Point(243, 339);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(100, 20);
            this.bunifuLabel2.TabIndex = 3;
            this.bunifuLabel2.Text = "Techonology";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel2, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel2, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel2, "");
            // 
            // bunifuLabel23
            // 
            this.bunifuLabel23.AutoEllipsis = false;
            this.bunifuLabel23.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel23, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel23, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel23.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel23.Location = new System.Drawing.Point(163, 724);
            this.bunifuLabel23.Name = "bunifuLabel23";
            this.bunifuLabel23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel23.Size = new System.Drawing.Size(94, 27);
            this.bunifuLabel23.TabIndex = 2;
            this.bunifuLabel23.Text = "DISPLAY";
            this.bunifuLabel23.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel23.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel23, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel23, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel23, "");
            // 
            // bunifuLabel14
            // 
            this.bunifuLabel14.AutoEllipsis = false;
            this.bunifuLabel14.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel14, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel14, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel14.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel14.Location = new System.Drawing.Point(163, 584);
            this.bunifuLabel14.Name = "bunifuLabel14";
            this.bunifuLabel14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel14.Size = new System.Drawing.Size(94, 27);
            this.bunifuLabel14.TabIndex = 2;
            this.bunifuLabel14.Text = "DISPLAY";
            this.bunifuLabel14.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel14.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel14, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel14, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel14, "");
            // 
            // bunifuLabel7
            // 
            this.bunifuLabel7.AutoEllipsis = false;
            this.bunifuLabel7.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel7, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel7, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel7.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel7.Location = new System.Drawing.Point(163, 463);
            this.bunifuLabel7.Name = "bunifuLabel7";
            this.bunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel7.Size = new System.Drawing.Size(62, 27);
            this.bunifuLabel7.TabIndex = 2;
            this.bunifuLabel7.Text = "BOBY";
            this.bunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel7, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel7, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel7, "");
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel4.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel4.Location = new System.Drawing.Point(163, 387);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(76, 27);
            this.bunifuLabel4.TabIndex = 2;
            this.bunifuLabel4.Text = "LUNCH";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel4, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel4, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel4, "");
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuLabel1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuLabel1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel1.Location = new System.Drawing.Point(163, 301);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(113, 27);
            this.bunifuLabel1.TabIndex = 2;
            this.bunifuLabel1.Text = "NETWORK";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.bunifuLabel1, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuLabel1, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuLabel1, "");
            // 
            // BrandAndModelName
            // 
            this.BrandAndModelName.AutoEllipsis = false;
            this.BrandAndModelName.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.BrandAndModelName, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.BrandAndModelName, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.BrandAndModelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BrandAndModelName.ForeColor = System.Drawing.Color.White;
            this.BrandAndModelName.Location = new System.Drawing.Point(349, 23);
            this.BrandAndModelName.Name = "BrandAndModelName";
            this.BrandAndModelName.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BrandAndModelName.Size = new System.Drawing.Size(115, 27);
            this.BrandAndModelName.TabIndex = 1;
            this.BrandAndModelName.Text = "bunifuLabel1";
            this.BrandAndModelName.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.BrandAndModelName.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.BrandAndModelName, "");
            this.bunifuToolTip1.SetToolTipIcon(this.BrandAndModelName, null);
            this.bunifuToolTip1.SetToolTipTitle(this.BrandAndModelName, "");
            // 
            // MobileImage
            // 
            this.bunifuTransitionOnHide.SetDecoration(this.MobileImage, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.MobileImage, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.MobileImage.Location = new System.Drawing.Point(317, 65);
            this.MobileImage.Name = "MobileImage";
            this.MobileImage.Size = new System.Drawing.Size(180, 220);
            this.MobileImage.TabIndex = 0;
            this.MobileImage.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.MobileImage, "");
            this.bunifuToolTip1.SetToolTipIcon(this.MobileImage, null);
            this.bunifuToolTip1.SetToolTipTitle(this.MobileImage, "");
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.bunifuButton4);
            this.panel2.Controls.Add(this.pictureBox4);
            this.bunifuTransitionOnShow.SetDecoration(this.panel2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.panel2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.panel2.Location = new System.Drawing.Point(3, 1498);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(837, 162);
            this.panel2.TabIndex = 1;
            this.bunifuToolTip1.SetToolTip(this.panel2, "");
            this.bunifuToolTip1.SetToolTipIcon(this.panel2, null);
            this.bunifuToolTip1.SetToolTipTitle(this.panel2, "");
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.bunifuImageButton6);
            this.panel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransitionOnShow.SetDecoration(this.panel5, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.panel5, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.panel5.Location = new System.Drawing.Point(741, 56);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(47, 39);
            this.panel5.TabIndex = 0;
            this.bunifuToolTip1.SetToolTip(this.panel5, "");
            this.bunifuToolTip1.SetToolTipIcon(this.panel5, null);
            this.bunifuToolTip1.SetToolTipTitle(this.panel5, "");
            // 
            // bunifuImageButton6
            // 
            this.bunifuImageButton6.ActiveImage = null;
            this.bunifuImageButton6.AllowAnimations = true;
            this.bunifuImageButton6.AllowZooming = true;
            this.bunifuImageButton6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuImageButton6, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuImageButton6, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuImageButton6.Enabled = false;
            this.bunifuImageButton6.ErrorImage = global::Online_Mobile_Shop.Properties.Resources.icons8_plus_96;
            this.bunifuImageButton6.FadeWhenInactive = false;
            this.bunifuImageButton6.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton6.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_minus_96;
            this.bunifuImageButton6.ImageActive = null;
            this.bunifuImageButton6.ImageLocation = null;
            this.bunifuImageButton6.ImageMargin = 15;
            this.bunifuImageButton6.ImageSize = new System.Drawing.Size(26, 18);
            this.bunifuImageButton6.ImageZoomSize = new System.Drawing.Size(41, 33);
            this.bunifuImageButton6.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton6.InitialImage")));
            this.bunifuImageButton6.Location = new System.Drawing.Point(2, 3);
            this.bunifuImageButton6.Name = "bunifuImageButton6";
            this.bunifuImageButton6.Rotation = 0;
            this.bunifuImageButton6.ShowActiveImage = true;
            this.bunifuImageButton6.ShowCursorChanges = true;
            this.bunifuImageButton6.ShowImageBorders = true;
            this.bunifuImageButton6.ShowSizeMarkers = false;
            this.bunifuImageButton6.Size = new System.Drawing.Size(41, 33);
            this.bunifuImageButton6.TabIndex = 5;
            this.bunifuToolTip1.SetToolTip(this.bunifuImageButton6, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuImageButton6, null);
            this.bunifuImageButton6.ToolTipText = "";
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuImageButton6, "");
            this.bunifuImageButton6.WaitOnLoad = false;
            this.bunifuImageButton6.Zoom = 15;
            this.bunifuImageButton6.ZoomSpeed = 10;
            this.bunifuImageButton6.Click += new System.EventHandler(this.BunifuImageButton6_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.bunifuImageButton5);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransitionOnShow.SetDecoration(this.panel4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.panel4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.panel4.Location = new System.Drawing.Point(615, 56);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(47, 39);
            this.panel4.TabIndex = 0;
            this.bunifuToolTip1.SetToolTip(this.panel4, "");
            this.bunifuToolTip1.SetToolTipIcon(this.panel4, null);
            this.bunifuToolTip1.SetToolTipTitle(this.panel4, "");
            // 
            // bunifuImageButton5
            // 
            this.bunifuImageButton5.ActiveImage = null;
            this.bunifuImageButton5.AllowAnimations = true;
            this.bunifuImageButton5.AllowZooming = true;
            this.bunifuImageButton5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuImageButton5, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuImageButton5, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuImageButton5.Enabled = false;
            this.bunifuImageButton5.ErrorImage = global::Online_Mobile_Shop.Properties.Resources.icons8_plus_96;
            this.bunifuImageButton5.FadeWhenInactive = false;
            this.bunifuImageButton5.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton5.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_plus_96;
            this.bunifuImageButton5.ImageActive = null;
            this.bunifuImageButton5.ImageLocation = null;
            this.bunifuImageButton5.ImageMargin = 15;
            this.bunifuImageButton5.ImageSize = new System.Drawing.Size(26, 18);
            this.bunifuImageButton5.ImageZoomSize = new System.Drawing.Size(41, 33);
            this.bunifuImageButton5.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton5.InitialImage")));
            this.bunifuImageButton5.Location = new System.Drawing.Point(3, 4);
            this.bunifuImageButton5.Name = "bunifuImageButton5";
            this.bunifuImageButton5.Rotation = 0;
            this.bunifuImageButton5.ShowActiveImage = true;
            this.bunifuImageButton5.ShowCursorChanges = true;
            this.bunifuImageButton5.ShowImageBorders = true;
            this.bunifuImageButton5.ShowSizeMarkers = false;
            this.bunifuImageButton5.Size = new System.Drawing.Size(41, 33);
            this.bunifuImageButton5.TabIndex = 5;
            this.bunifuToolTip1.SetToolTip(this.bunifuImageButton5, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuImageButton5, null);
            this.bunifuImageButton5.ToolTipText = "";
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuImageButton5, "");
            this.bunifuImageButton5.WaitOnLoad = false;
            this.bunifuImageButton5.Zoom = 15;
            this.bunifuImageButton5.ZoomSpeed = 10;
            this.bunifuImageButton5.Click += new System.EventHandler(this.BunifuImageButton5_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(50)))));
            this.panel3.Controls.Add(this.QuantityLabel);
            this.bunifuTransitionOnShow.SetDecoration(this.panel3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.panel3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.panel3.Location = new System.Drawing.Point(615, 56);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(161, 39);
            this.panel3.TabIndex = 2;
            this.bunifuToolTip1.SetToolTip(this.panel3, "");
            this.bunifuToolTip1.SetToolTipIcon(this.panel3, null);
            this.bunifuToolTip1.SetToolTipTitle(this.panel3, "");
            // 
            // QuantityLabel
            // 
            this.QuantityLabel.AutoEllipsis = false;
            this.QuantityLabel.CursorType = null;
            this.bunifuTransitionOnShow.SetDecoration(this.QuantityLabel, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.QuantityLabel, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.QuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityLabel.ForeColor = System.Drawing.Color.White;
            this.QuantityLabel.Location = new System.Drawing.Point(79, 7);
            this.QuantityLabel.Name = "QuantityLabel";
            this.QuantityLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.QuantityLabel.Size = new System.Drawing.Size(16, 31);
            this.QuantityLabel.TabIndex = 4;
            this.QuantityLabel.Text = "0";
            this.QuantityLabel.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.QuantityLabel.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuToolTip1.SetToolTip(this.QuantityLabel, "");
            this.bunifuToolTip1.SetToolTipIcon(this.QuantityLabel, null);
            this.bunifuToolTip1.SetToolTipTitle(this.QuantityLabel, "");
            // 
            // bunifuButton4
            // 
            this.bunifuButton4.AllowToggling = false;
            this.bunifuButton4.AnimationSpeed = 200;
            this.bunifuButton4.AutoGenerateColors = true;
            this.bunifuButton4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton4.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.bunifuButton4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton4.BackgroundImage")));
            this.bunifuButton4.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton4.ButtonText = "Add To Cart";
            this.bunifuButton4.ButtonTextMarginLeft = 0;
            this.bunifuButton4.ColorContrastOnClick = 45;
            this.bunifuButton4.ColorContrastOnHover = 45;
            this.bunifuButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.bunifuButton4.CustomizableEdges = borderEdges1;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuButton4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuButton4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton4.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton4.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton4.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton4.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton4.ForeColor = System.Drawing.Color.White;
            this.bunifuButton4.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton4.IconMarginLeft = 11;
            this.bunifuButton4.IconPadding = 10;
            this.bunifuButton4.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton4.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.bunifuButton4.IdleBorderRadius = 3;
            this.bunifuButton4.IdleBorderThickness = 1;
            this.bunifuButton4.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.bunifuButton4.IdleIconLeftImage = global::Online_Mobile_Shop.Properties.Resources.icons8_add_shopping_cart_100;
            this.bunifuButton4.IdleIconRightImage = null;
            this.bunifuButton4.IndicateFocus = false;
            this.bunifuButton4.Location = new System.Drawing.Point(581, 106);
            this.bunifuButton4.Name = "bunifuButton4";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(141)))), ((int)(((byte)(146)))));
            stateProperties1.BorderRadius = 3;
            stateProperties1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties1.BorderThickness = 1;
            stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(141)))), ((int)(((byte)(146)))));
            stateProperties1.ForeColor = System.Drawing.Color.White;
            stateProperties1.IconLeftImage = null;
            stateProperties1.IconRightImage = null;
            this.bunifuButton4.onHoverState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(26)))), ((int)(((byte)(31)))));
            stateProperties2.BorderRadius = 3;
            stateProperties2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties2.BorderThickness = 1;
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(26)))), ((int)(((byte)(31)))));
            stateProperties2.ForeColor = System.Drawing.Color.White;
            stateProperties2.IconLeftImage = null;
            stateProperties2.IconRightImage = null;
            this.bunifuButton4.OnPressedState = stateProperties2;
            this.bunifuButton4.Size = new System.Drawing.Size(210, 45);
            this.bunifuButton4.TabIndex = 1;
            this.bunifuButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton4.TextMarginLeft = 0;
            this.bunifuToolTip1.SetToolTip(this.bunifuButton4, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuButton4, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuButton4, "");
            this.bunifuButton4.Click += new System.EventHandler(this.BunifuButton4_Click);
            // 
            // pictureBox4
            // 
            this.bunifuTransitionOnHide.SetDecoration(this.pictureBox4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.pictureBox4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.pictureBox4.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_add_property_100;
            this.pictureBox4.Location = new System.Drawing.Point(503, 45);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(68, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.pictureBox4, "Add To WishList");
            this.bunifuToolTip1.SetToolTipIcon(this.pictureBox4, null);
            this.bunifuToolTip1.SetToolTipTitle(this.pictureBox4, "");
            this.pictureBox4.Click += new System.EventHandler(this.PictureBox4_Click);
            // 
            // Searchbar
            // 
            this.Searchbar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.Searchbar.Controls.Add(this.Login);
            this.Searchbar.Controls.Add(this.pictureBox3);
            this.Searchbar.Controls.Add(this.pictureBox5);
            this.Searchbar.Controls.Add(this.pictureBox2);
            this.Searchbar.Controls.Add(this.bunifuTextBox1);
            this.bunifuTransitionOnShow.SetDecoration(this.Searchbar, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.Searchbar, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.Searchbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.Searchbar.Location = new System.Drawing.Point(0, 0);
            this.Searchbar.Name = "Searchbar";
            this.Searchbar.Size = new System.Drawing.Size(860, 53);
            this.Searchbar.TabIndex = 0;
            this.bunifuToolTip1.SetToolTip(this.Searchbar, "");
            this.bunifuToolTip1.SetToolTipIcon(this.Searchbar, null);
            this.bunifuToolTip1.SetToolTipTitle(this.Searchbar, "");
            // 
            // Login
            // 
            this.Login.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuTransitionOnHide.SetDecoration(this.Login, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.Login, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.Login.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_login_50;
            this.Login.Location = new System.Drawing.Point(787, 6);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(56, 44);
            this.Login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Login.TabIndex = 1;
            this.Login.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.Login, "Login");
            this.bunifuToolTip1.SetToolTipIcon(this.Login, null);
            this.bunifuToolTip1.SetToolTipTitle(this.Login, "");
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuTransitionOnHide.SetDecoration(this.pictureBox3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.pictureBox3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.pictureBox3.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_shopping_cart_48;
            this.pictureBox3.Location = new System.Drawing.Point(711, 6);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(56, 44);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.pictureBox3, "Cart");
            this.bunifuToolTip1.SetToolTipIcon(this.pictureBox3, null);
            this.bunifuToolTip1.SetToolTipTitle(this.pictureBox3, "");
            this.pictureBox3.Visible = false;
            this.pictureBox3.Click += new System.EventHandler(this.PictureBox3_Click);
            // 
            // pictureBox5
            // 
            this.bunifuTransitionOnHide.SetDecoration(this.pictureBox5, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.pictureBox5, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.pictureBox5.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_arrow_pointing_left_48;
            this.pictureBox5.Location = new System.Drawing.Point(370, 10);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(68, 35);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.pictureBox5, "Search");
            this.bunifuToolTip1.SetToolTipIcon(this.pictureBox5, null);
            this.bunifuToolTip1.SetToolTipTitle(this.pictureBox5, "");
            this.pictureBox5.Click += new System.EventHandler(this.PictureBox5_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuTransitionOnHide.SetDecoration(this.pictureBox2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.pictureBox2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.pictureBox2.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_wish_list_48;
            this.pictureBox2.Location = new System.Drawing.Point(639, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(56, 44);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.pictureBox2, "Wish List");
            this.bunifuToolTip1.SetToolTipIcon(this.pictureBox2, null);
            this.bunifuToolTip1.SetToolTipTitle(this.pictureBox2, "");
            this.pictureBox2.Visible = false;
            this.pictureBox2.Click += new System.EventHandler(this.PictureBox2_Click);
            // 
            // bunifuTextBox1
            // 
            this.bunifuTextBox1.AcceptsReturn = false;
            this.bunifuTextBox1.AcceptsTab = false;
            this.bunifuTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuTextBox1.AnimationSpeed = 200;
            this.bunifuTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.bunifuTextBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox1.BackgroundImage")));
            this.bunifuTextBox1.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox1.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox1.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox1.BorderRadius = 1;
            this.bunifuTextBox1.BorderThickness = 1;
            this.bunifuTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuTextBox1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuTextBox1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTextBox1.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuTextBox1.DefaultText = "";
            this.bunifuTextBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            this.bunifuTextBox1.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox1.HideSelection = true;
            this.bunifuTextBox1.IconLeft = global::Online_Mobile_Shop.Properties.Resources.iconfinder_icon_111_search_314478;
            this.bunifuTextBox1.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox1.IconPadding = 10;
            this.bunifuTextBox1.IconRight = null;
            this.bunifuTextBox1.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox1.Lines = new string[0];
            this.bunifuTextBox1.Location = new System.Drawing.Point(6, 10);
            this.bunifuTextBox1.MaxLength = 32767;
            this.bunifuTextBox1.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox1.Modified = false;
            this.bunifuTextBox1.Multiline = false;
            this.bunifuTextBox1.Name = "bunifuTextBox1";
            stateProperties3.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox1.OnActiveState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Empty;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox1.OnDisabledState = stateProperties4;
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox1.OnHoverState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(49)))), ((int)(((byte)(57)))));
            stateProperties6.ForeColor = System.Drawing.Color.Silver;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox1.OnIdleState = stateProperties6;
            this.bunifuTextBox1.PasswordChar = '\0';
            this.bunifuTextBox1.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox1.PlaceholderText = "Search";
            this.bunifuTextBox1.ReadOnly = false;
            this.bunifuTextBox1.SelectedText = "";
            this.bunifuTextBox1.SelectionLength = 0;
            this.bunifuTextBox1.SelectionStart = 0;
            this.bunifuTextBox1.ShortcutsEnabled = true;
            this.bunifuTextBox1.Size = new System.Drawing.Size(363, 35);
            this.bunifuTextBox1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox1.TabIndex = 0;
            this.bunifuTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox1.TextMarginBottom = 0;
            this.bunifuTextBox1.TextMarginLeft = 5;
            this.bunifuTextBox1.TextMarginTop = 0;
            this.bunifuTextBox1.TextPlaceholder = "Search";
            this.bunifuToolTip1.SetToolTip(this.bunifuTextBox1, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuTextBox1, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuTextBox1, "");
            this.bunifuTextBox1.UseSystemPasswordChar = false;
            this.bunifuTextBox1.WordWrap = true;
            this.bunifuTextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.BunifuTextBox1_KeyPress);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.Header;
            this.bunifuDragControl1.Vertical = true;
            // 
            // Header
            // 
            this.Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(42)))), ((int)(((byte)(170)))));
            this.Header.Controls.Add(this.TitlePic);
            this.Header.Controls.Add(this.TitleLb);
            this.Header.Controls.Add(this.bunifuImageButton4);
            this.Header.Controls.Add(this.bunifuImageButton3);
            this.Header.Controls.Add(this.bunifuImageButton2);
            this.Header.Controls.Add(this.bunifuImageButton1);
            this.bunifuTransitionOnShow.SetDecoration(this.Header, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.Header, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.Header.Location = new System.Drawing.Point(0, 0);
            this.Header.Name = "Header";
            this.Header.Size = new System.Drawing.Size(1080, 34);
            this.Header.TabIndex = 1;
            this.bunifuToolTip1.SetToolTip(this.Header, "");
            this.bunifuToolTip1.SetToolTipIcon(this.Header, null);
            this.bunifuToolTip1.SetToolTipTitle(this.Header, "");
            // 
            // TitlePic
            // 
            this.bunifuTransitionOnHide.SetDecoration(this.TitlePic, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.TitlePic, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.TitlePic.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_shop_96;
            this.TitlePic.Location = new System.Drawing.Point(12, 0);
            this.TitlePic.Name = "TitlePic";
            this.TitlePic.Size = new System.Drawing.Size(35, 34);
            this.TitlePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.TitlePic.TabIndex = 3;
            this.TitlePic.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.TitlePic, "");
            this.bunifuToolTip1.SetToolTipIcon(this.TitlePic, null);
            this.bunifuToolTip1.SetToolTipTitle(this.TitlePic, "");
            // 
            // TitleLb
            // 
            this.TitleLb.AutoSize = true;
            this.bunifuTransitionOnShow.SetDecoration(this.TitleLb, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.TitleLb, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.TitleLb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleLb.ForeColor = System.Drawing.Color.White;
            this.TitleLb.Location = new System.Drawing.Point(55, 7);
            this.TitleLb.Name = "TitleLb";
            this.TitleLb.Size = new System.Drawing.Size(146, 20);
            this.TitleLb.TabIndex = 2;
            this.TitleLb.Text = "Online Mobile Shop";
            this.bunifuToolTip1.SetToolTip(this.TitleLb, "");
            this.bunifuToolTip1.SetToolTipIcon(this.TitleLb, null);
            this.bunifuToolTip1.SetToolTipTitle(this.TitleLb, "");
            // 
            // bunifuImageButton4
            // 
            this.bunifuImageButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuImageButton4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuImageButton4, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuImageButton4.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_multiply_48;
            this.bunifuImageButton4.ImageActive = null;
            this.bunifuImageButton4.Location = new System.Drawing.Point(1037, 4);
            this.bunifuImageButton4.Name = "bunifuImageButton4";
            this.bunifuImageButton4.Size = new System.Drawing.Size(34, 28);
            this.bunifuImageButton4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton4.TabIndex = 1;
            this.bunifuImageButton4.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.bunifuImageButton4, "Close");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuImageButton4, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuImageButton4, "");
            this.bunifuImageButton4.Zoom = 10;
            this.bunifuImageButton4.Click += new System.EventHandler(this.BunifuI1mageButton4_Click);
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuImageButton3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuImageButton3, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuImageButton3.Image = global::Online_Mobile_Shop.Properties.Resources.icons8_minus_48;
            this.bunifuImageButton3.ImageActive = null;
            this.bunifuImageButton3.Location = new System.Drawing.Point(981, 4);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Size = new System.Drawing.Size(38, 28);
            this.bunifuImageButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton3.TabIndex = 1;
            this.bunifuImageButton3.TabStop = false;
            this.bunifuToolTip1.SetToolTip(this.bunifuImageButton3, "Minimize");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuImageButton3, null);
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuImageButton3, "");
            this.bunifuImageButton3.Zoom = 10;
            this.bunifuImageButton3.Click += new System.EventHandler(this.BunifuImageButton3_Click);
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.ActiveImage = global::Online_Mobile_Shop.Properties.Resources.iconfinder_minus_remove_delete_minimize_2931142;
            this.bunifuImageButton2.AllowAnimations = true;
            this.bunifuImageButton2.AllowZooming = true;
            this.bunifuImageButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuImageButton2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuImageButton2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuImageButton2.ErrorImage = global::Online_Mobile_Shop.Properties.Resources.iconfinder_minus_remove_delete_minimize_2931142;
            this.bunifuImageButton2.FadeWhenInactive = false;
            this.bunifuImageButton2.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton2.Image = null;
            this.bunifuImageButton2.ImageActive = global::Online_Mobile_Shop.Properties.Resources.iconfinder_minus_remove_delete_minimize_2931142;
            this.bunifuImageButton2.ImageLocation = null;
            this.bunifuImageButton2.ImageMargin = 40;
            this.bunifuImageButton2.ImageSize = new System.Drawing.Size(3, -9);
            this.bunifuImageButton2.ImageZoomSize = new System.Drawing.Size(43, 31);
            this.bunifuImageButton2.InitialImage = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(1162, 3);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Rotation = 0;
            this.bunifuImageButton2.ShowActiveImage = true;
            this.bunifuImageButton2.ShowCursorChanges = true;
            this.bunifuImageButton2.ShowImageBorders = true;
            this.bunifuImageButton2.ShowSizeMarkers = false;
            this.bunifuImageButton2.Size = new System.Drawing.Size(43, 31);
            this.bunifuImageButton2.TabIndex = 0;
            this.bunifuToolTip1.SetToolTip(this.bunifuImageButton2, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuImageButton2, null);
            this.bunifuImageButton2.ToolTipText = "";
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuImageButton2, "");
            this.bunifuImageButton2.WaitOnLoad = false;
            this.bunifuImageButton2.Zoom = 40;
            this.bunifuImageButton2.ZoomSpeed = 10;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.ActiveImage = null;
            this.bunifuImageButton1.AllowAnimations = true;
            this.bunifuImageButton1.AllowZooming = true;
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransitionOnHide.SetDecoration(this.bunifuImageButton1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnShow.SetDecoration(this.bunifuImageButton1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuImageButton1.ErrorImage = null;
            this.bunifuImageButton1.FadeWhenInactive = false;
            this.bunifuImageButton1.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton1.Image = null;
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.ImageLocation = null;
            this.bunifuImageButton1.ImageMargin = 40;
            this.bunifuImageButton1.ImageSize = new System.Drawing.Size(3, -9);
            this.bunifuImageButton1.ImageZoomSize = new System.Drawing.Size(43, 31);
            this.bunifuImageButton1.InitialImage = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1224, 3);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Rotation = 0;
            this.bunifuImageButton1.ShowActiveImage = true;
            this.bunifuImageButton1.ShowCursorChanges = true;
            this.bunifuImageButton1.ShowImageBorders = true;
            this.bunifuImageButton1.ShowSizeMarkers = false;
            this.bunifuImageButton1.Size = new System.Drawing.Size(43, 31);
            this.bunifuImageButton1.TabIndex = 0;
            this.bunifuToolTip1.SetToolTip(this.bunifuImageButton1, "");
            this.bunifuToolTip1.SetToolTipIcon(this.bunifuImageButton1, null);
            this.bunifuImageButton1.ToolTipText = "";
            this.bunifuToolTip1.SetToolTipTitle(this.bunifuImageButton1, "");
            this.bunifuImageButton1.WaitOnLoad = false;
            this.bunifuImageButton1.Zoom = 40;
            this.bunifuImageButton1.ZoomSpeed = 10;
            // 
            // bunifuToolTip1
            // 
            this.bunifuToolTip1.Active = true;
            this.bunifuToolTip1.AlignTextWithTitle = false;
            this.bunifuToolTip1.AllowAutoClose = false;
            this.bunifuToolTip1.AllowFading = true;
            this.bunifuToolTip1.AutoCloseDuration = 5000;
            this.bunifuToolTip1.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuToolTip1.BorderColor = System.Drawing.Color.Gainsboro;
            this.bunifuToolTip1.ClickToShowDisplayControl = false;
            this.bunifuToolTip1.ConvertNewlinesToBreakTags = true;
            this.bunifuToolTip1.DisplayControl = null;
            this.bunifuToolTip1.EntryAnimationSpeed = 350;
            this.bunifuToolTip1.ExitAnimationSpeed = 200;
            this.bunifuToolTip1.GenerateAutoCloseDuration = false;
            this.bunifuToolTip1.IconMargin = 6;
            this.bunifuToolTip1.InitialDelay = 0;
            this.bunifuToolTip1.Name = "bunifuToolTip1";
            this.bunifuToolTip1.Opacity = 1D;
            this.bunifuToolTip1.OverrideToolTipTitles = false;
            this.bunifuToolTip1.Padding = new System.Windows.Forms.Padding(10);
            this.bunifuToolTip1.ReshowDelay = 100;
            this.bunifuToolTip1.ShowAlways = true;
            this.bunifuToolTip1.ShowBorders = false;
            this.bunifuToolTip1.ShowIcons = true;
            this.bunifuToolTip1.ShowShadows = true;
            this.bunifuToolTip1.Tag = null;
            this.bunifuToolTip1.TextFont = new System.Drawing.Font("Segoe UI", 9F);
            this.bunifuToolTip1.TextForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuToolTip1.TextMargin = 2;
            this.bunifuToolTip1.TitleFont = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.bunifuToolTip1.TitleForeColor = System.Drawing.Color.Black;
            this.bunifuToolTip1.ToolTipPosition = new System.Drawing.Point(0, 0);
            this.bunifuToolTip1.ToolTipTitle = null;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.TitleLb;
            this.bunifuDragControl2.Vertical = true;
            // 
            // bunifuDragControl3
            // 
            this.bunifuDragControl3.Fixed = true;
            this.bunifuDragControl3.Horizontal = true;
            this.bunifuDragControl3.TargetControl = this.TitlePic;
            this.bunifuDragControl3.Vertical = true;
            // 
            // bunifuTransitionOnHide
            // 
            this.bunifuTransitionOnHide.AnimationType = Bunifu.UI.WinForms.BunifuAnimatorNS.AnimationType.VertSlide;
            this.bunifuTransitionOnHide.Cursor = null;
            animation2.AnimateOnlyDifferences = true;
            animation2.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.BlindCoeff")));
            animation2.LeafCoeff = 0F;
            animation2.MaxTime = 1F;
            animation2.MinTime = 0F;
            animation2.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicCoeff")));
            animation2.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicShift")));
            animation2.MosaicSize = 0;
            animation2.Padding = new System.Windows.Forms.Padding(0);
            animation2.RotateCoeff = 0F;
            animation2.RotateLimit = 0F;
            animation2.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.ScaleCoeff")));
            animation2.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.SlideCoeff")));
            animation2.TimeCoeff = 0F;
            animation2.TransparencyCoeff = 0F;
            this.bunifuTransitionOnHide.DefaultAnimation = animation2;
            // 
            // bunifuTransitionOnShow
            // 
            this.bunifuTransitionOnShow.AnimationType = Bunifu.UI.WinForms.BunifuAnimatorNS.AnimationType.VertSlide;
            this.bunifuTransitionOnShow.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.bunifuTransitionOnShow.DefaultAnimation = animation1;
            // 
            // ProductDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(1080, 720);
            this.Controls.Add(this.WorkSpace);
            this.Controls.Add(this.Sidebar);
            this.Controls.Add(this.Header);
            this.bunifuTransitionOnShow.SetDecoration(this, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.bunifuTransitionOnHide.SetDecoration(this, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProductDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.ProductDetails_Load);
            this.Sidebar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.WorkSpace.ResumeLayout(false);
            this.WorkSpace.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MobileImage)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.Searchbar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Login)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.Header.ResumeLayout(false);
            this.Header.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TitlePic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).EndInit();
            this.ResumeLayout(false);

        }


        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel WorkSpace;
        private System.Windows.Forms.Panel Searchbar;
        private System.Windows.Forms.Panel Sidebar;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel Header;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton4;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton3;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton2;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Bunifu.UI.WinForms.BunifuToolTip bunifuToolTip1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox TitlePic;
        private System.Windows.Forms.Label TitleLb;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl3;
        private System.Windows.Forms.PictureBox Login;
        private System.Windows.Forms.PictureBox pictureBox5;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton AdminButton;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton2;
        private Bunifu.UI.WinForms.BunifuTransition bunifuTransitionOnHide;
        private Bunifu.UI.WinForms.BunifuTransition bunifuTransitionOnShow;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuLabel SimText;
        private Bunifu.UI.WinForms.BunifuLabel ResolutionText;
        private Bunifu.UI.WinForms.BunifuLabel DisplaySizeText;
        private Bunifu.UI.WinForms.BunifuLabel WarrantyText;
        private Bunifu.UI.WinForms.BunifuLabel PriceText;
        private Bunifu.UI.WinForms.BunifuLabel ColorText;
        private Bunifu.UI.WinForms.BunifuLabel BatteryText;
        private Bunifu.UI.WinForms.BunifuLabel BluetoothText;
        private Bunifu.UI.WinForms.BunifuLabel WlanText;
        private Bunifu.UI.WinForms.BunifuLabel CameraText;
        private Bunifu.UI.WinForms.BunifuLabel MemoryText;
        private Bunifu.UI.WinForms.BunifuLabel ChipsetText;
        private Bunifu.UI.WinForms.BunifuLabel DisplayText;
        private Bunifu.UI.WinForms.BunifuLabel DimensionText;
        private Bunifu.UI.WinForms.BunifuLabel WeightText;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel25;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel21;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel19;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel48;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel46;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel44;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel41;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel38;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel36;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel33;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel30;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel27;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel17;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel12;
        private Bunifu.UI.WinForms.BunifuLabel LunchText;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel9;
        private Bunifu.UI.WinForms.BunifuLabel NetworkText;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel43;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel40;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel35;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel32;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel29;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel24;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel23;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel14;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel7;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuLabel BrandAndModelName;
        private System.Windows.Forms.PictureBox MobileImage;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton5;
        private System.Windows.Forms.Panel panel3;
        private Bunifu.UI.WinForms.BunifuLabel QuantityLabel;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton OrderHistorys;
    }
}