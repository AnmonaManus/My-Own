﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Online_Mobile_Shop_Data_Emlpement;
using Online_Mobile_Shop_Model;

namespace Online_Mobile_Shop
{
    public partial class SearchForUpdate : Form
    {
        AdminManagement management = new AdminManagement();
        AdminManage admin;
        string Control;
        Bunifu.UI.WinForms.BunifuButton.BunifuButton[] btn;
        public SearchForUpdate(String data,String Info, AdminManage _admin)
        {
            InitializeComponent();
            this.TitleLb.Text = data;
            Control = Info;
            admin = _admin;
        }
        Image ConvertByteToImage(byte[] data)
        {
            using (MemoryStream memory = new MemoryStream(data))
            {
                return Image.FromStream(memory);
            }
        }
        byte[] COnvertImageToByte(String image)
        {
            byte[] img = null;
            FileStream fs = new FileStream(image, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            return img = br.ReadBytes((int)fs.Length);
        }


            private void BunifuImageButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SearchForUpdate_Load(object sender, EventArgs e)
        {
            this.SearchBrand.Items.Clear();
            List<string> brands = management.FetchBrand();
            foreach (var bnd in brands)
            {
                this.SearchBrand.Items.Add(bnd);
            }
        }

        private void SearchBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            SearchModel.Enabled = false;
            SearchModel.Items.Clear();
            List<string> Models=management.FetchModel(SearchBrand.SelectedItem.ToString());
            foreach (var model in Models)
            {
                SearchModel.Items.Add(model);
            }
            SearchModel.Enabled = true;
        }

        private void SearchModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<Product> products = management.FetchModelInfo(SearchBrand.SelectedItem.ToString(), SearchModel.SelectedItem.ToString());
            btn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton[products.Count];
            
            for(int i=0;i<products.Count;i++)
            {
                btn[i] = new Bunifu.UI.WinForms.BunifuButton.BunifuButton() { IdleBorderColor = Color.FromArgb(37, 49, 57), IdleFillColor = Color.FromArgb(37, 49, 57), Size = new Size(114, 109), IdleIconLeftImage = ConvertByteToImage(products[i].Image), Text = products[i].productId.ToString() };
                bunifuToolTip1.SetToolTip(btn[i], $"Model:  {products[i].Model} \r\n Brand: {products[i].Brand} \r\n ProductId: {products[i].productId}");
                Results.Controls.Add(btn[i]);
                btn[i].Click += SearchForUpdate_Click;
            }
        }

        private void SearchForUpdate_Click(object sender, EventArgs e)
        {
            var value = (Bunifu.UI.WinForms.BunifuButton.BunifuButton)sender;
            if(this.Control.Equals("update"))
            {
                admin.GetSearchData(Convert.ToInt32(value.Text));
                this.Close();
            }
            else if(this.Control.Equals("delete"))
            {
                admin.GetSearchDataForDelete(Convert.ToInt32(value.Text));
                this.Close();
            }
        }
    }
}
