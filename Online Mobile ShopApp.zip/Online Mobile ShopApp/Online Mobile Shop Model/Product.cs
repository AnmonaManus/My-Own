﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Online_Mobile_Shop_Model
{
   public class Product
    {
        public int productId { set; get; }
        public string Network { set; get; }
        public string Launch { set; get; }
        public int Quantity { set; get; }
        public string Dimension { set; get; }
        public string Weight { set; get; }
        public string Sim { set; get; }
        public string Display { set; get; }
        public string DispalySize { set; get; }
        public string Resolution { set; get; }
        public string Chipset { set; get; }
        public string Ram { set; get; }
        public string Memory { set; get; }
        public string Camera { set; get; }
        public string Wlan { set; get; }
        public string Bluetooth { set; get; }
        public string Battery { set; get; }
        public string Color { set; get; }
        public string Price { set; get; }
        public string Warranty { set; get; }
        public string Model { set; get; }
        public string Brand { set; get; }
        public byte[] Image { set; get; }

    }
}
