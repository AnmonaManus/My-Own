﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Online_Mobile_Shop_Model
{
   public class Order:IDisposable
    {

        

    public string  Brand{ set; get; }
    public string Model { set; get; }
    public DateTime PurchaseTime { set; get; }
    public int Price { set; get; }
    public int Quantity { set; get; }
    public int OrderId { set; get; }
    public int ProductId { set; get; }
    public OrderStutas Stutas { set; get; }
    public DateTime? Delivered { set; get; }
    public int UserId { set; get; }

        public void Dispose()
        {
            GC.Collect();
        }

    }
}
