﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Online_Mobile_Shop_Model
{
    public class User
    {
        public int userId { set; get; }
        public string Fname { set; get; }
        public string Lname { set; get; }
        public string Email { set; get; }
        public Types Type { set; get; }
        public string Password { set; get; }
        public string Phone { set; get; }
        public string Address { set; get; }


    }
}
