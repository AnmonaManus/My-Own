﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Online_Mobile_Shop_Model
{
    public enum Types { Admin,User}
    public enum OrderStutas { Pending,Delivered}

}
