﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Online_Mobile_Shop_Model
{
  public  class Brand
    {
        public string brand { set; get; }
        public int brandId { set; get; }

    }
}
