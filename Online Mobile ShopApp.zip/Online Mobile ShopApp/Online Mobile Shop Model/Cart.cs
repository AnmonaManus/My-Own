﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Online_Mobile_Shop_Model
{
   public class Cart:IDisposable
    {
        public int ProductId { set; get; }
        public string Brand { set; get; }
        public string Model { set; get; }
        public int Price { set; get; }
        public int Quantity { set; get; }

        public void Dispose()
        {
            GC.Collect();
        }
    }
}
