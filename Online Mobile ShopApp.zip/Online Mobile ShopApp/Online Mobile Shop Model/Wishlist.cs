﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Online_Mobile_Shop_Model
{
    public class Wishlist
    {
        public string ProductId { set; get; }
        public string Brand { set; get; }
        public string Model { set; get; }
        public string Price { set; get; }
    }
}
