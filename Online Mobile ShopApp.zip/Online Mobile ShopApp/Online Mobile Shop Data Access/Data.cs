﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Online_Mobile_Shop_Data_Access
{
    public class Data
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Shop;Integrated Security=True");
        public SqlConnection GetCon()
        {
            if(con.State==ConnectionState.Closed)
            {
                con.Open();
            }
            return con;
        }

       public int ExeNonQuery(SqlCommand cmd)
        {
            cmd.Connection = GetCon();
            int rowAffected = -1;
            rowAffected = cmd.ExecuteNonQuery();
            con.Close();
            return rowAffected;
                   
        }
        public object ExeScalar(SqlCommand cmd)
        {
            cmd.Connection = GetCon();
            object obj = -1;
            obj = cmd.ExecuteScalar();
            con.Close();
            return obj;
        }
        public DataTable ExeReader(SqlCommand cmd)
        {
            cmd.Connection = GetCon();
            SqlDataReader sdr;
            DataTable dt = new DataTable();
            sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            return dt;
        }
    }
}
